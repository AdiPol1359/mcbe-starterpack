<?php

namespace pomoc;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("pomoc loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "pomoc"){
      $sender->sendMessage("§2�l");
      $sender->sendMessage("§2     �§6------§2< §6Dostepne komendy§2 >§e6------§2�");
      $sender->sendMessage("§6 /wymiana §8- §7 Wymiana item za item.");
	 $sender->sendMessage("§6 /spawn §8- §7 Platny teleport na spawn. (§6VIP§7 za darmo)");
	 $sender->sendMessage("§6 /yt §8- §7 Informacje o randze §2Youtuber.");
	 $sender->sendMessage("§6 /informacje §8- §7 Przydatne informacje.");
	 $sender->sendMessage("§6 /cobblex §8- §7 Informacje o §2CobblestoneX�7.");
	 $sender->sendMessage("§6 /g §8- §7 Komendy dotycznace gildii.");
	 $sender->sendMessage("§6 /efekty §8- §7Efekty do kupienia za zloto.");
	 $sender->sendMessage("§6 /drop §8- §7 Informacje o §2dropie§7 ze stone.");
      $sender->sendMessage("§6 /vip §8- §7 Informacje na temat konta §6VIP§7.");
	 $sender->sendMessage("§6 /kopacz §8- §7 Informacje na temat KopaczaFosy");
	 $sender->sendMessage("§6 /sandfarmer §8- §7 Informacje na temat sandfarmera");
      $sender->sendMessage("§6 /boyfarmer §8- §7 Informacje na temat boyfarmera");
       return true;
   }

}
}
