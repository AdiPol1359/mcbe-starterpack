<?php

namespace yNote;

use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\item\Item;

class sendTip extends PluginBase implements Listener{
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
       $this->getLogger()->info("\nPlugin criado por yNote!");
	}
	public function onMove(PlayerMoveEvent $event){
		$p = $event->getPlayer();
		if($p->getItemInHand()->getId() === 345){
			$rand = mt_rand(1,4);
			$p->sendTip("§7X: §c".$p->getFloorX()." §7Y:§c ".$p->getFloorY()." §7Z:§c ".$p->getFloorZ());
   }
	}
}