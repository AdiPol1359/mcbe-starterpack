<?php

namespace Sopa;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\entity\Effect;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\level\Level;
use pocketmine\level\sound\ClickSound;
use pocketmine\level\particle\HeartParticle;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\utils\TextFormat as Color;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\plugin\PluginManager;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;

class iPeedro extends PluginBase implements Listener{
    
    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
       
        public function onEat(PlayerItemConsumeEvent $event) {
			$i = $event->getItem();
            if($i->getId() == 466) {
			$player = $event->getPlayer();
            $effect = Effect::getEffect(1);
			$effect->setDuration(720);
            $effect->setAmplifier(1);
			$player->addEffect($effect);
			$effect2 = Effect::getEffect(5);
			$effect2->setDuration(720);
			$player->addEffect($effect2);
      }
            }
        }

