<?php

namespace FosaFarmerKup;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info("FOSAFARMER KAPPA Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('fosafarmer'))) {
				if(empty($args)) {
					$sender->sendMessage("§7[ ========== §aFosaFarmer§7 ========== ]");
					$sender->sendMessage("§7Co to FosaFarmer?");
					$sender->sendMessage("§o§a  * Jest to blok ktory po postawieniu niszczy 70 kratek w dol bloki");
					$sender->sendMessage("§7Aby kupic wpisz:");
					$sender->sendMessage("§o§a  * /fosafarmer kup §6- §o§cKoszt: 4 diamenty i 8 obsidianu");
					$sender->sendMessage("§7[ ========== §aFosaFarmer§7 ========== ]");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 4))){
					 if($sender->getInventory()->contains(Item::get(49, 0, 8))){
						$sender->getInventory()->addItem(Item::get(56, 0, 1));
						 $sender->getInventory()->removeItem(Item::get(264, 0, 4));
						 $sender->getInventory()->removeItem(Item::get(49, 0, 8));
						$sender->sendMessage("§e[ FosaFarmer ] Zakupiłeś §cFosaFarmer'a");
						}
						else{
							$sender->sendMessage("§cNiemasz tyle potrzebnych itemów, potrzebujesz: 4 diamenty i 8 obsidianu");
							}
						}
						else{
							$sender->sendMessage("§cNiemasz tyle potrzebnych itemów, potrzebujesz: 4 diamenty i 8 obsidianu");
							}
						return true;
                          }
	
	}
						}
					}