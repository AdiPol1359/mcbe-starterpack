<?php

namespace informacje;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("Informacje loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "is"){
      $sender->sendMessage("§l§8[§7-----------§a[ItemShop]§7-----------§8]");
      $sender->sendMessage(" §a* §7W naszym itemshopie mozesz zakupic takie uslugi jak: ");
      $sender->sendMessage(" §a* §7Ranga §aVIP§7, §a50% itemów na gildie §7oraz §aUnbana! ");
      $sender->sendMessage(" §a* §7Link: §atinyurl.com/z5b7qnt");
      $sender->sendMessage(" §a* §7Link2: §ahttp://sklep-minecraft.pl/sklep/hyperhc");
      $sender->sendMessage("§l§8[§7-----------§a[ItemShop]§7-----------§8]");
       return true;
   }
}
}
