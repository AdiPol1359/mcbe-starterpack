<?php

namespace sponsor;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("vip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "vip"){
      $sender->sendMessage("§l§8[§7-----------§a[VIP]§7-----------§8]");
      $sender->sendMessage(" §a* §7Co posiada ranga §aVIP§7?");
	  $sender->sendMessage(" §a* §7- §7Kit vip, a w nim: ");
	  $sender->sendMessage(" §a* §7- §aZelazna klate oraz spodnie");
	  $sender->sendMessage(" §a* §7- §aDiamentowy helm oraz buty");
	  $sender->sendMessage(" §a* §7- §aDiamentowe Narzedzia (Miecz, kilof)");
	  $sender->sendMessage(" §a* §7- §a3 Zlote jablka (refile) ");
	  $sender->sendMessage(" §a* §7- §a2 Stoniarki oraz 16 diamentow");
	  $sender->sendMessage(" §a* §7- §7Dodatkowe permisje takie jak: ");
      $sender->sendMessage(" §a* §7- §aDarmowa teleportacje na spawn");
	  $sender->sendMessage(" §a* §7- §aTeleportacje w ostatnie miejsce lub miejsce smierci: /back");
	  $sender->sendMessage(" §a* §7- §aNaprawe konkretnego lub wszystkich przedmiotow: /repair");
      $sender->sendMessage(" §a* §7Jak kupic range §aVIP§7?");
	  $sender->sendMessage(" §a* §7- §aAby zakupic range wejdz na nasza strone!");
	  $sender->sendMessage(" §a* §7- §aWpisz /is aby zakupic range!");
      $sender->sendMessage("§l§8[§7-----------§a[VIP]§7-----------§8]");
       return true;
   }

}
}
