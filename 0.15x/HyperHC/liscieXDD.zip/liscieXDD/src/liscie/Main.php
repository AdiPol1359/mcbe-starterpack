<?php

namespace liscie;

use pocketmine\plugin\PluginBase as P;
use pocketmine\event\Listener as L;
use pocketmine\utils\TextFormat;
use pocketmine\utils\MainLogger;
use pocketmine\block\Air;
use pocketmine\entity\Effect;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\level\sound\PopSound as Pop;
use pocketmine\level\particle\LavaParticle as Lava;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;

class Main extends P implements L{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
		$this->saveDefaultConfig();
		$this->getServer()->getLogger()->info(TextFormat::GREEN."Enabled!");
	}

	
	public function onBreak(BlockBreakEvent $event){
		if(!($event->isCancelled())){
		$player = $event->getPlayer();
		$gracz = $event->getPlayer()->getName();
		$blok = $event->getBlock();
		$y = $blok->getFloorY();
		$x = $blok->getFloorX();
		$z = $blok->getFloorZ();
		if($blok->getId() == 18){
			 switch(mt_rand(1,5)){
		 		 case 1:
		$player->getLevel()->dropItem(new Vector3($x, $y, $z), Item::get(260, 0, 1));
		 break;
			 }
		}
		}
	}
	}
