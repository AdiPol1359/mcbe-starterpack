# ChatToolsPro

ChatToolsPro, the ultimate Chat Plugin.

 The Chat Toolbox coded by paetti!

 Dont Report Bugs in the Feedback please! Please Kik me!

Project Page: http://paetti.github.io/ChatToolsPro

For the Devlog go here: http://paetti.github.io/ChatToolsPro/devlog.html



 My Kik is: Oupsay
 If there nobody is Kik to: xpaetti

 Avaible Commands:

 /helpme - Adds [Needs Help] Tag to a Players name
 default: true

 /done - Removed [Needs Help] Tag from a Players name
 default: true

 /announcement - Broadcast with [Announcement] Tag
 default: op

 /serversay - Broadcast as [Server]
 default: op

 /staffsay - Broadcast as [Staff]
 default: op

 /Support - Broadcast as [Support]
 default: op

 /vmsg - Message somebody without your Name ( [ -> (Player)] Message)
 default: op

 /warning - Broadcast a [Warning]
 default: op

 /info - Broadcast a [Info]
 default: op

 /warn - Warn a player
 default: op

 /chatsay - Broadcast Message without any Tag
 default: op

 /tipgive - Give a Player an Tip
 default: true

 /setnick - Set your nick
 default: op
 
 /delnick - Reset your nick or the of another player
 default: op

 /sayas - Say a message as another Player (Beta)
 default: op

 /clearchat - Chat Clearer
 default: op

 /spam - Spam!
 default: op

 /ops - See online OP's
 default: true

 /Report - Report A Player and all OP's get a Report message
 default: true

 /checkop - Check if a Player is OP or not
 default: op
 
 /spammsg - Write a spam message to a Player
 default: op
 
 /lockchat - Lock or unlock the chat for all Players
 default: op

 /illuminati - Illuminati Message
 default: op
