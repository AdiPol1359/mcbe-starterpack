<?php

namespace Dirtex;

use pocketmine\plugin\PluginBase as P;
use pocketmine\event\Listener as L;
use pocketmine\utils\TextFormat;
use pocketmine\utils\MainLogger;
use pocketmine\block\Air;
use pocketmine\Server;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\level\sound\PopSound as Pop;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\level\particle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\level\sound;

class Main extends P implements L{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
		$this->saveDefaultConfig();
		$this->getServer()->getLogger()->info(TextFormat::GREEN."[CobbleX] Włączony!");
	}

	
	public function onPlace(BlockPlaceEvent $e){
		$player = $e->getPlayer();
		$block = $e->getBlock();
		$gracz = $e->getPlayer()->getName();
		if($e->getBlock()->getId() == 129){
			if(!($e->isCancelled())){
			 switch(mt_rand(1,20)){
         case 1:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(2) §7Złote jabłka (Koxy) §8•");
         $player->getInventory()->addItem(Item::get(466, 7, 2));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
        $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		$event->setCancelled();
		}
		$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 2:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(3) §7Złote Jabłka (Refile) §8•");
         $player->getInventory()->addItem(Item::get(322, 29, 3));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
		$event->setCancelled();
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
         break;
         case 3:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(1) §7Mikstura Siły §8•");
         $player->getInventory()->addItem(Item::get(373, 32, 1));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 4:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(3) §7CobbleX §8•");
         $player->getInventory()->addItem(Item::get(129, 0, 3));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 5:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(13) §7Diamentów §8•");
         $player->getInventory()->addItem(Item::get(264, 0, 13));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 6:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(49) §7Melon §8•");
         $player->getInventory()->addItem(Item::get(360, 0, 49));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 7:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(2) §7Mikstury niewidzialności §8•");
         $player->getInventory()->addItem(Item::get(373, 8, 2));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 8:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(64) §7Kamieni §8•");
         $player->getInventory()->addItem(Item::get(1, 0, 64));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 9:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(13) §7Jabłek §8•");
         $player->getInventory()->addItem(Item::get(260, 0, 13));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 10:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(7) §7Żelaza §8•");
         $player->getInventory()->addItem(Item::get(265, 0, 7));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 11:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(17) §7Złota §8•");
         $player->getInventory()->addItem(Item::get(266, 0, 17));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 12:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(42) §7Piasek §8•");
         $player->getInventory()->addItem(Item::get(12, 0, 42));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 13:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(64) §7Szkła §8•");
         $player->getInventory()->addItem(Item::get(20, 0, 64));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 14:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(1) §7Stół do enchantowania §8•");
         $player->getInventory()->addItem(Item::get(116, 0, 1));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 15:
         $player->sendMessage("§§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(1) §7Statyw alchemiczny §8•");
         $player->getInventory()->addItem(Item::get(379, 0, 1));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 16:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(31) §7TNT §8•");
         $player->getInventory()->addItem(Item::get(46, 0, 31));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 17:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(38) §7Półki z książkami §8•");
         $player->getInventory()->addItem(Item::get(47, 0, 38));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 18:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(43) §7Obsidian §8•");
         $player->getInventory()->addItem(Item::get(49, 0, 43));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 19:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7wylosował: §6(15) §7Steków §8•");
         $player->getInventory()->addItem(Item::get(364, 0, 15));
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
         break;
         case 20:
         $player->sendMessage("§8• §8[§6CobbleX§8] §7Gracz §6$gracz §7nic nie wylosował §8•");
         $player->getInventory()->addItem(Item::get());
         $player->addExperience(1);
         $player->getInventory()->removeItem(Item::get(129, 0, 1));
                 $level = $this->getServer()->getDefaultLevel();
		$x = $e->getBlock()->getFloorX();
		$y = $e->getBlock()->getFloorY();
		$z = $e->getBlock()->getFloorZ();
        $center = new Vector3($x, $y, $z);
        $radius = 1; 
        $count = 100;
        $particle = new LavaParticle($center);
        for($yaw = 3, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 30, $y += 1 / 25){
        $x = -sin($yaw) + $center->x;
        $z = cos($yaw) + $center->z;
        $particle->setComponents($x, $y, $z);
        $level->addParticle($particle);
		}
				$level = $player->getLevel();
		$level->addSound(new BlazeShootSound($player));
		$event->setCancelled();
		break;
}
	}
	else{
		$player->sendMessage("§cNie mozesz niszczyc cobblexa na zabezpieczonym terenie!");
		$event->setCancelled();
	}
}
	}
}