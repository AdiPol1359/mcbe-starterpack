<?php

namespace wymiana;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info(" Wymiany Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('wymiana'))) {
				if(empty($args)) {
					$sender->sendMessage("§7[ ========== §a[ Wymiana ] §7 ========== ]");
					$sender->sendMessage("§7> Aby wymienic dany item wpisz §c/wymiana (nr)");
					$sender->sendMessage("§7> §b[§c1§b] §764x2 Cobblestone na 1 TNT");
                 $sender->sendMessage("§7> §b[§c2§b] §764x9 Cobblestone na 32 TNT ");
					$sender->sendMessage("§7> §b[§c3§b] §764x9 Cobblestone na 64x3 Obsydianu");
					$sender->sendMessage("§7[ ========== §a[ Wymiana ] §7 ========== ]");
					return true;
				}   
					 if($args[0] == "1") {
					 if($sender->getInventory()->contains(Item::get(4, 0, 128))){
                               $sender->getInventory()->addItem(Item::get(46, 0, 1));
                               $sender->getInventory()->removeItem(Item::get(4, 0, 128));
						$sender->sendMessage("§e• §b[§cHyperHC§b] §7Wymieniles Cobblestone na  §c1 TNT ");
            }
						else{
							$sender->sendMessage("§c• §b[§cHyperHC§b] §7Nie posiadasz §c2x64 §7Cobblestone! •");
							}
						return true;
                }    
                     if($args[0] == "2") {
					    if($sender->getInventory()->contains(Item::get(4, 0, 576))){
                               $sender->getInventory()->addItem(Item::get(46, 0, 32));
                               $sender->getInventory()->removeItem(Item::get(4, 0, 576));
						$sender->sendMessage("§e• §b[§cHyperHC§b] §7Wymieniles Cobblestone na §c32 TNT ");
            }
						else{
							$sender->sendMessage("§c• §b[§cHyperHC§b] §7Nie posiadasz §c64x9 §7Cobblestone! •");
							}
						return true;
                }  
                     if($args[0] == "3") {
					    if($sender->getInventory()->contains(Item::get(4, 0, 576))){
                               $sender->getInventory()->addItem(Item::get(49, 0, 192));
                               $sender->getInventory()->removeItem(Item::get(4, 0, 576));
						$sender->sendMessage("§e• §b[§cHyperHC§b] §7Wymieniles Cobblestone na §c64x3 Obsydianu ");
            }
						else{
							$sender->sendMessage("§c• §b[§cHyperHC§b] §7Nie posiadasz §c64x9 §7cobblestone! •");
							}
						return true;
                          }
	
	}
						}
					}
