<?php

namespace efekty;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;

use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;

use pocketmine\item\Item;
use pocketmine\Player;
use pockemine\inventory\Inventory;

use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerItemHeldEvent;

use pocketmine\entity\Living;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\entity\Entity;

use pocketmine\level\particle\CriticalParticle;
use pocketmine\Server;

class main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("Enabling bcEffects...");
		$cmd = "setworldspawn 40 64 -41";
		$this->getServer()->dispatchCommand(new ConsoleCommandSender,$cmd);
		}
		
		  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
	   $name = $sender->getPlayer()->getName();
	
			if(strtolower($command->getName('efekt'))) {
				if(empty($args)) {
					$sender->sendMessage("§8[§7------------§6[ Efekty ]§7------------§8]");
					$sender->sendMessage("§7Nazwa: §cSzybkie Bieganie I - Numer 1");
					$sender->sendMessage("§7 Koszt:§c 10 Diamentów.");
					$sender->sendMessage("§7    Czas:§c 5 minut");
					$sender->sendMessage("§7Nazwa: §cSzybkie Bieganie II - Numer 2");
					$sender->sendMessage("§7 Koszt:§c 20 Diamentów.");
					$sender->sendMessage("§7    Czas:§c 5 minut");
					$sender->sendMessage("§7Nazwa: §cSzybkie Kopanie I - Numer 3");
					$sender->sendMessage("§7 Koszt:§c 15 Diamentów.");
					$sender->sendMessage("§7    Czas:§c 5 minut");
					$sender->sendMessage("§7Nazwa: §cSzybkie Kopanie II - Numer 4");
					$sender->sendMessage("§7 Koszt:§c 30 Diamentów.");
					$sender->sendMessage("§7    Czas:§c 5 minut");
					$sender->sendMessage("§7Nazwa: §cSila I - Numer 5");
					$sender->sendMessage("§7 Koszt:§c 20 Diamentów.");
					$sender->sendMessage("§7    Czas:§c 5 minut");
					$sender->sendMessage("§7Nazwa: §cOchrona przed ogniem - Numer 6");
					$sender->sendMessage("§7 Koszt:§c 15 Diamentów.");
					$sender->sendMessage("§7    Czas:§c 5 minut");
					$sender->sendMessage("§8[§7------------§6[ Efekty ]§7------------§8]");
					return true;
			   	 }
					 if($args[0] == "1") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 10))){
					 $sender->getInventory()->removeItem(Item::get(264, 0, 10));
					 $sender->sendMessage("§f• §8[§6Efekty§8] §7Zakupiłeś efekt: §cSzybkie Bieganie I §f•");
					 $cmd = "effect $name 1 300 0";
					 $this->getServer()->dispatchCommand(new ConsoleCommandSender,$cmd);
					 }
					 else{
					 $sender->sendMessage("§f• §8[§ebcEffects§8] §7Potrzebujesz §c10 §7diamentów by kupić ten efekt! §f•");
					 }
					 }
					 if($args[0] == "2") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 20))){
					 $sender->getInventory()->removeItem(Item::get(264, 0, 20));
					 $sender->sendMessage("§f• §8[§6Efekty§8] §7Zakupiłeś efekt: §cSzybkie Bieganie II §f•");
					 $cmd = "effect $name 1 300 1";
					 $this->getServer()->dispatchCommand(new ConsoleCommandSender,$cmd);
					 }
					 else{
					 $sender->sendMessage("§f• §8[§ebcEffects§8] §7Potrzebujesz §c20 §7diamentów by kupić ten efekt! §f•");
					 }
					 }
					 if($args[0] == "3") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 15))){
					 $sender->getInventory()->removeItem(Item::get(264, 0, 15));
					 $sender->sendMessage("§f• §8[§6Efekty§8] §7Zakupiłeś efekt: §cSzybkie Kopanie I §f•");
					 $cmd = "effect $name 3 300 0";
					 $this->getServer()->dispatchCommand(new ConsoleCommandSender,$cmd);
					 }
					 else{
					 $sender->sendMessage("§f• §8[§ebcEffects§8] §7Potrzebujesz §c15 §7diamentów by kupić ten efekt! §f•");
					 }
					 }
					 if($args[0] == "4") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 30))){
					 $sender->getInventory()->removeItem(Item::get(264, 0, 30));
					 $sender->sendMessage("§f• §8[§6Efekty§8] §7Zakupiłeś efekt: §cSzybkie Kopanie II §f•");
					 $cmd = "effect $name 3 300 0";
					 $this->getServer()->dispatchCommand(new ConsoleCommandSender,$cmd);
					 }
					 else{
					 $sender->sendMessage("§f• §8[§ebcEffects§8] §7Potrzebujesz §c30 §7diamentów by kupić ten efekt! §f•");
					 }
			
	  	}
					 if($args[0] == "5") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 20))){
					 $sender->getInventory()->removeItem(Item::get(264, 0, 20));
					 $sender->sendMessage("§f• §8[§6Efekty§8] §7Zakupiłeś efekt: §cSiła I §f•");
					 $cmd = "effect $name 5 300 0";
					 $this->getServer()->dispatchCommand(new ConsoleCommandSender,$cmd);
					 }
					 else{
					 $sender->sendMessage("§f• §8[§ebcEffects§8] §7Potrzebujesz §c20 §7diamentów by kupić ten efekt! §f•");
					 }
			
	  	}
					 if($args[0] == "6") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 15))){
					 $sender->getInventory()->removeItem(Item::get(264, 0, 15));
					 $sender->sendMessage("§f• §8[§6Efekty§8] §7Zakupiłeś efekt: §cOchrona przed ogniem I §f•");
					 $cmd = "effect $name 12 300 0";
					 $this->getServer()->dispatchCommand(new ConsoleCommandSender,$cmd);
					 }
					 else{
					 $sender->sendMessage("§f• §8[§ebcEffects§8] §7Potrzebujesz §c15 §7diamentów by kupić ten efekt! §f•");
					 }
			
	  	}
		}
		  }
}