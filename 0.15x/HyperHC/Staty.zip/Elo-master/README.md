# Elo
## The Elo plugin for all your needs! With an api

# Commands:
## /elo
### See your own elo
## /addelo name elo
### Add elo to a player
## /removeelo name elo
### Remove elo from a player
## /seeelo name
### See another players elo
## /topelo
### Find out who have the most elo on the server

