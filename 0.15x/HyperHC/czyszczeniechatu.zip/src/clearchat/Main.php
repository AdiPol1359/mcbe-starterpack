<?php

namespace clearchat;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\level\Position;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\item\Item;
use pockemine\inventory\Inventory;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerJoinEvent;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("ClearChat loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "cc"){
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
      $this->getServer()->broadcastMessage("§l");
	  $this->getServer()->broadcastMessage("§f• §7Chat zostal wyczyszczony przez§e " . $sender->getName() . " §f•");
       return true;
   }
}
}