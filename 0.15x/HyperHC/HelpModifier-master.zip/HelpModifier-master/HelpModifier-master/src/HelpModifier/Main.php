<?php

  namespace HelpModifier;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pockemine\inventory\Inventory;
use pocketmine\event\player\PlayerDeathEvent;

  class Main extends PluginBase implements Listener {


    public function onEnable() {

      $this->getServer()->getPluginManager()->registerEvents($this, $this);

    }

    public function sendHelp(PlayerCommandPreprocessEvent $event) {

      $command = explode(" ", strtolower($event->getMessage()));

      $player = $event->getPlayer();

      if($command[0] === "/spawn") {
          if($player->hasPermission("tepanie.spawn") or $player->getInventory()->contains(Item::get(41, 0, 1))) {
        $player->getInventory()->removeItem(Item::get(41, 0, 1));      
  }
  else {
	  $event->setCancelled();
	  $player->sendMessage("§f• §7Aby teleportowac sie na spawn potrzebujesz 1 Blok zlota! §f•");
	  }
	}
  }
  }
