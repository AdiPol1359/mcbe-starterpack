# GuildsRPG
A simple(not so) plugin called Guilds based on FactionsPro also add new feature for your server.

# Info:
- Actually This Plugin Were Taken From FactionsPro because others user can use it fine with PureChat plugin.
- You Need EconomyAPI, If Not This Plugin Will Not Work..
- I Recommend You Check Put The FactionCommand.php Cause There Might A Commands I Forgot To Add In Help List.
- Please Report Any Kind Of Bugs At The Issues.

# Features:

- [x] EconomysAPI Support (create,claim,ally,sethome)
- [x] Allies System
- [x] Wars System
- [x] Leaderboards (as /g leaderboards)
- [x] Plots
- [x] Admin Commands (which is /g help 6[only op player])

# Commands:

- usage: /guilds
- help : /guilds help

# Others:
I hope this plugin can help and add a new implement to your server.

# New Update:

- [x] Add Plots (by request)
- [x] Some Fix
- [x] now commands : /g and /guilds
- [x] Much More!!
- [x] WorldClaim (so your hub people can't claim)
- [x] Test Update: GuildsMoney
- [x] Clean Up
- [x] Add GuildsMoney At Info
- [x] Fix Bugs
- [x] Add OP Command /g addmoney <guilds> <money>
- [x] Add /g say <message>

# Todo List
- [ ] Add More Features On GuildsMoney
- [ ] Guilds Booster


