<?php

namespace eventtp;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;

use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;

use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pockemine\inventory\Inventory;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("Event-TP zaladowane");
		 $this->getServer()->loadLevel("world");
		}
	
  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
	    $player = $sender->getPlayer();
			if(strtolower($command->getName('event'))) {
					 $player->teleport(new Position(-100,70,-100, $this->getServer()->getLevelByName("world")));
					 $sender->sendMessage("§f• §7Teleportacja na Event §7... §f•");
           }
			
	  	}
		}