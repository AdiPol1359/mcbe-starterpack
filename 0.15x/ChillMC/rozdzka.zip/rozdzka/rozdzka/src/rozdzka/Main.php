<?php

namespace rozdzka;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;

use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;

use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pockemine\inventory\Inventory;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\entity\Effect;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("Rozdzka teleportujaca");
		 $this->getServer()->loadLevel("world");
		}
	
	public function interaktmadafaka(PlayerInteractEvent $event) {
		$player = $event->getPlayer();
				if($player->getItemInHand()->getId() === 352) {
				$player->addEffect(Effect::getEffect(9)->setAmplifier(1)->setDuration(30)->setVisible(false));
					 $player->teleport(new Position(-51,81,-15, $this->getServer()->getLevelByName("world")));
           }
	  	}
		}