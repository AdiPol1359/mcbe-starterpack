<?php

namespace drop;

use pocketmine\plugin\PluginBase as P;
use pocketmine\event\Listener as L;
use pocketmine\utils\TextFormat;
use pocketmine\utils\MainLogger;
use pocketmine\block\Air;
use pocketmine\entity\Effect;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\level\sound\PopSound as Pop;
use pocketmine\level\particle\LavaParticle as Lava;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;

class Main extends P implements L{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
		$this->saveDefaultConfig();
		$this->getServer()->getLogger()->info(TextFormat::GREEN."[DROP] Włączony!");
	}

	
	public function onBreak(BlockBreakEvent $e){
		$player = $e->getPlayer();
		$block = $e->getBlock();
		$gracz = $e->getPlayer()->getName();
		if($e->getBlock()->getId() == 1){
			 switch(mt_rand(1,606)){
		 case 1:
         $player->sendMessage("§f• §8[§6BH] §7Znalazłeś: §6(1) §7Perle (§6+6exp§7) §f•");
         $player->getInventory()->addItem(Item::get(332, 0, 1));
		 $player->addExperience(6);
         case 2:
         $player->sendMessage("§f• §8[§6BH] §7Znalazłeś: §6(3) §7Złota (§6+4exp§7) §f•");
         $player->getInventory()->addItem(Item::get(14, 0, 3));
		 $player->addExperience(4);
         break;
         case 3:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(2) §7Złota (§6+3exp§7) §f•");
         $player->getInventory()->addItem(Item::get(14, 0, 2));
		 $player->addExperience(3);
         break;
         case 4:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(1) §7Złoto (§6+2exp§7) §f•");
         $player->getInventory()->addItem(Item::get(14, 0, 1));
		 $player->addExperience(2);
         break;
		 		 case 5:
		 $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(3) §7Diamenty (§6+3exp§7) §f•");
		 $player->getInventory()->addItem(Item::get(264, 0, 3));
		 		 $player->addExperience(3);
		 break;
		 		 case 6:
		 $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(2) §7Diamenty (§6+2exp§7) §f•");
		 $player->getInventory()->addItem(Item::get(264, 0, 2));
		 		 $player->addExperience(2);
		 break;
		 		 case 7:
		 $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(1) §7Diamenty (§6+1exp§7) §f•");
		 $player->getInventory()->addItem(Item::get(264, 0, 1));
		 		 $player->addExperience(1);
		 break;
		          case 8:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(3) §7Obsydianu (§6+2exp§7) §f•");
         $player->getInventory()->addItem(Item::get(49, 0, 3));
		 $player->addExperience(2);
         break;
		          case 9:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(2) §7Obsydianu (§6+2exp§7) §f•");
         $player->getInventory()->addItem(Item::get(49, 0, 2));
		 $player->addExperience(2);
         break;
		          case 10:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(1) §7Obsydian (§6+2exp§7) §f•");
         $player->getInventory()->addItem(Item::get(49, 0, 1));
		 $player->addExperience(2);
         break;
		          case 11:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(3) §7Emeraldy (§6+2exp§7) §f•");
         $player->getInventory()->addItem(Item::get(388, 0, 3));
		 $player->addExperience(2);
         break;
		          case 12:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(2) §7Emeraldy (§6+2exp§7) §f•");
         $player->getInventory()->addItem(Item::get(388, 0, 2));
		 $player->addExperience(2);
         break;
		          case 13:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(1) §7Emerald (§6+2exp§7) §f•");
         $player->getInventory()->addItem(Item::get(388, 0, 1));
		 $player->addExperience(2);
         break;
		 		 case 14:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(3) §7Żelaza (§6+2exp§7) §f•");
         $player->getInventory()->addItem(Item::get(15, 0, 3));
		 $player->addExperience(2);
         break;
		 		 case 15:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(2) §7Żelaza (§6+2exp§7) §f•");
         $player->getInventory()->addItem(Item::get(15, 0, 2));
		 $player->addExperience(2);
         break;
		 		 case 16:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(1) §7Żelazo (§6+2exp§7) §f•");
         $player->getInventory()->addItem(Item::get(15, 0, 1));
		 $player->addExperience(2);
         break;
		 		          case 17:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(3) §7Proszku (§6+3exp§7) §f•");
         $player->getInventory()->addItem(Item::get(289, 0, 3));
		 $player->addExperience(3);
         break;
		 		          case 18:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(2) §7Proszku (§6+2exp§7) §f•");
         $player->getInventory()->addItem(Item::get(289, 0, 2));
		 $player->addExperience(2);
         break;
		 		          case 19:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(1) §7Proszku (§6+1exp§7) §f•");
         $player->getInventory()->addItem(Item::get(289, 0, 1));
		 $player->addExperience(1);
         break;
		 		 case 20:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(3) §7Książek (§6+1exp§7) §f•");
         $player->getInventory()->addItem(Item::get(340, 0, 3));
		 $player->addExperience(1);
         break;
		 		 case 21:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(2) §7Książki (§6+1exp§7) §f•");
         $player->getInventory()->addItem(Item::get(340, 0, 2));
		 $player->addExperience(1);
         break;
		 		 case 22:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(1) §7Książke (§6+1exp§7) §f•");
         $player->getInventory()->addItem(Item::get(340, 0, 1));
		 $player->addExperience(1);
         break;
		 		 		 case 23:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(3) §7Lapis Lazuli (§6+1exp§7) §f•");
         $player->getInventory()->addItem(Item::get(351, 4, 3));
		 $player->addExperience(1);
         break;
		 		 		 case 24:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(2) §7Lapis Lazuli (§6+1exp§7) §f•");
         $player->getInventory()->addItem(Item::get(340, 0, 2));
		 $player->addExperience(1);
         break;
		 		 		 case 25:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(1) §7Lapis Lazuli (§6+1exp§7) §f•");
         $player->getInventory()->addItem(Item::get(340, 0, 1));
		 $player->addExperience(1);
         break;
         case 26:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(3) §7Węgla (§6+1exp§7) §f•");
         $player->getInventory()->addItem(Item::get(263, 0, 3));
		 $player->addExperience(1);
         break;
		          case 27:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(2) §7Węgla (§6+1exp§7) §f•");
         $player->getInventory()->addItem(Item::get(263, 0, 2));
		 $player->addExperience(1);
         break;
		          case 28:
         $player->sendMessage("§f• §8[§6BH§8] §7Znalazłeś: §6(1) §7Węgiel (§6+1exp§7) §f•");
         $player->getInventory()->addItem(Item::get(263, 0, 1));
		 $player->addExperience(1);
         break;
			 }
		}
	}
}
