<?php

namespace sponsor;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("sponsor loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "sponsor"){
      $sender->sendMessage("§l§8 [§7-----------§a[SPONSOR]§7-----------§8]");
      $sender->sendMessage(" §a* §7Jak kupic range §aSPONSOR? ");
      $sender->sendMessage(" §a* §7Wyslij SMS'a o tresci §aAP.HOSTMC §7na numer §a91758");
      $sender->sendMessage(" §a* §7Calkowity koszt rangi to §a20,91§7zl.");
      $sender->sendMessage(" §a* §7Co posiada ranga §aSPONSOR§7?");
	  $sender->sendMessage(" §a* §7- §aPrzywileje svipa oraz vipa (kity rowniez) ");
	  $sender->sendMessage(" §a* §7- §aDarmowa teleportacje na spawn, homy");
	  $sender->sendMessage(" §a* §7- §aDarmowe tworzenie homow oraz gildii");
	  $sender->sendMessage(" §a* §7- §aDrop 25% powiekszony");
      $sender->sendMessage(" §a* §7Kit §asponsor §7zawiera: ");
	  $sender->sendMessage(" §a* §7- §aDiamentowy Miecz Ostrosc 5, Odrzut 2");
	  $sender->sendMessage(" §a* §7- §aDiamentowa Zbroje oraz narzedzia");
	  $sender->sendMessage(" §a* §7- §a2 Zlote Jablka(koxy), 14 Zlotych Jablek(refili) oraz 25 chleba");
	  $sender->sendMessage(" §a* §7- §aLuk i 64 strzaly");
      $sender->sendMessage("§l§8[§7-----------§a[SPONSOR]§7-----------§8]");
       return true;
   }

}
}
