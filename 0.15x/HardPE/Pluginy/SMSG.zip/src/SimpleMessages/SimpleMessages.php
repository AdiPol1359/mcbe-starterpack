<?php
/**
 * User: Michael Leahy
 * Date: 6/24/14
 * Time: 11:02 AM
 */

namespace SimpleMessages;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

class SimpleMessages extends PluginBase{

    public $configFile;

    public function onEnable(){
        @mkdir($this->getDataFolder());
        $this->configFile = (new Config($this->getDataFolder()."config.yml", Config::YAML, array(
            "messages" => array(
                "Listę komend znajdziesz pod /help •",
                "Chcesz szybko teleportować się do sklepu? Wpisz /sklep •",
                "Polub nasz fanpage na fb! facebook.com/HardPe •",
                "Wszystkie informacje znajdziesz na spawnie •",
            ),
            "time" => "60",
            "prefix" => "BOT",
            "color" => "§9"
        )))->getAll();

        $time = intval($this->configFile["time"]) * 20;
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new SimpleMessagesTask($this), $time);

        $this->getLogger()->info("I've been enabled!");
    }

    public function onDisable(){
        $this->getLogger()->info("I've been disabled!");
    }

}
