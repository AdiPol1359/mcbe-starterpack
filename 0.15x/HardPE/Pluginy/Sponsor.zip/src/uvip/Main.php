<?php

namespace uvip;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("vip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "sponsor"){
      $sender->sendMessage("§a[----------------§6[Sponsor]§a---------------]");
      $sender->sendMessage("§a> Wyslij sms o tresci§c DOGRY§a pod numer§c 91909§a <");
      $sender->sendMessage("§a> §aKoszt: §c23.37zl§a, kod podaj§c Marttinkowi §a<");
      $sender->sendMessage("§a> Mozna takze kupic za doladowanie do play 2x10 zl <");
      $sender->sendMessage("§a> lub kodem psc o wartosci 20zl <");
      $sender->sendMessage("§a> Sponsor posiada wszystkie wlasciwosci §bVIP §ai§e SVIP§a <");
      $sender->sendMessage("§a> razem z /kit vip oraz /kit svip <");
      $sender->sendMessage("§a> Inne wlasciwosci sponsora: <");
      $sender->sendMessage("§a> darmowe podpalanie graczy <");
      $sender->sendMessage("§a> pisanie bez ograniczenia czasowego na chacie <");
      $sender->sendMessage("§a> Ranga jest do konca edycji! <");
      $sender->sendMessage("§a[----------------§6[Sponsor]§a---------------]");
       return true;
   }

}
}
