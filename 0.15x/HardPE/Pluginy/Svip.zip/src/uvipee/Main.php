<?php

namespace uvipee;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("svip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "svip"){
      $sender->sendMessage("§a[----------------§e[SVIP]§a---------------]");
      $sender->sendMessage("§a> Wyslij sms o tresci§c DOGRY§a pod numer§c 79550§a <");
      $sender->sendMessage("§a> §aKoszt: §c11.07 zl§a, kod podaj§c Marttinkowi§a <");
      $sender->sendMessage("§a> Mozna takze kupic za doladowanie do play 10zl! <");
      $sender->sendMessage("§a> SVIP ma wlasciwosci vipa (oprocz kitu), oraz <");
      $sender->sendMessage("§a> otrzymuje: Komendy: /getpos /near /back <");
      $sender->sendMessage("§a> /kit svip a w nim znajduje sie: <");
      $sender->sendMessage("§a> Diamentowy set, luk, 128 strzal, diamentowe narzedzia <");
      $sender->sendMessage("§a> 5 Refili, 16 diaxow, 16 zlota, 16 zelaza, 16 redstone <");
      $sender->sendMessage("§a> Ranga jest do konca edycji! <");
      $sender->sendMessage("§a[----------------§e[SVIP]§a---------------]");
       return true;
   }

}
}
