<?php

namespace Stoniarka;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info(" Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('stoniarka'))) {
				if(empty($args)) {
					$sender->sendMessage("§7[ ========== §a[ Stoniarka ] §7 ========== ]");
					$sender->sendMessage("§7> Jest to End_Stone, który ");
					$sender->sendMessage("§7> generuje stone! ");
                         $sender->sendMessage("§7> aby kupic, wpisz §c/stoniarka kup");
					$sender->sendMessage("§7> Koszt: §c10 diamentow");
					$sender->sendMessage("§7[ ========== §a[ Stoniarka ] §7 ========== ]");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 10))){
                               $sender->getInventory()->addItem(Item::get(121, 0, 1));
                               $sender->getInventory()->removeItem(Item::get(264, 0, 10));
						$sender->sendMessage("§e• [HardPe] Zakupiles §6Pioruna• ");
            }
						else{
							$sender->sendMessage("§c• [HardPe] Nie posiadasz 10 diamentow! •");
							}
						return true;
                          }
	
	}
						}
					}
