<?php

namespace DirtexKUP;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info("PiorunKUP Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('piorun'))) {
				if(empty($args)) {
					$sender->sendMessage("§e[ ========== §a[ Piorun ] §e ========== ]");
					$sender->sendMessage("§7> Jest to specjalna kosc, która");
					$sender->sendMessage("§7> strzela piorunami w gracza ");
					$sender->sendMessage("§7> jezeli go uderzymy i zabiera");
					$sender->sendMessage("§7> mu przy jednym ciosie 1 serce");
                         $sender->sendMessage("§7> aby kupic, wpisz §c/piorun kup");
					$sender->sendMessage("§7> Koszt: §c20 diamentow");
					$sender->sendMessage("§e[ ========== §a[ Piorun ] §e ========== ]");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 20))){
                               $sender->getInventory()->addItem(Item::get(352, 0, 1));
                               $sender->getInventory()->removeItem(Item::get(264, 0, 20));
						$sender->sendMessage("§e• [HardPe] Zakupiles Pioruna • ");
            }
						else{
							$sender->sendMessage("§c• [HardPe] Nie posiadasz 20 diamentow! •");
							}
						return true;
                          }
	
	}
						}
					}
