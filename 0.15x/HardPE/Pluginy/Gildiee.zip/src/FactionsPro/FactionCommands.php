<?php

namespace FactionsPro;

use pocketmine\plugin\PluginBase;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\Player;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\utils\TextFormat;
use pocketmine\scheduler\PluginTask;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\Config;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\item\Item;

class FactionCommands {
	
	public $plugin;
	
	public function __construct(FactionMain $pg) {
		$this->plugin = $pg;
	}
	
	public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
		if($sender instanceof Player) {
			$player = $sender->getPlayer()->getName();
			if(strtolower($command->getName('g'))) {
				if(empty($args)) {
					$sender->sendMessage($this->plugin->formatMessage("Użyj /g pomoc, aby zobaczyć dostępne komendy gildii."));    					return true;
				}
				if(count($args == 2)) {
					
					/////////////////////////////// CREATE ///////////////////////////////
					
					if($args[0] == "stworz") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Użyj: /g stworz <nazwa>"));
							return true;
						}
						if(!(ctype_alnum($args[1]))) {
							$sender->sendMessage($this->plugin->formatMessage("Możesz jedynie użyj liter i liczb!"));
							return true;
						}
						if($this->plugin->isNameBanned($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Wystąpił błąd w nazwie gildi, zmień nazwe."));
							return true;
						}
						if($this->plugin->factionExists($args[1]) == true ) {
							$sender->sendMessage($this->plugin->formatMessage("Ta nazwa jest zajęta"));
							return true;
						}
						if(strlen($args[1]) > $this->plugin->prefs->get("MaxFactionNameLength")) {
							$sender->sendMessage($this->plugin->formatMessage("Nazwa gildi jest za krótka!"));
							return true;
						}
						if($this->plugin->isInFaction($sender->getName())) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz najpierw opuścić gildie"));
							return true;
            
						} else {
							if($sender->getInventory()->contains(Item::get(264, 0, 32))){
						    if($sender->getInventory()->contains(Item::get(265, 0, 32))){
							if($sender->getInventory()->contains(Item::get(266, 0, 32))){
						    if($sender->getInventory()->contains(Item::get(388, 0, 32))){
							$sender->getInventory()->removeItem(Item::get(264, 0, 32));
							$sender->getInventory()->removeItem(Item::get(265, 0, 32));
							$sender->getInventory()->removeItem(Item::get(266, 0, 32));
							$sender->getInventory()->removeItem(Item::get(388, 0, 32));
							$factionName = $args[1];
							$player = strtolower($player);
							$rank = "Leader";
							$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
							$stmt->bindValue(":player", $player);
							$stmt->bindValue(":faction", $factionName);
							$stmt->bindValue(":rank", $rank);
							$result = $stmt->execute();
							$sender->sendMessage($this->plugin->formatMessage("Gildia została utworzona!", true));
							return true;
							}
							else{
								$sender->sendMessage($this->plugin->formatMessage("Do założenia gildii potrzebujesz: 32 diamenty, 32 emeraldy, 32 żelaza, 32 złota"));
						   }
						}
						else{
								$sender->sendMessage($this->plugin->formatMessage("Do założenia gildii potrzebujesz: 32 diamenty, 32 emeraldy, 32 żelaza, 32 złota"));
						   }
						}
						else{
								$sender->sendMessage($this->plugin->formatMessage("Do założenia gilidii potrzebujesz: 32 diamenty, 32 emeraldy, 32 żelaza, 32 złota"));
						   }
						}
						else{
								$sender->sendMessage($this->plugin->formatMessage("Do założenia gildii potrzebujesz: 32 diamenty, 32 emeraldy, 32 żelaza, 32 złota"));
						   }
					}
					}
					
					/////////////////////////////// INVITE ///////////////////////////////
					
					if($args[0] == "zapros") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Użyj: /g zapros <nick>"));
							return true;
						}
						if(!$this->plugin->isInFaction($player)) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być w gildii by użyć tego.."));
							return true;
						}
						if(!$this->plugin->isLeader($player) && !$this->plugin->hasPermission($player, "invite")) {
							$sender->sendMessage($this->plugin->formatMessage("Nie możesz użyć tej komendy!"));
							return true;
						}
						if( $this->plugin->isFactionFull($this->plugin->getPlayerFaction($player)) ) {
							$sender->sendMessage($this->plugin->formatMessage("Gildia jest pełna! Musisz kogoś wyrzucić."));
							return true;
						}
						$invited = $this->plugin->getServer()->getPlayerExact($args[1]);
						if($this->plugin->isInFaction($invited) == true) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz jest już w gildii"));
							return true;
						}
						if(!$invited instanceof Player) {
							$sender->sendMessage($this->plugin->formatMessage("Gracza nie ma na serwerze! •"));
							return true;
						}
						$factionName = $this->plugin->getPlayerFaction($player);
						$invitedName = $invited->getName();
						$rank = "Member";
							
						$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO confirm (player, faction, invitedby, timestamp) VALUES (:player, :faction, :invitedby, :timestamp);");
						$stmt->bindValue(":player", strtolower($invitedName));
						$stmt->bindValue(":faction", $factionName);
						$stmt->bindValue(":invitedby", $sender->getName());
						$stmt->bindValue(":timestamp", time());
						$result = $stmt->execute();

						$sender->sendMessage($this->plugin->formatMessage("$invitedName został zaproszony!", true));
						$invited->sendMessage($this->plugin->formatMessage("Zostaleś zaproszony do > $factionName. Wpisz '/g akceptuj' lub '/g odrzuc' /g akceptuj = akceptowanie, /g odrzuc = odrzuć!", true));
					}
					
					/////////////////////////////// LEADER ///////////////////////////////
					
					if($args[0] == "szef") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Użyj: /g szef <nick>"));
							return true;
						}
						if(!$this->plugin->isInFaction($sender->getName())) {
							$sender->sendMessage($this->plugin->formatMessage("Nusisz być w gildii by użyć tego!"));
							return true;
						}
						if(!$this->plugin->isLeader($player)) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być leaderem by użyć tego."));
							return true;
						}
						if($this->plugin->getPlayerFaction($player) != $this->plugin->getPlayerFaction($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz dodać najpierw gracza do gildii!"));
							return true;
						}		
						if(!$this->plugin->getServer()->getPlayerExact($args[1]) instanceof Player) {
							$sender->sendMessage($this->plugin->formatMessage("Gracza nie ma na serwerze! Sprawdź później."));
							return true;
						}
							$factionName = $this->plugin->getPlayerFaction($player);
							$factionName = $this->plugin->getPlayerFaction($player);
	
							$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
							$stmt->bindValue(":player", $player);
							$stmt->bindValue(":faction", $factionName);
							$stmt->bindValue(":rank", "Member");
							$result = $stmt->execute();
	
							$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
							$stmt->bindValue(":player", strtolower($args[1]));
							$stmt->bindValue(":faction", $factionName);
							$stmt->bindValue(":rank", "Leader");
							$result = $stmt->execute();
	
	
							$sender->sendMessage($this->plugin->formatMessage("Nie jesteś już leaderem!", true));
							$this->plugin->getServer()->getPlayer($args[1])->sendMessage($this->plugin->formatMessage("Jesteś leaderem gildii $factionName!",  true));
							if($this->plugin->prefs->get("FactionNametags")) {
								$this->plugin->updateTag($sender->getName());
								$this->plugin->updateTag($this->plugin->getServer()->getPlayer($args[1])->getName());
							}
						}
					
					/////////////////////////////// PROMOTE ///////////////////////////////
					
					if($args[0] == "awans") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Uzyj: /g awans <nick>"));
							return true;
						}
						if(!$this->plugin->isInFaction($sender->getName())) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być w gildii do użycia tego!"));
							return true;
						}
						if(!$this->plugin->isLeader($player) && !$this->plugin->hasPermission($player, "promote")) {
							$sender->sendMessage($this->plugin->formatMessage("You do not have permission to do this"));
							return true;
						}
						if($this->plugin->getPlayerFaction($player) != $this->plugin->getPlayerFaction($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz musi być w Twojej gildii!"));
							return true;
						}
						if($this->plugin->isOfficer($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz jest już oficerem! "));
							return true;
						}
						$factionName = $this->plugin->getPlayerFaction($player);
						$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
						$stmt->bindValue(":player", strtolower($args[1]));
						$stmt->bindValue(":faction", $factionName);
						$stmt->bindValue(":rank", "Officer");
						$result = $stmt->execute();
						$player = $args[1];
						$sender->sendMessage($this->plugin->formatMessage("" . $player . " został oficerem!", true));
						if($player = $this->plugin->getServer()->getPlayer($args[1])) {
							$player->sendMessage($this->plugin->formatMessage("Jesteś oficerem!", true));
						}
						if($this->plugin->prefs->get("FactionNametags")) {
								$this->plugin->updateTag($player->getName());
						}
					}
					
					/////////////////////////////// DEMOTE ///////////////////////////////
					
					if($args[0] == "zabierz") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Użyj : /g zabierz <player>"));
							return true;
						}
						if($this->plugin->isInFaction($sender->getName()) == false) {
							$sender->sendMessage($this->plugin->formatMessage("You must be in a faction to use this! •"));
							return true;
						}
						if(!$this->plugin->isLeader($player) && !$this->plugin->hasPermission($player, "demote")) {
							$sender->sendMessage($this->plugin->formatMessage("You do not have permission to do this"));
							return true;
						}
						if($this->plugin->getPlayerFaction($player) != $this->plugin->getPlayerFaction($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz nie jest w tej gildii! Musisz dodać, aby użyć tą komende."));
							return true;
						}
						if(!$this->plugin->isOfficer($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Gracz jest już memberem"));
							return true;
						}
						$factionName = $this->plugin->getPlayerFaction($player);
						$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
						$stmt->bindValue(":player", strtolower($args[1]));
						$stmt->bindValue(":faction", $factionName);
						$stmt->bindValue(":rank", "Member");
						$result = $stmt->execute();
						$player = $args[1];
						$sender->sendMessage($this->plugin->formatMessage("" . $player . " has been demoted to Member.", true));
						
						if($player = $this->plugin->getServer()->getPlayer($args[1])) {
							$player->sendMessage($this->plugin->formatMessage("You were demoted to Member.", true));
						}
						if($this->plugin->prefs->get("FactionNametags")) {
							$this->plugin->updateTag($player->getName());
						}
					}
					
					/////////////////////////////// KICK ///////////////////////////////
					
					if($args[0] == "wyrzuc") {
						if(!isset($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Użyj : /g wyrzuc <player>"));
							return true;
						}
						if($this->plugin->isInFaction($sender->getName()) == false) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być w gildii, aby użyć tego!"));
							return true;
						}
						if(!$this->plugin->isLeader($player) && !$this->plugin->hasPermission($player, "kick")) {
							$sender->sendMessage($this->plugin->formatMessage("You do not have permission to do this"));
							return true;
						}
						if($this->plugin->getPlayerFaction($player) != $this->plugin->getPlayerFaction($args[1])) {
							$sender->sendMessage($this->plugin->formatMessage("Aby wyrzucić gracza, musi być on w Twojej gildii!"));
							return true;
						}
						$kicked = $this->plugin->getServer()->getPlayer($args[1]);
						$factionName = $this->plugin->getPlayerFaction($player);
						$this->plugin->db->query("DELETE FROM master WHERE player='$args[1]';");
						$sender->sendMessage($this->plugin->formatMessage("Wyrzuciłeś gracza z gildii :$args[1]!", true));
						$players[] = $this->plugin->getServer()->getOnlinePlayers();
						if(in_array($args[1], $players) == true) {
							$this->plugin->getServer()->getPlayer($args[1])->sendMessage($this->plugin->formatMessage("You have been kicked from \n $factionName!", true));
							if($this->plugin->prefs->get("FactionNametags")) {
								$this->plugin->updateTag($args[1]);
							}
							return true;
						}
					}
					
					/////////////////////////////// INFO ///////////////////////////////
					
					if(strtolower($args[0]) == 'info') {
						if(isset($args[1])) {
							if( !(ctype_alnum($args[1])) | !($this->plugin->factionExists($args[1]))) {
								$sender->sendMessage($this->plugin->formatMessage("Gildia, którą chcesz zobaczyć nie istnieje. "));
								return true;
							}
							$faction = strtolower($args[1]);
							$result = $this->plugin->db->query("SELECT * FROM motd WHERE faction='$faction';");
							$array = $result->fetchArray(SQLITE3_ASSOC);
							$message = $array["message"];
							$leader = $this->plugin->getLeader($faction);
							$numPlayers = $this->plugin->getNumberOfPlayers($faction);
							$sender->sendMessage(TextFormat::BOLD . "-------------------------");
							$sender->sendMessage("$faction");
							$sender->sendMessage(TextFormat::BOLD . "Zalozyciel: " . TextFormat::RESET . "$leader");
							$sender->sendMessage(TextFormat::BOLD . "# Osoby w gildii: " . TextFormat::RESET . "$numPlayers");
							$sender->sendMessage(TextFormat::BOLD . "MOTD: " . TextFormat::RESET . "$message");
							$sender->sendMessage(TextFormat::BOLD . "-------------------------");
						} else {
							$faction = $this->plugin->getPlayerFaction(strtolower($sender->getName()));
							$result = $this->plugin->db->query("SELECT * FROM motd WHERE faction='$faction';");
							$array = $result->fetchArray(SQLITE3_ASSOC);
							$message = $array["message"];
							$leader = $this->plugin->getLeader($faction);
							$numPlayers = $this->plugin->getNumberOfPlayers($faction);
							$sender->sendMessage(TextFormat::BOLD . "-------------------------");
							$sender->sendMessage("$faction");
							$sender->sendMessage(TextFormat::BOLD . "Zalozyciel: " . TextFormat::RESET . "$leader");
							$sender->sendMessage(TextFormat::BOLD . "# Osoby w gildii: " . TextFormat::RESET . "$numPlayers");
							$sender->sendMessage(TextFormat::BOLD . "MOTD: " . TextFormat::RESET . "$message");
							$sender->sendMessage(TextFormat::BOLD . "-------------------------");
						}
					}
					if(strtolower($args[0]) == "pomoc") {
						if(!isset($args[1]) || $args[1] == 1) {
							$sender->sendMessage(TextFormat::BLUE . "• Komendy Gildii [1/3] •" . TextFormat::RED . "\n• /g plugin - info o pluginie •\n• /g akceptuj - akceptuje zaproszenie do gildii •\n• /g dzialka - robi dzialke gildii •\n• /g stworz <nazwa> - tworzy gildie •\n• /g usun - usuwa gildie •\n• /g zabierz <nick> - odbiera oficera •\n• /g odrzuc - odrzuca zaproszenie do gildii •");
							return true;
						}
						if($args[1] == 2) {
							$sender->sendMessage(TextFormat::BLUE . "• Komendy Gildii [2/3] •" . TextFormat::RED . "\n• /g dom - tepa do domu gildii •\n• /g pomoc <strona> - strona komend gildii •\n• /g info - info o gildii •\n• /g info <gildia> - info o innej gildii •\n• /g zapros <nick> - zaprasza gracza do gildii •\n• /g wyrzuc <nick> - wyrzuca z gildii gracza •\n• /g szef <nick> - daje leadera innej osobie •\n• /g opusc - opuszcza gildie •");
							return true;
						} else {
							$sender->sendMessage(TextFormat::BLUE . "• Komendy Gildii [3/3] •" . TextFormat::RED . "\n• /g motd -  motd gildii •\n• /g awans <nick> - daje oficera •\n• /g ustawdom - ustawia dom gildii •\n• /g usundzialke - usuwa dzialke •\n• /g usundom - usuwa dom gildii •");
							return true;
						}
					}
				}
				if(count($args == 1)) {
					
					/////////////////////////////// CLAIM ///////////////////////////////
					
					if(strtolower($args[0]) == 'dzialka') {
						if($this->plugin->prefs->get("ClaimingEnabled") == false) {
							$sender->sendMessage($this->plugin->formatMessage("Robienie działki nie jest dostępne."));
							return true;
						}
						if(!$this->plugin->isInFaction($player)) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być najpierw w gildii! "));
							return true;
						}
						if(!$this->plugin->isLeader($player) && !$this->plugin->hasPermission($player, "claim")) {
							$sender->sendMessage($this->plugin->formatMessage("You do not have permission to do this"));
							return true;
						}
						if($this->plugin->inOwnPlot($sender)) {
							$sender->sendMessage($this->plugin->formatMessage("Działka Twojej gildii już istnieje. Wpisz /g usundzialke i spróbuj ponownie!"));
							return true;
           
						} else {
							if($sender->getInventory()->contains(Item::get(264, 0, 5))){
						    if($sender->getInventory()->contains(Item::get(265, 0, 5))){
							if($sender->getInventory()->contains(Item::get(266, 0, 5))){
						    if($sender->getInventory()->contains(Item::get(388, 0, 5))){
							$sender->getInventory()->removeItem(Item::get(264, 0, 5));
							$sender->getInventory()->removeItem(Item::get(265, 0, 5));
							$sender->getInventory()->removeItem(Item::get(266, 0, 5));
							$sender->getInventory()->removeItem(Item::get(388, 0, 5));
						$x = floor($sender->getX());
						$y = floor($sender->getY());
						$z = floor($sender->getZ());
						$faction = $this->plugin->getPlayerFaction($sender->getPlayer()->getName());
						if(!$this->plugin->drawPlot($sender, $faction, $x, $y, $z, $sender->getPlayer()->getLevel(), $this->plugin->prefs->get("PlotSize"))) {
							return true;
						}
						$sender->sendMessage($this->plugin->formatMessage("Działka (50x50) została założona.", true));
					}
						     else{
								$sender->sendMessage($this->plugin->formatMessage("Do założenia działki potrzebujesz: 5 diamentow, 5 emeraldow, 5 żelaza, 5 złota"));
						   }
						}
						else{
								$sender->sendMessage($this->plugin->formatMessage("Do założenia działki potrzebujesz: 5 diamentow, 5 emeraldow, 5 żelaza, 5 złota"));
						   }
						}
						else{
								$sender->sendMessage($this->plugin->formatMessage("Do założenia działki potrzebujesz: 5 diamentow, 5 emeraldow, 5 żelaza, 5 złota"));
						   }
						}
						else{
								$sender->sendMessage($this->plugin->formatMessage("Do założenia działki potrzebujesz: 5 diamentow, 5 emeraldow, 5 żelaza, 5 złota"));
						   }
					}
					}
					 					
					/////////////////////////////// UNCLAIM ///////////////////////////////
					
					if(strtolower($args[0]) == "usundzialke") {
						if($this->plugin->prefs->get("ClaimingEnabled") == false) {
							$sender->sendMessage($this->plugin->formatMessage("Plots are not enabled on this server."));
							return true;
						}
						if(!$this->plugin->isLeader($player) && !$this->plugin->hasPermission($player, "unclaim")) {
							$sender->sendMessage($this->plugin->formatMessage("You do not have permission to do this"));
							return true;
						}
						$faction = $this->plugin->getPlayerFaction($sender->getName());
						$this->plugin->db->query("DELETE FROM plots WHERE faction='$faction';");
						$sender->sendMessage($this->plugin->formatMessage("Działka usunięta.", true));
					}
					
					/////////////////////////////// MOTD ///////////////////////////////
					
					if(strtolower($args[0]) == "motd") {
						if($this->plugin->isInFaction($sender->getName()) == false) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być w gildii, aby użyć tego!"));
							return true;
						}
						if(!$this->plugin->isLeader($player) && !$this->plugin->hasPermission($player, "motd")) {
							$sender->sendMessage($this->plugin->formatMessage("You do not have permission to do this"));
							return true;
						}
						$sender->sendMessage($this->plugin->formatMessage("Type your message in chat. It will not be visible to other players", true));
						$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO motdrcv (player, timestamp) VALUES (:player, :timestamp);");
						$stmt->bindValue(":player", strtolower($sender->getName()));
						$stmt->bindValue(":timestamp", time());
						$result = $stmt->execute();
					}
					
					/////////////////////////////// ACCEPT ///////////////////////////////
					
					if(strtolower($args[0]) == "akceptuj") {
						$player = $sender->getName();
						$lowercaseName = strtolower($player);
						$result = $this->plugin->db->query("SELECT * FROM confirm WHERE player='$lowercaseName';");
						$array = $result->fetchArray(SQLITE3_ASSOC);
						if(empty($array) == true) {
							$sender->sendMessage($this->plugin->formatMessage("Nie posiadasz zaproszeń do gildii!"));
							return true;
						}
						$invitedTime = $array["timestamp"];
						$currentTime = time();
						if(($currentTime - $invitedTime) <= 60) { //This should be configurable
							$faction = $array["faction"];
							$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO master (player, faction, rank) VALUES (:player, :faction, :rank);");
							$stmt->bindValue(":player", strtolower($player));
							$stmt->bindValue(":faction", $faction);
							$stmt->bindValue(":rank", "Member");
							$result = $stmt->execute();
							$this->plugin->db->query("DELETE FROM confirm WHERE player='$lowercaseName';");
							$sender->sendMessage($this->plugin->formatMessage("Pomyślnie dołączyłeś do gildii > $faction!", true));
							if($this->plugin->getServer()->getPlayer($array["invitedby"])) {
								if($this->plugin->getServer()->getPlayer($array["invitedby"])) {
									$this->plugin->getServer()->getPlayer($array["invitedby"])->sendMessage($this->plugin->formatMessage("$player dołączył do gildii!", true));
								}
							}
							if($this->plugin->prefs->get("FactionNametags")) {
								$this->plugin->updateTag($sender->getName());
							}
						} else {
							$sender->sendMessage($this->plugin->formatMessage("Invite has timed out!"));
							$this->plugin->db->query("DELETE FROM confirm WHERE player='$lowercaseName';");
						}
					}
					
					/////////////////////////////// DENY ///////////////////////////////
					
					if(strtolower($args[0]) == "odrzuc") {
						$player = $sender->getName();
						$lowercaseName = strtolower($player);
						$result = $this->plugin->db->query("SELECT * FROM confirm WHERE player='$lowercaseName';");
						$array = $result->fetchArray(SQLITE3_ASSOC);
						if(empty($array) == true) {
							$sender->sendMessage($this->plugin->formatMessage("Nie masz zaproszenia do żadnej gildii!"));
							return true;
						}
						$invitedTime = $array["timestamp"];
						$currentTime = time();
						if( ($currentTime - $invitedTime) <= 60 ) { //This should be configurable
							$this->plugin->db->query("DELETE FROM confirm WHERE player='$lowercaseName';");
							$sender->sendMessage($this->plugin->formatMessage("Invite declined!", true));
							$this->plugin->getServer()->getPlayerExact($array["invitedby"])->sendMessage($this->plugin->formatMessage("$player declined the invite!"));
						} else {
							$sender->sendMessage($this->plugin->formatMessage("Invite has timed out!"));
							$this->plugin->db->query("DELETE FROM confirm WHERE player='$lowercaseName';");
						}
					}
					
					/////////////////////////////// DELETE ///////////////////////////////
					
					if(strtolower($args[0]) == "usun") {
						if($this->plugin->isInFaction($player) == true) {
							if($this->plugin->isLeader($player)) {
								$faction = $this->plugin->getPlayerFaction($player);
                                  $this->plugin->db->query("DELETE FROM plots WHERE faction='$faction';");
								$this->plugin->db->query("DELETE FROM master WHERE faction='$faction';");
								$sender->sendMessage($this->plugin->formatMessage("Gildia oraz jej dzialka została usunięta!", true));
								if($this->plugin->prefs->get("FactionNametags")) {
									$this->plugin->updateTag($sender->getName());
								}
							} else {
								$sender->sendMessage($this->plugin->formatMessage("Musisz być leaderem, by usunąć!"));
							}
						} else {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być w gildii!"));
						}
					}
					
					/////////////////////////////// LEAVE ///////////////////////////////
					
					if(strtolower($args[0] == "opusc")) {
						if($this->plugin->isLeader($player) == false) {
							$remove = $sender->getPlayer()->getNameTag();
							$faction = $this->plugin->getPlayerFaction($player);
							$name = $sender->getName();
							$this->plugin->db->query("DELETE FROM master WHERE player='$name';");
							$sender->sendMessage($this->plugin->formatMessage("Opuściłeś/aś gildię > $faction", true));
							if($this->plugin->prefs->get("FactionNametags")) {
								$this->plugin->updateTag($sender->getName());
							}
						} else {
							$sender->sendMessage($this->plugin->formatMessage("Musisz usunąć /oddać komuś gildie!"));
						}
					}
					
					/////////////////////////////// SETHOME ///////////////////////////////
					
					if(strtolower($args[0] == "ustawdom")) {
						if(!$this->plugin->isInFaction($player)) {
							$sender->sendMessage($this->plugin->formatMessage("Musisz być w gildii, aby użyć tego."));
							return true;
						}
						if(!$this->plugin->isLeader($player) && !$this->plugin->hasPermission($player, "sethome")) {
							$sender->sendMessage($this->plugin->formatMessage("You do not have permission to do this"));
							return true;
						}
						$factionName = $this->plugin->getPlayerFaction($sender->getName());
						$stmt = $this->plugin->db->prepare("INSERT OR REPLACE INTO home (faction, x, y, z, world) VALUES (:faction, :x, :y, :z, :world);");
						$stmt->bindValue(":faction", $factionName);
						$stmt->bindValue(":x", $sender->getX());
						$stmt->bindValue(":y", $sender->getY());
						$stmt->bindValue(":z", $sender->getZ());
						$stmt->bindValue(":world", $sender->getLevel()->getName());
						$result = $stmt->execute();
						$sender->sendMessage($this->plugin->formatMessage("Dom gildii został stworzony!", true));
					}
					
					/////////////////////////////// UNSETHOME ///////////////////////////////
						
					if(strtolower($args[0] == "usundom")) {
						if(!$this->plugin->isInFaction($player)) {
							$sender->sendMessage($this->plugin->formatMessage("musisz być w gildii."));
							return true;
						}
						if(!$this->plugin->isLeader($player) && !$this->plugin->hasPermission($player, "unsethome")) {
							$sender->sendMessage($this->plugin->formatMessage("You do not have permission to do this"));
							return true;
						}
						$faction = $this->plugin->getPlayerFaction($sender->getName());
						$this->plugin->db->query("DELETE FROM home WHERE faction = '$faction';");
						$sender->sendMessage($this->plugin->formatMessage("Dom usunięty!", true));
					}
					
					/////////////////////////////// HOME ///////////////////////////////
						
					if(strtolower($args[0] == "dom")) {
						if(!$this->plugin->isInFaction($player)) {
							$sender->sendMessage($this->plugin->formatMessage("You must be in a faction to do this."));
						}
						if(!$this->plugin->isLeader($player) && !$this->plugin->hasPermission($player, "home")) {
							$sender->sendMessage($this->plugin->formatMessage("You do not have permission to do this"));
							return true;
						}
						$faction = $this->plugin->getPlayerFaction($sender->getName());
						$result = $this->plugin->db->query("SELECT * FROM home WHERE faction = '$faction';");
						$array = $result->fetchArray(SQLITE3_ASSOC);
						if(!empty($array)) {
							$world = $this->plugin->getServer()->getLevelByName($array['world']);
+							$sender->getPlayer()->teleport(new Position($array['x'], $array['y'], $array['z'], $world));
							$sender->sendMessage($this->plugin->formatMessage("Za chwile nastąpi teleportacja do home gildii...", true));
							return true;
						} else {
							$sender->sendMessage($this->plugin->formatMessage("Home tej gildii nie został ustawiony!"));
							}
						}
					
					/////////////////////////////// ABOUT ///////////////////////////////
					
					if(strtolower($args[0] == "plugin")) {
						$sender->sendMessage("§aGildie HardPe§c v2.0.0");
					}
				}
			}
		} else {
			$this->plugin->getServer()->getLogger()->info($this->plugin->formatMessage("Please run command in game"));
		}
	}
}
