<?php

namespace vip;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("vip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "vip"){
      $sender->sendMessage("§a[----------------§b[VIP]§a---------------]");
      $sender->sendMessage("§a> Wyslij sms o tresci§c DOGRY§a pod numer§c 74550§a <");
      $sender->sendMessage("§a> §aKoszt: §c4,92 zl§a, kod podaj§c Marttinkowi§a <");
      $sender->sendMessage("§a> Co otrzymuje §bVIP?§a: Komendy: /time set day/night <");
      $sender->sendMessage("§a> /kit vip a w nim znajduje sie: <");
      $sender->sendMessage("§a> Zelazny set, luk, 64 strzaly, zelazne narzedzia <");
      $sender->sendMessage("§a> 2 Refile, 8 diamentów, 8 zlota, 8 zelaza, 8 emeraldow <");
      $sender->sendMessage("§a> Mozliwosc pisania na kolorowo <");
      $sender->sendMessage("§a> Ranga jest do konca edycji! <");
      $sender->sendMessage("§a[----------------§b[VIP]§a---------------]");
       return true;
   }

}
}
