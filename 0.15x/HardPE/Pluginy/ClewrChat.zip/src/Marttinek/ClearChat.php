<?php

namespace Marttinek;

use pocketmine\plugin\PluginBase;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\utils\TextFormat;

class ClearChat extends PluginBase {
	
	public function onEnable(){
		$this->getLogger()->info("Loaded!");
	}
	public function onDisable(){
		$this->getLogger()->info("Disabled!");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		if($command->getName()=="wyczysc")
		{
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
               $this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
               $this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
               $this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
               $this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'');
			$this->getServer()->broadcastMessage(TextFormat::YELLOW .'• Czat zostal wyczyszczony! •');
		}
	}
}
