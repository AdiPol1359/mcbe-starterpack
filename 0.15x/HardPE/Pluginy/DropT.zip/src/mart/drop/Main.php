<?php

namespace mart\drop;

use pocketmine\plugin\PluginBase as P;
use pocketmine\event\Listener as L;
use pocketmine\utils\TextFormat;
use pocketmine\event\block\BlockBreakEvent as BBL;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\item\Item;

class Main extends P implements L{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
		$this->saveDefaultConfig();
		$this->getServer()->getLogger()->info(TextFormat::YELLOW."Enabled.. !");
	}

	public function onBreak(BBL $e){

/*
*
public function onBreak(BBL $e){

/*


$zelazo = Item::get("15");
$zloto = Item::get("14");
$wegiel = Item::get("16");
$diax = Item::get("56");
$redstone = Item::get("73");
$snowball = Item::get("78");

*/


if($e->getBlock()->getID() == 15){
$e->setDrops(array(Item::get(0)));
}

if($e->getBlock()->getID() == 14){
$e->setDrops(array(Item::get(0)));
}

if($e->getBlock()->getID() == 16){
$e->setDrops(array(Item::get(0)));
}

if($e->getBlock()->getID() == 56){
$e->setDrops(array(Item::get(0)));
}

if($e->getBlock()->getID() == 73){
$e->setDrops(array(Item::get(0)));
}

if($e->getBlock()->getID() == 78){
$e->setDrops(array(Item::get(0)));
}


if($e->getBlock()->getId() == 1 && mt_rand(1,$this->getConfig()->get("t6-chance")) == "1"){
			$p = $e->getPlayer();
			$p->sendMessage("§e• [Drop] Znalazłeś (1) obsydian •");
			foreach($this->getConfig()->get("t6-loot") as $loot){
					$p->getInventory()->addItem(Item::get($loot,1,mt_rand(1,$this->getConfig()->get("t6-item-max"))));
			}
		}
		else{
          }
if($e->getBlock()->getId() == 1 && mt_rand(1,$this->getConfig()->get("t7-chance")) == "1"){
			$p = $e->getPlayer();
			$p->sendMessage("§e• [Drop] Znalazłeś (1) żelazo •");
			foreach($this->getConfig()->get("t7-loot") as $loot){
					$p->getInventory()->addItem(Item::get($loot,1,mt_rand(1,$this->getConfig()->get("t7-item-max"))));
			}
		}
		else{
          }
if($e->getBlock()->getId() == 1 && mt_rand(1,$this->getConfig()->get("t8-chance")) == "1"){
			$p = $e->getPlayer();
			$p->sendMessage("§e• [Drop] Znalazłeś (1) zloto •");
			foreach($this->getConfig()->get("t8-loot") as $loot){
					$p->getInventory()->addItem(Item::get($loot,1,mt_rand(1,$this->getConfig()->get("t8-item-max"))));
			}
		}
		else{
          }
if($e->getBlock()->getId() == 1 && mt_rand(1,$this->getConfig()->get("t9-chance")) == "1"){
			$p = $e->getPlayer();
			$p->sendMessage("§e• [Drop] Znalazłeś (1) diament •");
			foreach($this->getConfig()->get("t9-loot") as $loot){
					$p->getInventory()->addItem(Item::get($loot,1,mt_rand(1,$this->getConfig()->get("t9-item-max"))));
			}
		}
		else{
          }
if($e->getBlock()->getId() == 1 && mt_rand(1,$this->getConfig()->get("t10-chance")) == "1"){
			$p = $e->getPlayer();
			$p->sendMessage("§e• [Drop] Znalazłeś (1) węgiel •");
			foreach($this->getConfig()->get("t10-loot") as $loot){
					$p->getInventory()->addItem(Item::get($loot,1,mt_rand(1,$this->getConfig()->get("t10-item-max"))));
			}
		}
		else{
          }
if($e->getBlock()->getId() == 1 && mt_rand(1,$this->getConfig()->get("t11-chance")) == "1"){
			$p = $e->getPlayer();
			$p->sendMessage("§e• [Drop] Znalazłeś (1) redstone •");
			foreach($this->getConfig()->get("t11-loot") as $loot){
					$p->getInventory()->addItem(Item::get($loot,1,mt_rand(1,$this->getConfig()->get("t11-item-max"))));
			}
		}
		else{
          }
	}
}
