# HelpModifier
Modify The /help Command!


#10 pages, with 10 messages per page!
