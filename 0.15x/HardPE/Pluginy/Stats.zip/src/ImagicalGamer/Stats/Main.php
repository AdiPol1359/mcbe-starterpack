<?php
namespace ImagicalGamer\Stats;
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\command\{Command, CommandSender};
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\level\particle\Particle;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as C;
use pocketmine\utils\Config;
class Main extends PluginBase implements Listener{

  public function onEnable(){
          $this->getServer()->getPluginManager()->registerEvents($this, $this);
          $this->saveResource("kills.yml");
          $this->saveResource("deaths.yml");
          @mkdir($this->getDataFolder());
          $killfile = new Config($this->getDataFolder() . "/kills.yml", Config::YAML);
          $killfile->save();
          $deathfile = new Config($this->getDataFolder() . "/deaths.yml", Config::YAML);
          $deathfile->save();
          $this->getLogger()->info(C::GREEN . "Enabled!");
  }
  public function onDeath(PlayerDeathEvent $event){
    $deathdata = new Config($this->getDataFolder() . "/deaths.yml", Config::YAML);
    $killdata = new Config($this->getDataFolder() . "/kills.yml", Config::YAML);
    $entity = $event->getEntity();
    $cause = $entity->getLastDamageCause();
        $killer = $cause->getDamager();
    if($entity instanceof Player){
        $name = $event->getEntity()->getName();
        $deaths = $deathdata->get($name);
        $deathdata->set($name,$deaths+1);
        $deathdata->save();
    }
    if($killer instanceof Player){
      $name = $killer->getName();
      $kills = $killdata->get($name);
      $killdata->set($name,$kills+1);
      $killdata->save();
    }
  }
  public function onCommand(CommandSender $s, Command $cmd, $label, array $args){
        if($cmd->getName() == "statystyki"){
          if($s instanceof Player){
          if(count($args) == 0) {
            $killfile = new Config($this->getDataFolder() . "/kills.yml", Config::YAML);
            $kills = $killfile->get($s->getName());
            $deathfile = new Config($this->getDataFolder() . "/deaths.yml", Config::YAML);
            $deaths = $deathfile->get($s->getName());
            $stats = C::GREEN . "Twoje statystyki!" . C::RESET . C::GREEN . "\nZabojstwa: " . $kills . "\nSmierci: " . $deaths;
            $s->sendMessage($stats);
          }
          if(count($args) == 1){
            $player = $args[0];
            $killfile = new Config($this->getDataFolder() . "/kills.yml", Config::YAML);
            $kills = $killfile->get($player);
            $deathfile = new Config($this->getDataFolder() . "/deaths.yml", Config::YAML);
            $deaths = $deathfile->get($player);
            $stats = C::GREEN . $args[0] . "''" . C::RESET . C::GREEN . "\nZabojstwa: " . $kills . "\nSmierci: " . $deaths;
            $s->sendMessage($stats);
          }
        }
      }
}
}
