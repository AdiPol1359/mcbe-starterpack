# BanSystem

By: randy128gamer, xXSuperFrostyXx

A ban system that allows to temporarily/permanently ban/mute/block and kick players/IP address.