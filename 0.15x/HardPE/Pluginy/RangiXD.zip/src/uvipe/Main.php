<?php

namespace uvipe;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("svip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "rangi"){
      $sender->sendMessage("§a[----------------§c[§cRangi]§a---------------]");
      $sender->sendMessage("§a> /vip - ranga vip! <");
      $sender->sendMessage("§a> /svip - ranga svip <");
      $sender->sendMessage("§a> /sponsor - ranga sponsor! <");
      $sender->sendMessage("§a[----------------§c[§cRangi]§a---------------]");
       return true;
   }

}
}
