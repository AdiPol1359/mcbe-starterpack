<?php

namespace DirtexKUPA;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info("PiorunKUP Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('exp'))) {
				if(empty($args)) {
					$sender->sendMessage("§7[ ========== §a[ EXP ] §7 ========== ]");
					$sender->sendMessage("§7> Jest to dodatek, który umozliwia zakup");
					$sender->sendMessage("§7> zakup expa Komenda! ");
					$sender->sendMessage("§7> Kupujac exp dostajesz 10000 punktów, ");
					$sender->sendMessage("§7> czyli tyle tych zielonych kuleczek, co");
                         $sender->sendMessage("§7> przykladowo dostaniemy wykopujac wegiel");
                         $sender->sendMessage("§7> Aby zakupic wpisz §c/exp kup");
					$sender->sendMessage("§7> Koszt: §c5 diamentow");
					$sender->sendMessage("§7[ ========== §a[ EXP ] §7 ========== ]");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 5))){
                               $sender->addExperience(10000);
                               $sender->getInventory()->removeItem(Item::get(264, 0, 5));
						$sender->sendMessage("§e• [ EXP ] Zakupiles pomyślnie •");
            }
						else{
							$sender->sendMessage("§c• [HardPe] Nie posiadasz 5 diamentow! •");
							}
						return true;
                          }
	
	}
						}
					}
