<?php

namespace perly;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info("Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('enderperly'))) {
				if(empty($args)) {
					$sender->sendMessage("§7[ ========== §aEnderPerly§7 ==========]");
					$sender->sendMessage("§7> Aby kupic §c5 perel§7 wpisz:"); 
					$sender->sendMessage("§7> /perly kup §7Koszt: 10 emeraldow");
					$sender->sendMessage("§7[ ========== §aEnderPerly§7 ========== ]");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(388, 0, 10))){
						$sender->getInventory()->addItem(Item::get(332, 0, 5));
						 $sender->getInventory()->removeItem(Item::get(388, 0, 10));
						$sender->sendMessage("§a• [HardPe] Zakupiłeś 5 enderperel •");
            }
						else{
							$sender->sendMessage("§c• [HardPe] potrzebujesz 10 emeraldow •");
							}
						return true;
                          }
	
	}
						}
					}
