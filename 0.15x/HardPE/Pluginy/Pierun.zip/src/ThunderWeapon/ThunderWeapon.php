<?php

namespace ThunderWeapon;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\permission\ServerOperator;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\level\Level;
use pocketmine\entity\Entity;
use pocketmine\utils\Config;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\MovePlayerPacket;
use pocketmine\network\protocol\MoveEntityPacket;

class ThunderWeapon extends PluginBase implements Listener {
const NETWORK_ID = 93;

        public function onEnable(){
		$plugin = "ThunderWeapon";
		$this->getLogger()->info("§b".$plugin."§f I read the §f !§6By Ziken");
		if(!file_exists($this->getDataFolder())){@mkdir($this->getDataFolder(), 0744, true);}
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->I = new Config($this->getDataFolder() . "config.yml", Config::YAML,array("Damage" => 1,"Fire" => 0,"ID" => 352,));
	}


public function onEntityDamageByEntity(EntityDamageEvent $event){
	if ($event instanceof EntityDamageByEntityEvent) {
		$entity = $event->getEntity();
		$player = $event->getDamager();
		if ($entity instanceof Player and $player instanceof Player) {
			$item = $player->getInventory()->getItemInHand()->getID();
			$id = $this->I->get("ID");
			if ($item == $id) {
				$d = $this->I->get("Damage");
				$f = $this->I->get("Fire");
				$Online = Server::getInstance()->getOnlinePlayers();
				$light = new AddEntityPacket();
				$light->type = 93;
				$light->eid = Entity::$entityCount++;
				$light->metadata = array();
				$light->speedX = 0;
				$light->speedY = 0;
				$light->speedZ = 0;
 				$light->yaw = $entity->getYaw();
				$light->pitch = $entity->getPitch();
				$light->x = $entity->x;
				$light->y = $entity->y;
				$light->z = $entity->z;
				Server::broadcastPacket($Online,$light);
				$event->setDamage($d);
				$entity->setOnFire($f);
				}
			}
		}
	}
}
