<?php

  namespace HelpModifier;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pockemine\inventory\Inventory;

  class Main extends PluginBase implements Listener {


    public function onEnable() {

      $this->getServer()->getPluginManager()->registerEvents($this, $this);

    }

    public function sendHelp(PlayerCommandPreprocessEvent $event) {

      $command = explode(" ", strtolower($event->getMessage()));

      $player = $event->getPlayer();

      if($command[0] === "/spawn") {
		  $event->setCancelled();
		  $player->sendMessage("§cAby przeteleportowac sie na spawn wpisz §a/sp§c!");
	  }
	}
 public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
	    $player = $sender->getPlayer();
			if(strtolower($command->getName('sp'))) {
				if($sender->getInventory()->contains(Item::get(41, 0, 1)) or $sender->hasPermission("spawn.komenda")) {
				if($sender->getInventory()->contains(Item::get(280, 0, 1)) or $sender->hasPermission("spawn.komenda")) {
				if($sender->getInventory()->contains(Item::get(332, 0, 1)) or $sender->hasPermission("spawn.komenda")) {
					$sender->getInventory()->removeItem(Item::get(332, 0, 1));
					$sender->getInventory()->removeItem(Item::get(288, 0, 1));
					$sender->getInventory()->removeItem(Item::get(41, 0, 1));
					 $player->teleport(new Position(-295,73,503, $this->getServer()->getLevelByName("world")));
					 $sender->sendMessage("§f• §7Teleportuje na spawn§7... §f•");
           }
		   else {
			   $sender->sendMessage("§f• §cPotrzebujesz 1 Blok złota, 1 patyk oraz 1 perłe aby przeteleportować sie na spawn! §f•");
		   }
			           }
		   else {
			   $sender->sendMessage("§f• §cPotrzebujesz 1 Blok złota, 1 patyk oraz 1 perłe aby przeteleportować sie na spawn! §f•");
		   }
		              }
		   else {
			   $sender->sendMessage("§f• §cPotrzebujesz 1 Blok złota, 1 patyk oraz 1 perłe aby przeteleportować sie na spawn! §f•");
		   }
	  	}
 }
  }
