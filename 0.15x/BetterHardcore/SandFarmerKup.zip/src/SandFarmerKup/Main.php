<?php

namespace SandFarmerKup;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info("BOYFARMERKUP Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('sandfarmer'))) {
				if(empty($args)) {
					$sender->sendMessage("§7[ ========== §aSandFarmer§7 ========== ]");
					$sender->sendMessage("§7Co to SandFarmer?");
					$sender->sendMessage("§o§a  * Jest to blok ktory po postawieniu tworzy piasek 70 kratek w dol");
					$sender->sendMessage("§7Aby kupic wpisz:");
					$sender->sendMessage("§o§a  * /sandfarmer kup §6- §o§cKoszt: 5 diamenty i 3 piasku");
					$sender->sendMessage("§7[ ========== §aSandFarmer§7 ========== ]");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 5))){
					 if($sender->getInventory()->contains(Item::get(12, 0, 3))){
						$sender->getInventory()->addItem(Item::get(120, 0, 1));
						 $sender->getInventory()->removeItem(Item::get(264, 0, 5));
						 $sender->getInventory()->removeItem(Item::get(12, 0, 3));
						$sender->sendMessage("§e[ SandFarmer ] Zakupiłeś §cSandFarmera'a");
						}
						else{
							$sender->sendMessage("§cNiemasz tyle potrzebnych itemów, potrzebujesz: 5 diamentów i 3 piasku");
							}
						}
						else{
							$sender->sendMessage("§cNiemasz tyle potrzebnych itemów, potrzebujesz: 3 diamentów i 3 piasku");
							}
						return true;
                          }
	
	}
						}
					}