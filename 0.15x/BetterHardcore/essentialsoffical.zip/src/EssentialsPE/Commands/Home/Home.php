<?php
namespace EssentialsPE\Commands\Home;

use EssentialsPE\BaseFiles\BaseCommand;
use EssentialsPE\Loader;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;

class Home extends BaseCommand{
    /**
     * @param Loader $plugin
     */
    public function __construct(Loader $plugin){
        parent::__construct($plugin, "home", "Teleport to your home", "/home <name>", false, ["homes"]);
        $this->setPermission("essentials.home.use");
    }

    /**
     * @param CommandSender $sender
     * @param string $alias
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, $alias, array $args){
        if(!$this->testPermission($sender)){
            return false;
        }
        if(!$sender instanceof Player){
            $sender->sendMessage($this->getConsoleUsage());
            return false;
        }
        if(count($args) > 1){
            $sender->sendMessage(TextFormat::RED . $this->getUsage());
            return false;
        }
        if($alias === "homes" || count($args) === 0){
            if(($list = $this->getPlugin()->homesList($sender, false)) === false){
                $sender->sendMessage(TextFormat::AQUA . "§8• §8[§cBŁĄD§8] §cNiemasz żadnych domów!! §8•");
                return false;
            }
            $sender->sendMessage(TextFormat::AQUA . "§3Twoje domy: \n" . $list);
            return true;
        }
        $home = $this->getPlugin()->getHome($sender, $args[0]);
        if(!$home){
            $sender->sendMessage(TextFormat::RED . "§8• §8[§cBŁĄD§8] §cDom o takiej nazwie nie istnieje albo jest niedostepny w tym świecie! §8•");
            return false;
        }
        else {
				if($sender->getInventory()->contains(Item::get(41, 0, 1)) or $sender->hasPermission("spawn.komenda")) {
				if($sender->getInventory()->contains(Item::get(280, 0, 1)) or $sender->hasPermission("spawn.komenda")) {
				if($sender->getInventory()->contains(Item::get(332, 0, 1)) or $sender->hasPermission("spawn.komenda")) {
					$sender->getInventory()->removeItem(Item::get(332, 0, 1));
					$sender->getInventory()->removeItem(Item::get(288, 0, 1));
					$sender->getInventory()->removeItem(Item::get(41, 0, 1));
        $sender->teleport($home);
        $sender->sendMessage("§8• §8[§cBH§8] §cTeleportacja do domu... §8•");
        return true;
				} 
						else {
							$sender->sendMessage("§cAby przeteleportowac sie na swoj dom potrzebujesz: 1 Blok złota, 1 Patyk oraz 1 Perle!");
						}
						} 
						else {
							$sender->sendMessage("§cAby przeteleportowac sie na swoj dom potrzebujesz: 1 Blok złota, 1 Patyk oraz 1 Perle!");
						} 
						} 
						else {
							$sender->sendMessage("§cAby przeteleportowac sie na swoj dom potrzebujesz: 1 Blok złota, 1 Patyk oraz 1 Perle!");
						}
    }
	}
} 
