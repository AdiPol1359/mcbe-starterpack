<?php

namespace DirtexKUP;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info("DirtexKUP Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('cobblex'))) {
				if(empty($args)) {
					$sender->sendMessage("§7[ ---------- §aCobbleX§7 ---------- ]");
					$sender->sendMessage("§7Co to CobbleX?");
					$sender->sendMessage("§o§a  * Jest to blok ktory po postawieniu daje losowe");
					$sender->sendMessage("§o§a  * itemy (czasami mozna wylosowac NIC):");
					$sender->sendMessage("§7Aby kupic wpisz:");
					$sender->sendMessage("§o§a  * /cobblex kup §6- §o§cKoszt: 9 stakow cobblestona");
					$sender->sendMessage("§7[ ---------- §aCobbleX§7 ---------- ]");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(4, 0, 576))){
						 $sender->getInventory()->removeItem(Item::get(4, 0, 576));
						$sender->getInventory()->addItem(Item::get(129, 0, 1));
						$sender->sendMessage("§8[ §eCobbleX §8] §7Zakupiłeś §cCobbleX");
            }
						else{
							$sender->sendMessage("§8[§eCobbleX§8] §7Nie posiadasz tyle §cBruku!");
                                                }
                                         }
                        }
  }
}


