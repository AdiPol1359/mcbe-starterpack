<?php

namespace sprawdzanie;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;

use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;

use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pockemine\inventory\Inventory;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("Sprawdzanie-Tp loaded");
		 $this->getServer()->loadLevel("world");
		}
	
  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('czysty'))) {
							    if(count($args) == 1) {
			   					 			   $player = $args[0];
			   $this->getServer()->broadcastMessage("§f• §7Gracz§c " . $player . " §7okazał się być LEGIT! §f•");
			   $player = $args[0];
			   $player = $this->getServer()->getPlayer($args[0]);
			   $tp = $this->getSession($player)->getLastPosition();
			   $player->teleport($tp);
			   $player->sendMessage("§cOkazales sie byc czysty!");
					}
					else {
				$sender->sendMessage("§f• §cPoprawne uzycie to: /czysty <nick> §f•");
			}
			}
}
}