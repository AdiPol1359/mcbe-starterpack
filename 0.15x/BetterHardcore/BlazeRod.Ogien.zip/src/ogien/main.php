<?php

namespace ogien;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;

use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;

use pocketmine\item\Item;
use pocketmine\Player;
use pockemine\inventory\Inventory;

use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerItemHeldEvent;

use pocketmine\entity\Living;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\entity\Entity;

use pocketmine\level\particle\CriticalParticle;
use pocketmine\Server;

class main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("BlazeRod FireAspect Loaded");
		}
		
		  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
	   $name = $sender->getPlayer()->getName();
	
			if(strtolower($command->getName('ogien'))) {
				if(empty($args)) {
					$sender->sendMessage("§c[§e---------§c[Ogien]§e---------§e]");
					$sender->sendMessage("§6* §7Jest to dodatek ktory dodaje mozliwosc");
					$sender->sendMessage("§6* §7podpalania ofiar, dziala to tylko na");
					$sender->sendMessage("§6* §7miecze(Nie działa na ZŁOTY). Aby kupic wpisz /ogien kup");
					$sender->sendMessage("§6* §7Koszt: 64 butelki exp'a i 32 diamenty");
					$sender->sendMessage("§c[§e---------§c[Ogien]§e---------§e]");
					return true;
			   	 }
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(384, 0, 64))){
					 if($sender->getInventory()->contains(Item::get(264, 0, 32))){
					 $sender->getInventory()->removeItem(Item::get(384, 0, 64));
					 $sender->getInventory()->removeItem(Item::get(264, 0, 32));
					 $sender->getInventory()->addItem(Item::get(369, 0, 1));
					 $sender->sendMessage("§e Zakupiłeś ogień, gratulacje!");
					 }
					 else{
					 $sender->sendMessage("§e• Niestac cię potrzebujesz 64 butelki exp'a i 32 diamenty");
					 }
					 }
					 else{
				   $sender->sendMessage("§e• Niestac cię potrzebujesz 64 butelki exp'a i 32 diamenty");
					 }
           }
			
	  	}
		}
		
	    public function onFight(EntityDamageEvent $event) {  
      if($event instanceof EntityDamageByEntityEvent && $event->getDamager() instanceof Player) {
        $hit = $event->getEntity();
        $damager = $event->getDamager();
         if($damager->getInventory()->getItemInHand()->getId() == 267) {
		     if($damager->getInventory()->contains(Item::get(369,0,1))){
            $x = $hit->x;
            $y = $hit->y;
            $z = $hit->z;
            $hitpos = $hit->getPosition(new Vector3($x, $y, $z));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->setOnFire(14);
          }
        else{
	      }
       }
       else{
       }
      }
    }
        public function onFight2(EntityDamageEvent $event2) {  
      if($event2 instanceof EntityDamageByEntityEvent && $event2->getDamager() instanceof Player) {
        $hit = $event2->getEntity();
        $damager = $event2->getDamager();
         if($damager->getInventory()->getItemInHand()->getId() == 268) {
		     if($damager->getInventory()->contains(Item::get(369,0,1))){
            $x = $hit->x;
            $y = $hit->y;
            $z = $hit->z;
            $hitpos2 = $hit->getPosition(new Vector3($x, $y, $z));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->setOnFire(14);
          }
          else{
	        }
        }
        else{
        }
      }
    }
        public function onFight3(EntityDamageEvent $event3) {  
      if($event3 instanceof EntityDamageByEntityEvent && $event3->getDamager() instanceof Player) {
        $hit = $event3->getEntity();
        $damager = $event3->getDamager();
         if($damager->getInventory()->getItemInHand()->getId() == 272) {
		     if($damager->getInventory()->contains(Item::get(369,0,1))){
            $x = $hit->x;
            $y = $hit->y;
            $z = $hit->z;
            $hitpos = $hit->getPosition(new Vector3($x, $y, $z));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->setOnFire(14);
          }
          else{
         }
        }
        else{
        }
      }
    }
        public function onFight4(EntityDamageEvent $event4) {  
      if($event4 instanceof EntityDamageByEntityEvent && $event4->getDamager() instanceof Player) {
        $hit = $event4->getEntity();
        $damager = $event4->getDamager();
         if($damager->getInventory()->getItemInHand()->getId() == 276) {
		     if($damager->getInventory()->contains(Item::get(369,0,1))){
            $x = $hit->x;
            $y = $hit->y;
            $z = $hit->z;
            $hitpos = $hit->getPosition(new Vector3($x, $y, $z));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->getLevel()->addParticle(new CriticalParticle(new Vector3($x, $y, $z)));
            $hit->setOnFire(14);
          }
          else{
         }
        }
        else{
       }
      }
    }
}