<?php

namespace svip;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("svip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "svip"){
      $sender->sendMessage("§l§8 [§7-----------§a[SVIP]§7-----------§8]");
      $sender->sendMessage(" §a* §7Jak kupic range §aSVIP? ");
      $sender->sendMessage(" §a* §7Wyslij SMS'a o tresci §aAP.HOSTMC §7na numer §a91058");
      $sender->sendMessage(" §a* §7Calkowity koszt rangi to §a12,30§7zl.");
      $sender->sendMessage(" §a* §7Co posiada ranga §aSVIP§7?");
	  $sender->sendMessage(" §a* §7- §aPrzywileje vipa (prócz kita) ");
	  $sender->sendMessage(" §a* §7- §aDrop 10% powiekszony");
      $sender->sendMessage(" §a* §7Kit §asvip §7zawiera: ");
	  $sender->sendMessage(" §a* §7- §aZelazny Helm oraz Spodnie");
	  $sender->sendMessage(" §a* §7- §aLuk oraz 32 strzal");
	  $sender->sendMessage(" §a* §7- §a10 Zlotych Jablek oraz 15 Chleba");
	  $sender->sendMessage(" §a* §7- §aDiamentowy Napiersnik oraz Buty");
	  $sender->sendMessage(" §a* §7- §aDiamentowy miecz Ostrosc 2, Odrzut 1");
      $sender->sendMessage("§l§8[§7-----------§a[SVIP]§7-----------§8]");
       return true;
   }

}
}
