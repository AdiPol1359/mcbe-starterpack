<?php
namespace Gracz;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\command\{Command, CommandSender};
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\level\particle\Particle;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as C;
use pocketmine\utils\Config;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use xSmoothy\FactionsPro\FactionMain;
class Main extends PluginBase implements Listener{
	
	    public function getAPI()
    {
        return Server::getInstance()->getPluginManager()->getPlugin("FactionsPro");
    }
		    public function getAPI2()
    {
        return Server::getInstance()->getPluginManager()->getPlugin("Elo");
    }
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("ExpStone Loaded zaladowane");
		}
	
public function onDeath(PlayerDeathEvent $event){
    $deathdata = new Config($this->getDataFolder() . "/smierci.yml", Config::YAML);
        $name = $event->getPlayer()->getDisplayName();
        $deaths = $deathdata->get($name);
        $deathdata->set($name,$deaths+1);
        $deathdata->save();
    }
  public function onDestroy(BlockBreakEvent $event){
    $breakdata = new Config($this->getDataFolder() . "/zniszczone.yml", Config::YAML);
        $name = $event->getPlayer()->getDisplayName();
        $breaks = $breakdata->get($name);
        $breakdata->set($name,$breaks+1);
        $breakdata->save();
  }
  public function onPlace(BlockPlaceEvent $event){
    $placedata = new Config($this->getDataFolder() . "/postawione.yml", Config::YAML);
        $name = $event->getPlayer()->getDisplayName();
        $places = $placedata->get($name);
        $placedata->set($name,$places+1);
        $placedata->save();
	}
public function onDeath2(PlayerDeathEvent $event){
    $pointdata = new Config($this->getDataFolder() . "/punkty.yml", Config::YAML);
    $entity = $event->getEntity();
    $cause = $entity->getLastDamageCause();
        $killer = $cause->getDamager();
    if($killer instanceof Player){
      $name = $killer->getName();
      $points = $pointdata->get($name);
      $pointdata->set($name,$points+100);
      $pointdata->save();
    }
  }
 public function onDeath3(PlayerDeathEvent $event){
     $pointdata = new Config($this->getDataFolder() . "/punkty.yml", Config::YAML);
   $pkt = 100;
   $player = $event->getPlayer()->getDisplayName();
     $punkty = $pointdata->get($player);
     $ustawpkt = $punkty - $pkt;
      $pointdata->set($player, $ustawpkt);
        $pointdata->save();
        $pointdata->reload();
 }
   public function onDeath4(PlayerDeathEvent $event){
    $killdata = new Config($this->getDataFolder() . "/zabicia.yml", Config::YAML);
    $entity = $event->getEntity();
    $cause = $entity->getLastDamageCause();
        $killer = $cause->getDamager();
    if($killer instanceof Player){
      $name = $killer->getName();
      $kills = $killdata->get($name);
      $killdata->set($name,$kills+1);
      $killdata->save();
    }
  }
  public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
        if($cmd->getName() == "gracz"){
			if($sender instanceof Player) {
			$gracz = $sender->getName();
            $deathdata = new Config($this->getDataFolder() . "/smierci.yml", Config::YAML);
            $deaths = $deathdata->get($sender->getName());
            $killdata = new Config($this->getDataFolder() . "/zabicia.yml", Config::YAML);
            $kills = $killdata->get($sender->getName());
            $breakdata = new Config($this->getDataFolder() . "/zniszczone.yml", Config::YAML);
            $breaks = $breakdata->get($sender->getName());
            $placedata = new Config($this->getDataFolder() . "/postawione.yml", Config::YAML);
            $places = $placedata->get($sender->getName());
            $pointdata = new Config($this->getDataFolder() . "/punkty.yml", Config::YAML);
            $points = $pointdata->get($sender->getName());
			$gildia2 = $sender->getName();
			$gildia = $this->getAPI()->getPlayerFaction($gildia2);
			$punktciory = $this->getAPI2()->getElo($gildia2);
			$sender->sendMessage("§f• §7Gracz: §a" . $gracz . " §f•");
			$sender->sendMessage("§f• §7Gildia: §a" .$gildia . " §f•");
			$sender->sendMessage("§f• §7Punkty: §a" . $punktciory . " §f•");
			$sender->sendMessage("§f• §7Zabojstwa: §a" . $kills . " §f•");
			$sender->sendMessage("§f• §7Smierci: §a" . $deaths . " §f•");
			$sender->sendMessage("§f• §7Wykopane Bloki: §a" . $breaks . " §f•");
			$sender->sendMessage("§f• §7Postawione Bloki: §a" . $places . " §f•");
			}
			if(count($args) == 1){
				$player = $args[0];
            $killdata = new Config($this->getDataFolder() . "/zabicia.yml", Config::YAML);
            $kills = $killdata->get($player);
            $deathdata = new Config($this->getDataFolder() . "/smierci.yml", Config::YAML);
            $deaths = $deathdata->get($player);
            $breakdata = new Config($this->getDataFolder() . "/zniszczone.yml", Config::YAML);
            $breaks = $breakdata->get($player);
            $placedata = new Config($this->getDataFolder() . "/postawione.yml", Config::YAML);
            $places = $placedata->get($player);
            $pointdata = new Config($this->getDataFolder() . "/punkty.yml", Config::YAML);
            $points = $pointdata->get($player);
			$gildia = $this->getAPI()->getPlayerFaction($player);
			$punktciory = $this->getAPI2()->getElo($player);
			$sender->sendMessage("§f• §7Gracz: §a" . $player . " §f•");
			$sender->sendMessage("§f• §7Gildia: §a" .$gildia . " §f•");
			$sender->sendMessage("§f• §7Punkty: §a" . $punktciory . " §f•");
			$sender->sendMessage("§f• §7Zabojstwa: §a" . $kills . " §f•");
			$sender->sendMessage("§f• §7Smierci: §a" . $deaths . " §f•");
			$sender->sendMessage("§f• §7Wykopane Bloki: §a" . $breaks . " §f•");
			$sender->sendMessage("§f• §7Postawione Bloki: §a" . $places . " §f•");
			}
			}
  }
  }
