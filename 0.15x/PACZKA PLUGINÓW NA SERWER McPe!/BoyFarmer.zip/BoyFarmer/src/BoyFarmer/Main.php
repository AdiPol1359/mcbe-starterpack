<?php

namespace BoyFarmer;

use pocketmine\plugin\PluginBase as PluginBase;
use pocketmine\event\Listener as Listener;
use pocketmine\utils\TextFormat;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\utils\Config;
use pocketmine\block\Block;
use pocketmine\block\Air;
use pocketmine\block\Obsidian;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\BlazeShootSound;


class Main extends PluginBase implements Listener{

 
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);	
		$this->saveDefaultConfig();
		$this->getServer()->getLogger()->info(TextFormat::GREEN . "[BoyFarmer] Enabling...");
	}
	
	public function onPlace(BlockPlaceEvent $event){
	 $blok = $event->getBlock();
	 $gracz = $event->getPlayer();
	 $y = $blok->getFloorY();
	 $x = $blok->getFloorX();
	 $z = $blok->getFloorZ();
	 
  	 if($blok->getId() == 19){
  	  if(!($event->isCancelled())){

		 //10
		$gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY(), $blok->getFloorZ()), new Obsidian());
  	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-1, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-1, $blok->getFloorZ()), new Obsidian());
	  }
	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-2, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-2, $blok->getFloorZ()), new Obsidian());
	  }
	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-3, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-3, $blok->getFloorZ()), new Obsidian());
	  }
	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-4, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-4, $blok->getFloorZ()), new Obsidian());
		  }
	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-5, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-5, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-6, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-6, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-7, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-7, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-8, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-8, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-9, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-9, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-10, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-10, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-11, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-11, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-12, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-12, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-13, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-13, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-14, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-14, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-15, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-15, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-16, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-16, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-17, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-17, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-18, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-18, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-19, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-19, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-20, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-20, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-21, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-21, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-22, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-22, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-23, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-23, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-24, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-24, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-25, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-25, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-26, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-26, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-27, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-27, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-28, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-28, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-29, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-29, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-30, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-30, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-31, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-31, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-32, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-32, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-33, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-33, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-34, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-34, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-35, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-35, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-36, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-36, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-37, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-37, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-38, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-38, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-39, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-39, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-40, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-40, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-41, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-41, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-42, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-42, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-43, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-43, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-44, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-44, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-45, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-45, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-46, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-46, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-47, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-47, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-48, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-48, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-49, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-49, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-50, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-50, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-51, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-51, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-52, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-52, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-53, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-53, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-54, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-54, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-55, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-55, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-56, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-56, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-57, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-57, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-58, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-58, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-59, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-59, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-60, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-60, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-61, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-61, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-62, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-62, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-63, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-63, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-64, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-64, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-65, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-65, $blok->getFloorZ()), new Obsidian());
		  }
		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-66, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-66, $blok->getFloorZ()), new Obsidian());
		  }
		  		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-67, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-67, $blok->getFloorZ()), new Obsidian());
		  }
		  		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-68, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-68, $blok->getFloorZ()), new Obsidian());
		  }
		  		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-69, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-69, $blok->getFloorZ()), new Obsidian());
		  }
		  		  	    	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-70, $z))->getId() == 0) {
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()-70, $blok->getFloorZ()), new Obsidian());
		  }
		  
     $gracz->sendMessage("§l§7Postawiłeś §aBoyFarmera");
        $center = new Vector3($x, $y, $z);
        $particle = new LavaParticle($center);
        for($yaw = 0, $y = $center->y; $y < $center->y + 3; $yaw += (M_PI * 2) / 20, $y += 1 / 20) {
            $x = -sin($yaw) + $center->x;
            $z = cos($yaw) + $center->z;
            $particle->setComponents($x, $y, $z);
    }
	  }else{
	   $gracz->sendMessage("");
	  }	 
	 }
 }
	 
			public function onPlace2(BlockPlaceEvent $event){
			$blok = $event->getBlock();
			$gracz = $event->getPlayer();
			  if($blok->getId() == 19){
				$event->setCancelled();
				$gracz->getInventory()->removeItem(Item::get(19, 0, 1));
				 }
			}
}