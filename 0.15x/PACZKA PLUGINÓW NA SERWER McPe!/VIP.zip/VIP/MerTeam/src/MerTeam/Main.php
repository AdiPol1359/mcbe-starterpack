<?php

namespace MerTeam;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pockemine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("MerTeam Was Kocha <3");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		if(strtolower($command->getName('vip'))) {
			if(empty($args)) {
				$sender->sendMessage("§l§8)§7===========§8( (§aVIP§8) )§7===========§8(");
				$sender->sendMessage("§a* §7- Aby kupic wyslij sms'a o tresci: §aAP.HOSTMC §7pod numer: §s74068");
				$sender->sendMessage("    §7- Koszt to: §a4§7.§a92§7zl");
				$sender->sendMessage("§a* §7- Ranga §l§aVIP§7§r posiada permisje takie jak:");
				$sender->sendMessage("    §7- §a/time§7, §a/kit§7, §a/repair§7, §a/back");
				$sender->sendMessage("§a* §7- Kod z rangi zwrotnej podaj tylko do §aAdministracji§7!");
				$sender->sendMessage("§l§8)§7===========§8( (§aVIP§8) )§7===========§8(");
			}
		}
	}
}
