<?php

namespace Pomoc;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pockemine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info(" Enabled!");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		if(strtolower($command->getName('pomoc'))) {
			if(empty($args)) {
				$sender->sendMessage(")§7===========§8( (§aPOMOC§8) )§7===========§8( ");
				$sender->sendMessage("§a* §7Komendy serwera");
				$sender->sendMessage("§a* §7Komendy Gildi: §a/g pomoc §7(§a1§7-§a3§7)");
				$sender->sendMessage("§a* §7Top 10 graczy PvP: §a/topka");
				$sender->sendMessage("§a* §7Kupno rang poprzez sms: §a/sms");
				$sender->sendMessage("§a* §7Dostępne efekty do PvP: §a/efekt");
				$sender->sendMessage("§a* §7Startowe itemki i nie tylko: §a/kit");
				$sender->sendMessage("§a* §7Teleportacj na losowe koordynanty: §a/losowe");
				$sender->sendMessage("§a* §7Dodatki serwera: §a/dodatki");
				$sender->sendMessage("§a* §7Stan pięniędzy: §a/monety");
				$sender->sendMessage("§a* §7Wysłanie pieniędzy: §a/zaplac");
				$sender->sendMessage("§a* §bWiecej komend juz wkrótce!");
				$sender->sendMessage("§8)§7===========§8( (§aPOMOC§8) )§7===========§8(");
			}
		}
	}
}
