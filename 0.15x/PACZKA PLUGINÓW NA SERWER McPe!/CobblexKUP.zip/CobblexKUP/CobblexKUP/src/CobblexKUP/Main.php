<?php

namespace CobblexKUP;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info("CobblexKUP Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('cobblex'))) {
				if(empty($args)) {
					$sender->sendMessage("§l§8)§7===========§8( (§aCobbleX§8) )§7===========§8(");
					$sender->sendMessage("§a* §7CobbleX jest dodatkiem, ktory losuje nagrode.");
					$sender->sendMessage("§a* §7Jak go aktywowac?");
					$sender->sendMessage("   §7Wystarczy postawic CobbleX'a a wylosuje");
					$sender->sendMessage("   §7automatycznie jedna nagrode sposrod 25.");
					$sender->sendMessage("§a* §7CobbleX'a kupisz komenda: §a/cobblex kup§7.");
				    $sender->sendMessage("§l§8)§7===========§8( (§aCobbleX§8) )§7===========§8(");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(4, 0, 576))){
						$sender->getInventory()->addItem(Item::get(129, 0, 1));
						 $sender->getInventory()->removeItem(Item::get(4, 0, 576));
						$sender->sendMessage("§8[§aCobbleX§8] §7Zakupiłeś §aCobbleX");
            }
						else{
							$sender->sendMessage("§8[§aCobbleX§8] §7Nie posiadasz tyle §aBruku!");
                                                }
                                         }
                        }
  }
}


