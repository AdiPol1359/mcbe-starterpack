<?php

namespace MerTeamPerlaKUP;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info("MerTeam Was Kocha <3");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('perly'))) {
				if(empty($args)) {
					$sender->sendMessage("§l§8)§7===========§8( (§aEnderPerly§8) )§7===========§8)");
					$sender->sendMessage("§a* §7- Perla to dodatek dzieki ktoremu mozesz,"); 
					$sender->sendMessage("    §7- teleportowac sie w miejsce gdzie spadnie §aSniezka§7!");
					$sender->sendMessage("§a* §7- Aby kupic wpisz: §a/perly kup ");
					$sender->sendMessage("    §7- Koszt to: §a5 §7Diamentów!");
					$sender->sendMessage("§l§8)§7===========§8( (§aEnderPerly§8) )§7===========§8)");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 5))){
						$sender->getInventory()->addItem(Item::get(332, 0, 2));
						 $sender->getInventory()->removeItem(Item::get(264, 0, 5));
						$sender->sendMessage("§8• (§aPerły§8) §7Pomyślnie kupiłeś §a2 §7EnderPerły! §8•");
            }
						else{
						$sender->sendMessage("§8• (§aPerły§8) §7Nie posiadasz §a5 §7Dimentów! §8•");
							}
						return true;
                          }
	
	}
						}
					}
