<?php

namespace MerTeamSVIP;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pockemine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("MerTeam Waas Kocha <3");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		if(strtolower($command->getName('svip'))) {
			if(empty($args)) {
				$sender->sendMessage("§l§8)§7===========§8( (§aSVIP§8) )§7===========§8(");
				$sender->sendMessage("§a* §7- Aby kupic wyslij sms'a o tresci: §aAP.HOSTMC §7pod numer: §a76068");
				$sender->sendMessage("    §7- Koszt to: §a7§7.§a38§7zl");
				$sender->sendMessage("§a* §7- Ranga §l§aSVIP§7§r posiada permisje takie jak:");
				$sender->sendMessage("    §7- §a/time§7, §a/kit§7, §a/repair§7, §a/back, §a/near");
				$sender->sendMessage("§a* §7- Kod z rangi zwrotnej podaj tylko do §aAdministracji§7!");
				$sender->sendMessage("§l§8)§7===========§8( (§aSVIP§8) )§7===========§8(");
			}
		}
	}
}
