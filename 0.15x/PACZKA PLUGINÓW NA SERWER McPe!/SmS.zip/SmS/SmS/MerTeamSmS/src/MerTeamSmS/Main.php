<?php

namespace MerTeamSmS;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pockemine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("MerTeam Was Kocha <3");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		if(strtolower($command->getName('sms'))) {
			if(empty($args)) {
				$sender->sendMessage("§l§8)§7===========§8( (§aSmS§8) )§7===========§8(");
				$sender->sendMessage("§a* §7- Ranga §8[§bVIP§8] §7- §a/vip");
				$sender->sendMessage("§a* §7- Ranga §8[§6SVIP§8] §7- §a/svip");
				$sender->sendMessage("§a* §7- Ranga §8[§eUVIP§8] §7- §a/uvip");
				$sender->sendMessage("§l§8)§7===========§8( (§aSmS§8) )§7===========§8(");
				
			}
		}
	}
}
