<?php

namespace MerTeamYT;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pockemine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("MerTeam Was Kocha <3");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
		if(strtolower($command->getName('yt'))) {
			if(empty($args)) {
				$sender->sendMessage("§l§8)§7===========§8( (§aYT§8) )§7===========§8(");
				$sender->sendMessage("§a* §7- Aby zdobyc range §aYT §7musisz posiadac §a100 §7Subskrybcji");
				$sender->sendMessage("    §7- Oraz trailer na swoim kanale!");
				$sender->sendMessage("§a* §7- Ranga §aYT §7posiada wszystko to co §aVIP§7.");
				$sender->sendMessage("§a* §7- Po range zglos sie do §aAdministacji§7!");
				$sender->sendMessage("§l§8)§7===========§8( (§aYT§8) )§7===========§8(");
			}
		}
	}
}
