<?php
namespace ChatToolsPro;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Config;
use pocketmine\permission\ServerOperator;
use pocketmine\event\player\PlayerChatEvent;
/**
 *  ____     ______    ______    _________   _________     _______
 * |  _ \   |  __  |  |  ____|  |___   ___| |___   ___|   |__   __|
 * | |_) /  | |__| |  | |____       | |         | |          | |
 * |  __/   |  __  |  |  ____|      | |         | |          | |
 * | |      | |  | |  | |____       | |         | |        __| |__
 * |_|      |_|  |_|  |______|      |_|         |_|       |_______|
 * Plugin coded by paetti.
 * This Label is by paetti.
**/
class Main extends PluginBase implements Listener{
	public $prefix = TextFormat::GREEN."§8• (§aCHAT§8)§7".TextFormat::YELLOW." ";
    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->saveDefaultConfig();
        $this->getLogger()->info(TextFormat::AQUA . "ChatToolsPro by paetti loaded. Coded by paetti. Instagram: xPaetti Kik: Oupsay");
    }
    
    public function onDisable(){
        $this->getLogger()->info(TextFormat::AQUA . "ChatToolsPro disabled.");
    }
        public function onChat(PlayerChatEvent $event) {
    
      if(!($event->getPlayer()->hasPermission("chattoolspro.lockchat"))) {
      
        if($this->disableChat) {
        
          $event->setCancelled(true);
          
          $event->getPlayer()->sendMessage("§8• §7Niestety chat główny jest wyłączony! §8•");
          
        }
        
      }
      
    }
    public function onCommand(CommandSender $sender, Command $command, $label, array $args){
        switch($command->getName()){

            case "chattoolspro":
                if(!(isset($args[0]))){
                $sender->sendMessage(TextFormat::GREEN . "ChatToolsPro v1.1 coded by paetti. Kik: Oupsay");
                $sender->sendMessage(TextFormat::GREEN . "/chattoolspro <1/2/3/4/5> for help");
               
      
           
                    return true;
                }
            if($args[0] == "1"){
                $sender->sendMessage(TextFormat::GREEN . "Page 1 of 4 Help Pages");
                $sender->sendMessage(TextFormat::GREEN . "/announcement " . TextFormat::WHITE . "Broadcast Message with [Announcement] Tag");
                $sender->sendMessage(TextFormat::GREEN . "/serversay " . TextFormat::WHITE . "Broadcast Message with [Server] Tag");
                $sender->sendMessage(TextFormat::GREEN . "/staffsay " . TextFormat::WHITE . "Broadcast Message with [Staff] Tag");
                $sender->sendMessage(TextFormat::GREEN . "/support " . TextFormat::WHITE . "Broadcast Message with [Support] Tag");
                $sender->sendMessage(TextFormat::GREEN . "/warning " . TextFormat::WHITE . "Broadcast Message with [Warning] Tag");
                $sender->sendMessage(TextFormat::GREEN . "/alert" . TextFormat::WHITE . "Broadcast Message with [ALERT] Tag");
                return true;
            }
            elseif($args[0] == "2"){
                $sender->sendMessage(TextFormat::GREEN . "Page 2 of 4 Help Pages");
                $sender->sendMessage(TextFormat::GREEN . "/info " . TextFormat::WHITE . "Broadcast Message with [Info] Tag");
                $sender->sendMessage(TextFormat::GREEN . "/chatsay " . TextFormat::WHITE . "Broadcast Message without any Tag");
                $sender->sendMessage(TextFormat::GREEN . "/warn " . TextFormat::WHITE . "Warn a Player");
                $sender->sendMessage(TextFormat::GREEN . "/vmsg " . TextFormat::WHITE . "Send a anonymous Message to a Player");
                $sender->sendMessage(TextFormat::GREEN . "/tipgive " . TextFormat::WHITE . "Give a Tip to a Player");
                $sender->sendMessage(TextFormat::GREEN . "/hug " . TextFormat::WHITE . "Hug a Player");
                return true;
            }
        elseif($args[0] == "3"){
                $sender->sendMessage(TextFormat::GREEN . "Page 3 of 4 Help Pages");
                $sender->sendMessage(TextFormat::GREEN . "/setnick " . TextFormat::WHITE . "Set a nick");
                $sender->sendMessage(TextFormat::GREEN . "/sayas " . TextFormat::WHITE . "Say a Message as another Player");
                $sender->sendMessage(TextFormat::GREEN . "/spam " . TextFormat::WHITE . "Spam");
                $sender->sendMessage(TextFormat::GREEN . "/clearchat " . TextFormat::WHITE . "Clears the Chat");
                $sender->sendMessage(TextFormat::GREEN . "/spamsay " . TextFormat::WHITE . "Spams a Message");
                $sender->sendMessage(TextFormat::GREEN . "/spammsg " . TextFormat::WHITE . "Send a Message more times to a Player");
                return true;
        }
        elseif($args[0] == "4"){
                $sender->sendMessage(TextFormat::GREEN . "Page 4 of 4 Help Pages");
                $sender->sendMessage(TextFormat::GREEN . "/helpme " . TextFormat::WHITE . "Adds [NeedsHelp] Tag to Name");
                $sender->sendMessage(TextFormat::GREEN . "/done " . TextFormat::WHITE . "Remove [NeedsHelp] Tag from Name");
                $sender->sendMessage(TextFormat::GREEN . "/report " . TextFormat::WHITE . "Report a Player");
                $sender->sendMessage(TextFormat::GREEN . "/ops " . TextFormat::WHITE . "Lists online OP's");
                $sender->sendMessage(TextFormat::GREEN . "/opfake " . TextFormat::WHITE . "Fake op somebody");
                $sender->sendMessage(TextFormat::GREEN . "/deopfake " . TextFormat::WHITE . "Fake Deop somebody");
                $sender->sendMessage(TextFormat::GREEN . "/checkop " . TextFormat::WHITE . "Check if a Player is OP or not");
                return true;
        }
         elseif($args[0] == "4"){
                $sender->sendMessage(TextFormat::GREEN . "Page 4 of 4 Help Pages");
                $sender->sendMessage(TextFormat::GREEN . "/lockchat " . TextFormat::WHITE . "Lock or unlock Chat");
                $sender->sendMessage(TextFormat::GREEN . "/illuminati " . TextFormat::WHITE . "Illuminati Message");
               
                return true;
        }
                break;
                // Broadcasting Features
                case "ogloszenie":
                $sender->sendMessage("§7Pomyślnie wysłałeś §3Ogłoszenie§7 serwera!");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "§8(§aOGŁOSZENIE§8) §3" . implode(" ", $args));
                return true;
             
                case "server":
                $sender->getServer()->broadcastMessage(TextFormat::LIGHT_PURPLE . "§8(§aSERVER§8) §3" . implode(" ", $args));
                return true;
                case "administracja":
                $sender->getServer()->broadcastMessage(TextFormat::YELLOW . "[§aADMINISTRACJA] §3" . TextFormat::RED . implode(" ", $args));
                return true;
                case "suport":
                $sender->getServer()->broadcastMessage(TextFormat::YELLOW . TextFormat::BOLD . "§8(§aPOMOC§8) §3" .TextFormat::RESET . TextFormat::AQUA . implode(" ", $args));
                return true;
                case "uwaga":
                $sender->getServer()->broadcastMessage(TextFormat::DARK_RED . "§8(§aUWAGA§8) §3" . implode(" ", $args));
                return true;
                case "alarm":
                $sender->getServer()->broadcastMessage(TextFormat::RED . "§8(§aALARM§8) §3" . implode(" ", $args));
                return true;
                case "informacja":
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "§8(§aINFORMACJA§8) §3" . implode(" ", $args));
                return true;
                case "chatsay":
                    if(!(isset($args[0]))){
                    return false;
                }
                $sender->getServer()->broadcastMessage(implode(" ", $args));
                return true;
                // UP - Broadcasting Features
            case "warn":
                $name = \strtolower(\array_shift($args));

		$player = $sender->getServer()->getPlayer($name);

                if($player === $sender){
			$sender->sendMessage("You can't warn yourself!");
			return \true;
		}
		
                if($player instanceof Player){
			$sender->sendMessage(TextFormat::DARK_RED . "[Warning" . " -> " . $player->getDisplayName() . "] " . "Â§c" . implode(" ", $args));
			$player->sendMessage(TextFormat::DARK_RED . "[Warning" . " -> ".$player->getName()."] " . implode(" ", $args));
		}else{
			$sender->sendMessage(TextFormat::RED . "Usage: /warn <Player> <Reason>");
		}

		return true;
                case "vmsg":
                $name = \strtolower(\array_shift($args));

		$player = $sender->getServer()->getPlayer($name);

                if($player === $sender){
			$sender->sendMessage("You can't write yourself!");
			return \true;
		}
		
                if($player instanceof Player){
			$sender->sendMessage(TextFormat::YELLOW . "[ -> " . $player->getDisplayName() . "] " . TextFormat::WHITE . implode(" ", $args));
			$player->sendMessage(TextFormat::YELLOW . "[ -> ".$player->getName()."] " . TextFormat::WHITE . implode(" ", $args));
		}else{
			$sender->sendMessage(TextFormat::RED . "Usage: /vmsg <Player> <Message>");
		}

		return true;
		  case "send":
                $name = \strtolower(\array_shift($args));

		$player = $sender->getServer()->getPlayer($name);

                if($player === $sender){
			$sender->sendMessage("You can't send yourself!");
			return \true;
		}
		
                if($player instanceof Player){
			$sender->sendMessage($this->prefix."Sended to the specified player.");
			$player->sendMessage(implode(" ", $args));
		}else{
			$sender->sendMessage(TextFormat::RED . "Usage: /send <Player> <Message>");
		}

		return true;
                case "tipgive":
                $name = \strtolower(\array_shift($args));

		$player = $sender->getServer()->getPlayer($name);

                if($player === $sender){
			$sender->sendMessage("You can't give yourself an tip!");
			return \true;
		}
		
                if($player instanceof Player){
			$sender->sendMessage(TextFormat::YELLOW . "[Tip by " .  $sender->getName() . "  -> ".$player->getName." ] " . implode(" ", $args));
			$player->sendMessage(TextFormat::YELLOW . "[Tip by " . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " -> you] " . implode(" ", $args));
		}else{
			$sender->sendMessage("Â§cUsage: /tipgive <Player> <Tip>");
		}
                return true;
                case "hug":
                $name = \strtolower(\array_shift($args));

		$player = $sender->getServer()->getPlayer($name);

                if($player === $sender){
			$sender->sendMessage("You can't hug yourself!");
			return \true;
		}
		
                if($player instanceof Player){
			$sender->sendMessage(TextFormat::RED . "<3 You hug " . $player->getDisplayName() . " <3");
			$player->sendMessage(TextFormat::RED . "<3 " . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " hugs you <3 ");
		}else{
			$sender->sendMessage("Â§cUsage: /hug <Player>");
		}
                return true;
                case "opfake":
                $name = \strtolower(\array_shift($args));

		$player = $sender->getServer()->getPlayer($name);

                if($player === $sender){
			$sender->sendMessage("You can't fake op yourself!");
			return \true;
		}
		
                if($player instanceof Player){
			$sender->sendMessage(TextFormat::GREEN . "Sucessfully fake-opped Player " . TextFormat::YELLOW .  $player->getDisplayName());
			$player->sendMessage(TextFormat::GRAY . "You are now op!");
		}else{
			$sender->sendMessage("§cUsage: /opfake <Player>");
		}
                return true;
                case "deopfake":
                $name = \strtolower(\array_shift($args));

		$player = $sender->getServer()->getPlayer($name);

                if($player === $sender){
			$sender->sendMessage("You can't fake deop yourself!");
			return \true;
		}
		
                if($player instanceof Player){
			$sender->sendMessage(TextFormat::GREEN . "Sucessfully fake-deopped Player " . TextFormat::YELLOW .  $player->getDisplayName());
			$player->sendMessage(TextFormat::GRAY . "You are no longer op!");
		}else{
			$sender->sendMessage("§cUsage: /deopfake <Player>");
		}
                return true;
                case "setnick":
                 if (!($sender instanceof Player)){ 
                $sender->sendMessage(TextFormat::GREEN . "This command is only avaible In-Game!");
                    return true;
                }
                $sender->sendMessage(TextFormat::GREEN . "Nick set sucessfully.");
                $sender->setDisplayName(implode(" ", $args));
                          return true;
             
            case "sayas":
                $name = \strtolower(\array_shift($args));
                
            $sender->sendMessage(TextFormat::GREEN . "Sended Message as " .  $name);
            $sender->getServer()->broadcastMessage("<" . $name . "> " . implode(" ", $args));
        
            return true;
            case "spam":
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");      
                      $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM"); 
                      $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM");
                $sender->getServer()->broadcastMessage(TextFormat::AQUA . "SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM SPAM"); 
           return true;
           case "cc":
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
                $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
                $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
                $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
                $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
                $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
               $sender->getServer()->broadcastMessage(" ");
              
               $sender->getServer()->broadcastMessage($this->prefix."§7Chat został wyczyszczony przez §a".$sender->getDisplayName().TextFormat::RED." §7Powód: §a".implode(" ", $args));
                       
            return true;
           case "spamsay":
               if(!(isset($args[0]))){
                    $sender->sendMessage(TextFormat::RED."Usage: /spamsay <Message>");
                    return true;
               }
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->getServer()->broadcastMessage(implode(" ", $args));
               $sender->sendMessage(TextFormat::GREEN . "Message spammed sucessfully");
                       
           return true;
           case "spammsg":
                $name = \strtolower(\array_shift($args));

		$player = $sender->getServer()->getPlayer($name);

                if($player === $sender){
			$sender->sendMessage(TextFormat::Red . "You can't send a spammed Message to yourself!");
			return \true;
		}

		if($player instanceof Player){
			$player->sendMessage(TextFormat::YELLOW . "[" . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " -> ".$player->getName()."] " . implode(" ", $args));
                        $player->sendMessage(TextFormat::YELLOW . "[" . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " -> ".$player->getName()."] " . implode(" ", $args));
                        $player->sendMessage(TextFormat::YELLOW . "[" . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " -> ".$player->getName()."] " . implode(" ", $args));
                        $player->sendMessage(TextFormat::YELLOW . "[" . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " -> ".$player->getName()."] " . implode(" ", $args));
                        $player->sendMessage(TextFormat::YELLOW . "[" . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " -> ".$player->getName()."] " . implode(" ", $args));
                        $player->sendMessage(TextFormat::YELLOW . "[" . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " -> ".$player->getName()."] " . implode(" ", $args));
                        $player->sendMessage(TextFormat::YELLOW . "[" . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " -> ".$player->getName()."] " . implode(" ", $args));
                        $player->sendMessage(TextFormat::YELLOW . "[" . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " -> ".$player->getName()."] " . implode(" ", $args));
                        $player->sendMessage(TextFormat::YELLOW . "[" . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " -> ".$player->getName()."] " . implode(" ", $args));
                        $sender->sendMessage(TextFormat::GREEN . "Sucessfully spammed the Message to the Player " . TextFormat::YELLOW . $player->getName());
		}else{
			$sender->sendMessage(TextFormat::YELLOW . "Player not found!");
		}

		return true;
                case "helpme":
                 if (!($sender instanceof Player)){ 
                $sender->sendMessage(TextFormat::GREEN . "This command is only avaible In-Game!");
                    return true;
                }
                $sender->sendMessage(TextFormat::GREEN . "Type /done if you don't need help anymore.");
                $sender->setDisplayName(TextFormat::RED . "[NeedsHelp] ".$sender->getDisplayName());
                          return true;  
            case "done":
                 if (!($sender instanceof Player)){ 
                $sender->sendMessage(TextFormat::GREEN . "This command is only avaible In-Game!");
                    return true;
                }
                $sender->setDisplayName(str_replace(TextFormat::RED . "[NeedsHelp]", "", $sender->getDisplayName()));
                $sender->sendMessage(TextFormat::GREEN . "Type /helpme if you need help again.");
                return true;

            case "checkop":
             $name = \strtolower(\array_shift($args));

                    $player = $sender->getServer()->getPlayer($name);
		
                    if($player instanceof Player){
                if($player->isOp()){
		$sender->sendMessage(TextFormat::GREEN . "[ChatToolsPro] Player " . $player->getDisplayName() . " is an OP");

		return true;
                } else {
                    $sender->sendMessage(TextFormat::GREEN . "[ChatToolsPro] Player " . $player->getDisplayName() . " is not OP");
                    return true;
                }
                    } else {
                        $sender->sendMessage(TextFormat::RED . "Player not online!");
                        return true;
                    }
  
	
            case "zglos":
		 $name = \strtolower(\array_shift($args));

                    $player = $sender->getServer()->getPlayer($name);
                if(!(isset($args[0]))){
                    $sender->sendMessage(TextFormat::RED."§7Użyj: §3/zglos §7<§3Player§7> <§3Reason§7>");
                    return true;
              }
              if (!($sender instanceof Player)){ 
                $sender->sendMessage("Uzyj tego w grze...");
                    return true;
                }
		if(count($args) < 1){                   
				foreach($this->getServer()->getOnlinePlayers() as $p){
					if($p->isOnline() && $p->isOp()){
						if($player instanceof Player){
                                            $p->sendMessage(TextFormat::RED."§8• (§aCHAT§7) §7".TextFormat::GRAY."§7Gracz §a".$sender->getName()." §3zgłasza §7".TextFormat::RED.$player->getDisplayName().TextFormat::GRAY." §7za§a ".TextFormat::RED.implode("", $args));
						
						$sender->sendMessage(TextFormat::RED."§8• (§aCHAT§7) ".TextFormat::GRAY."§7Raprot wysłany. §f");
						return true;
					}else{
						$sender->sendMessage(TextFormat::RED."§8• (§aCHAT§7) ".TextFormat::GRAY."Na serwerze niema administracji. §f•");
						return true;
                                        }
                                        }else{ 
                                            $sender->sendMessage(TextFormat::RED."§8• (§aCHAT§7) §7Na serwerze niema tego gracza.");
					}
				}
		 	
			}else if($sender->hasPermission("chattoolspro.report")){
                             
				foreach($this->getServer()->getOnlinePlayers() as $p){
					if($p->isOnline() && $p->isOp()){
                                            if($player instanceof Player){
							$p->sendMessage(TextFormat::RED."§8• (§aCHAT§7) §3".TextFormat::GRAY."§7Gracz §a".$sender->getName()." §7zgłasza§a ".TextFormat::RED.$player->getDisplayName().TextFormat::GRAY." §7za§a ".TextFormat::RED.implode("", $args));
                                                        
							$sender->sendMessage(TextFormat::RED."§8• (§aCHAT§7) ".TextFormat::GRAY."Zgłoszenie wysłane. §f•");
							return true;
					}else{
						$sender->sendMessage(TextFormat::RED."§8• (§aCHAT§7) ".TextFormat::GRAY."Ten gracz nie jest online! Zgłoszenie nie zostało wysłane.. §f•");
						return true;
					}
                                        }else{ 
                                            $sender->sendMessage(TextFormat::RED."Gracz jest offline!");
					}
				}
			}else{
				$sender->sendMessage(TextFormat::RED."No Permission!");
				return true;
			}
               case "chat":
               	        if(!(isset($args[0]))){
                $sender->sendMessage(TextFormat::GREEN . "Uzycie: /chat on/off");
                    return true;
                }
            if($args[0] == "off"){
                 $sender->sendMessage("§f• §7Chat został wyłączony. §f•");
           $sender->getServer()->broadcastMessage("§8• §7Chat zostal wyłączony przez §a" . $sender->getName() . " §8•");
	   $this->disableChat = true;
                return true;
            }
            elseif($args[0] == "on"){
                 $sender->sendMessage("§f• §7Chat został włączony. §f•");
           $sender->getServer()->broadcastMessage("§8• §7Chat zostal włączony przez §a" . $sender->getName() . " §8•");
           $this->disableChat = false;
                return true;
            }
                
        
            case "ops":
                
			$ops = "";
			if($sender->hasPermission("chattoolspro.ops")){
				foreach($this->getServer()->getOnlinePlayers() as $p){
					if($p->isOnline() && $p->isOp()){
						$ops = $p->getName()." , ";
						$sender->sendMessage(TextFormat::AQUA."§7Administracja online:§a\n".substr($ops, 0, -2));		
						return true;
					}else{
						$sender->sendMessage(TextFormat::AQUA."§7Administracja Online:§a \n");
						return true;
					}
				}
			}else{
				$sender->sendMessage(TextFormat::RED."§8(§aCHAT§7) §7Nie posiadasz permisji!");
				return true;
			}
		}
	}
	
	public function getMsg($words){
		return implode(" ",$words);
	
    }
    
}
    /*
     *                         Coded by paetti
     */
             
