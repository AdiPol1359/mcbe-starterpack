<?php
/**
 * User: Michael Leahy
 * Date: 6/24/14
 * Time: 11:02 AM
 */

namespace SimpleMessages;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

class SimpleMessages extends PluginBase{

    public $configFile;

    public function onEnable(){
        @mkdir($this->getDataFolder());
        $this->configFile = (new Config($this->getDataFolder()."config.yml", Config::YAML, array(
            "messages" => array(
                "§7Wszystkie informcje znajdziesz na Spawnie! §8•",
                "§7Zapraszaj znajomych! §8•",
                "§7Serwer używa paczki zaprojektowanej przez: §aMerTeam §8•",
                "§7Kupno rang znajdziesz pod komendą: §a/sms§7! §8•",
				"§7Listę komend znajdziesz pod: §a/pomoc §8•",
				"§7Przed grą przeczytaj Regulamin: §a/regulamin§7!",
            ),
            "time" => "60",
            "prefix" => "§aBOT§8",
            "color" => "§8"
        )))->getAll();

        $time = intval($this->configFile["time"]) * 20;
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new SimpleMessagesTask($this), $time);

        $this->getLogger()->info("I've been enabled!");
    }

    public function onDisable(){
        $this->getLogger()->info("I've been disabled!");
    }

}
