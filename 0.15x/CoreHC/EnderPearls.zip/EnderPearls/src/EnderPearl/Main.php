<?php

namespace EnderPearl;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\entity\Egg;
use pocketmine\item\Item;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\math\Vector3;

class Main extends PluginBase implements Listener {
    
    private $cooldown;
    private $player = [];

    public function formatMessage($string) {
        return str_replace('&', '§', "&f• &8> [§2xHardCore&8] $string &f•");
    }
    
    public function onEnable() {
        $this->getLogger()->info("Plugin wlaczony!");
        $this->getLogger()->info("Plugin napisany dla CraftTure!");
        $this->saveDefaultConfig();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->cooldown = $this->getConfig()->getNested("ctEnderPearl.cooldown");
    }
    
    public function onDisable() {
        $this->getLogger()->info("Plugin wylaczony!");
        $this->getLogger()->info("Plugin napisany dla xHardCore!");
    }
    
    public function onProjectileHitEvent(ProjectileHitEvent $e) {
        $entity = $e->getEntity();
        $playerName = $entity->shootingEntity->getName();
        if($entity instanceof Egg) {
            $dirrerence = time() - (isset($this->player[$playerName]) ? $this->player[$playerName] : 0);
            if($dirrerence <= $this->cooldown) {
                $entity->shootingEntity->getInventory()->addItem(Item::get(344, 0, 1));
                $entity->shootingEntity->sendMessage($this->formatMessage("&7Perle ponownie bedziesz mogl uzyc za &2" . ($this->cooldown - $dirrerence) . " &7sekund!"));
            } else {
                $this->player[$playerName] = time();
                $entity->shootingEntity->teleport($entity->getPosition());
            }
        }
    }
    
    public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        if(strtolower($command->getName()) == "enderpearl") {
            if(count($args) == 0) {
                foreach($this->getConfig()->getNested("ctEnderPearl.info") as $info) {
                    $sender->sendMessage(str_replace('&', '§', $info));
                }
                return true;
            }
            elseif(count($args) == 1) {
                $canBuy = 0;
                if(strtolower($args[0]) == "buy" || strtolower($args[0]) == "kup") {
                    if(!$sender instanceof Player) {
                        $sender->sendMessage($this->formatMessage("&7Komende mozna uzyc jedynie w grze!"));
                        return true;
                    }
                    foreach($this->getConfig()->getNested("ctEnderPearl.price") as $key => $value) {
                        if(isset($key)) {
                            $item = explode(":", $this->getConfig()->getNested("ctEnderPearl.price.$key.item"));
                            if($sender->getInventory()->contains(Item::get($item[0], $item[1], $item[2]))) {
                                if($canBuy == 0) {
                                    $canBuy = 1;
                                }
                            } else {
                                $canBuy = 2;
                                $sender->sendMessage($this->formatMessage("&7Do zakupienia perly kresu potrzebujes &2$key &7w ilosci &2$item[2]&7!"));
                            }
                        }
                    }
                    if($canBuy == 1) {
                        foreach($this->getConfig()->getNested("ctEnderPearl.price") as $key => $value) {
                            if(isset($key)) {
                                $item = explode(":", $this->getConfig()->getNested("ctEnderPearl.price.$key.item"));  
                                $sender->getInventory()->removeItem(Item::get($item[0], $item[1], $item[2]));
                            }
                        }
                        $sender->getInventory()->addItem(Item::get(344, 0, 1));
                        $sender->sendMessage($this->formatMessage("&7Zakupiles &21 &7perle kresu."));
                    }
                    return true;
                }
                if(strtolower($args[0]) == "reload" || strtolower($args[0]) == "przeladuj") {
                    if($sender->hasPermission("ctenderpearl.reload")) {
                        $this->reloadConfig();
                        $this->cooldown = $this->getConfig()->getNested("ctEnderPearl.cooldown");
                        $sender->sendMessage($this->formatMessage("&7Plugin zostal przeladowany!"));
                        return true;
                    } else {
                        $sender->sendMessage($this->formatMessage("&7Nie masz do tego uprawnien!"));
                        return true;
                    }
                }
            } 
        }
        return false;
    }
}

