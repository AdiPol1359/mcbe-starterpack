<?php

namespace AntyCheat;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\IPlayer;
use pocketmine\command\{Command, CommandSender};
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\level\particle\Particle;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use pocketmine\utils\Utils;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pockemine\inventory\Inventory;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDespawnEvent;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\entity\Snowball;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\particle\BubbleParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\BatSound;
use pocketmine\level\sound;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\block\Air;
use pocketmine\block\Obsidian;
use pocketmine\block\Sand;
use pocketmine\block\Stone;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\entity\EntityShootBowEvent;
use pocketmine\entity\Egg;
use pocketmine\event\server\DataPacketReceiveEvent;

class Main extends PluginBase implements Listener{
	
	 	private $cooldown = [];
		
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$server = $this->getServer();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§1E§2n§2a§4b§5l§6e§7d§2!");
		}
	  public function OnBreak(BlockBreakEvent $event){
		  $cfg = new Config($this->getDataFolder() . "players.yml", Config::YAML);
		  $cfgs = $cfg->get($event->getPlayer()->getName());
		  $cfg->set($event->getPlayer()->getName(), $cfgs+1);
		  $cfg->save();
		  $player = $event->getPlayer();
		if(!isset($this->cooldown[$player->getName()])){
		if($cfg->get($event->getPlayer()->getName()) >= 7){
		if($player->getGamemode() == 0){
        $this->cooldown[$player->getName()] = time();
		//ustawiasz cooldown
		}
		}
		}
		else{
        if(time() - $this->cooldown[$player->getName()] <= 1){
		if($cfg->get($event->getPlayer()->getName()) >= 7){
            //nie moze wykonac bo blokada
			$event->setCancelled();
			foreach($this->getServer()->getOnlinePlayers() as $p){
		    if($p->isOp() or $p->hasPermission("antycheat.admin")){
			$p->sendPopup("§c§lANTYCHEAT§r§c:§7 " . $event->getPlayer()->getName() . " prawdopodobnie uzywa TAPDESTROY!");
			}
			}
		}
        } else{
            $this->cooldown[$player->getName()] = time();
            //zerujemy cooldowna
			$cfg->set($event->getPlayer()->getName(), "0");
			$cfg->save();
			
	  }
		}
	  }
	    public function onDamage(EntityDamageEvent $event) {
    if($event instanceof EntityDamageByEntityEvent) {
      $damager = $event->getDamager();
      $player = $event->getEntity();
      $distance = $damager->distance($player->getPosition());
   if($distance > 4 && $damager->getLevel()->getName() == $player->getLevel()->getName()) {
    if($damager instanceof Player) {
      if($damager->getInventory()->getItemInHand()->getId() == Item::BOW) {
        return;
      }else{
		if(!$damager->hasPermission("antycheat.admin") or !$damager->isOp()){
        $event->setCancelled();
		foreach($this->getServer()->getOnlinePlayers() as $p){
		if($p->isOp() or $p->hasPermission("antycheat.admin")){
		$p->sendTip("§c§lANTYCHEAT§r§c:§7 " . $damager->getName() . " prawdopodobnie uzywa cheatow!");
		}
		}
      }
    }
  }
}
}
}
}