<?php

namespace Rozdzka;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\command\{Command, CommandSender};
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use pocketmine\utils\Utils;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pockemine\inventory\Inventory;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\entity\Effect;

class Main extends PluginBase implements Listener{
 	
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$server = $this->getServer();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§1E§2n§aa§4b§5l§6e§7d§a!");
		$this->saveDefaultConfig();
		}
		
		public function onInteract(PlayerInteractEvent $event){
			$this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
			$gracz = $event->getPlayer();
			$x = $this->cfg->get('X');
			$y = $this->cfg->get('Y');
			$z = $this->cfg->get('Z');
			if(!$event->isCancelled()){
			if($gracz->getInventory()->getItemInHand()->getId() == 369){
			$gracz->sendMessage("§f• §8> §8[§2xHardCore§8] §7Teleportacja na spawn w toku! §f•");
	        $gracz->teleport(new Position(899, 120, -33, $gracz->getLevel()));
			$effect = Effect::getEffect(15);
			$effect->setDuration(70);
			$effect->setAmplifier(0);
			$effect2 = Effect::getEffect(2);
			$effect2->setDuration(70);
			$effect2->setAmplifier(0);
			$gracz->addEffect($effect);
			$gracz->addEffect($effect2);
			$gracz->getInventory()->removeItem(Item::get(369, 0, 1));
			}
		}
}
}