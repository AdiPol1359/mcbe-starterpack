<?php

namespace SystemBlokKomend;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\command\{Command, CommandSender};
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use pocketmine\utils\Utils;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pockemine\inventory\Inventory;

class Main extends PluginBase implements Listener{
	
	    private $cooldown;
		
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$server = $this->getServer();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§1E§2n§2a§4b§5l§6e§7d§2!");
		}
		
		public function onKomenda(PlayerCommandPreprocessEvent $event){
		$command = explode(" ", strtolower($event->getMessage()));
		$player = $event->getPlayer();
		if($command[0] == "/tpaccept" or $command[0] == "/tpyes"){
		if(!$player->getInventory()->contains(Item::get(388, 0, 3))){
		$event->setCancelled();
		$player->sendMessage("§f• §8> §8[§2xHardCore§8] §7Aby zaakceptowac teleportacje musisz posiadac 3 emeraldy! §f•");
		}
		else{
		$player->getInventory()->removeItem(Item::get(388, 0, 3));
		}
		}
		if($command[0] == "/tpahere" && !$player->hasPermission("komenda.dostep")){
			$event->setCancelled();
		$player->sendMessage("§cYou don't have permission to use this command");
		}
		if($command[0] == "/about" && !$player->hasPermission("komenda.dostep")){
			$event->setCancelled();
		$player->sendMessage("§cYou don't have permission to use this command");
		}
		if($command[0] == "/ver" && !$player->hasPermission("komenda.dostep")){
			$event->setCancelled();
		$player->sendMessage("§cYou don't have permission to use this command");
		}
		if($command[0] == "/version" && !$player->hasPermission("komenda.dostep")){
			$event->setCancelled();
		$player->sendMessage("§cYou don't have permission to use this command");
		}
		if($command[0] == "/about" && !$player->hasPermission("komenda.dostep")){
			$event->setCancelled();
		$player->sendMessage("§cYou don't have permission to use this command");
		}
		if($command[0] == "/help" && !$player->hasPermission("komenda.dostep")){
			$event->setCancelled();
		$player->sendMessage("§cYou don't have permission to use this command");
		}
		if($command[0] == "/?" && !$player->hasPermission("komenda.dostep")){
			$event->setCancelled();
		$player->sendMessage("§cYou don't have permission to use this command");
		}
		if($command[0] == "/list"){
		$event->setCancelled();
		$player->sendMessage("§f• §8> §8[§2xHardCore§8] §7Na serwerze jest aktualnie§2 " . count($this->getServer()->getOnlinePlayers()) . "§7/§2200§7 graczy! §f•");
		}
		}
		public function trueCooldownCode(PlayerCommandPreprocessEvent $event){
		  $player = $event->getPlayer();
		  $command = explode(" ", strtolower($event->getMessage()));
		if(!isset($this->cooldown[$player->getName()])){
			if($command[0] == "/aktywuj"){
        $this->cooldown[$player->getName()] = time();
		//ustawiasz cooldown
		}
		}
		else{
        if(time() - $this->cooldown[$player->getName()] <= 30){
			$dirrerence = time() - (isset($this->cooldown[$player->getName()]) ? $this->cooldown[$player->getName()] : 0);
			if($command[0] == "/aktywuj"){
            //nie moze wykonac bo blokada
			$player->sendMessage("§f• §8> §8[§2xHardCore§8] §7Ta komende mozesz wysylac za§2 " . (30 - $dirrerence) . " §7sekund! §f•");
			$event->setCancelled();
            return true;
		}
        } else{
            $this->cooldown[$player->getName()] = time();
            //zerujemy cooldowna
	  }
		}
	  }
}