<?php

namespace CobbleX;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\command\{Command, CommandSender};
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use pocketmine\utils\Utils;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pockemine\inventory\Inventory;

class Main extends PluginBase implements Listener{
 	
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$server = $this->getServer();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§1E§2n§2a§4b§5l§6e§7d§2!");
		}
		
		public function onBreak(BlockBreakEvent $event){
			$player = $event->getPlayer();
			$block = $event->getBlock();
			$ilosc = rand(1,3);
			if($block->getId() == 129){
			switch(mt_rand(1,10)){
			case 1:
			$player->sendTip("§8> §7DROP: (§2" . $ilosc . "§7) §5Perla");
			if($player->getInventory()->canAddItem(Item::get(344, 0, $ilosc))){
			$player->getInventory()->addItem(Item::get(344, 0, $ilosc));
			$drops = array();
			$drops[] = Item::get(0, 0, 0);
			$event->setDrops($drops);
			}
			else{
			$drops = array();
			$drops[] = Item::get(344, 0, $ilosc);
			$event->setDrops($drops);
			}
			break;
			case 2:
			$player->sendTip("§8> §7DROP: (§2" . $ilosc . "§7) §aTrzcina");
			if($player->getInventory()->canAddItem(Item::get(338, 0, $ilosc))){
			$player->getInventory()->addItem(Item::get(338, 0, $ilosc));
			$drops = array();
			$drops[] = Item::get(0, 0, 0);
			$event->setDrops($drops);
			}
			else{
			$drops = array();
			$drops[] = Item::get(338, 0, $ilosc);
			$event->setDrops($drops);
			}
			break;
			case 3:
			$player->sendTip("§8> §7DROP: (§2" . $ilosc . "§7) §cJablka");
			if($player->getInventory()->canAddItem(Item::get(260, 0, $ilosc))){
			$player->getInventory()->addItem(Item::get(260, 0, $ilosc));
			$drops = array();
			$drops[] = Item::get(0, 0, 0);
			$event->setDrops($drops);
			}
			else{
			$drops = array();
			$drops[] = Item::get(260, 0, $ilosc);
			$event->setDrops($drops);
			}
			break;
			case 4:
			$player->sendTip("§8> §7DROP: (§2" . $ilosc . "§7) §6Zloto");
			if($player->getInventory()->canAddItem(Item::get(266, 0, $ilosc))){
			$player->getInventory()->addItem(Item::get(266, 0, $ilosc));
			$drops = array();
			$drops[] = Item::get(0, 0, 0);
			$event->setDrops($drops);
			}
			else{
			$drops = array();
			$drops[] = Item::get(266, 0, $ilosc);
			$event->setDrops($drops);
			}
			break;
			case 5:
			$player->sendTip("§8> §7DROP: (§2" . $ilosc . "§7) §fNić");
			if($player->getInventory()->canAddItem(Item::get(287, 0, $ilosc))){
			$player->getInventory()->addItem(Item::get(287, 0, $ilosc));
			$drops = array();
			$drops[] = Item::get(0, 0, 0);
			$event->setDrops($drops);
			}
			else{
			$drops = array();
			$drops[] = Item::get(287, 0, $ilosc);
			$event->setDrops($drops);
			}
			break;
			case 6:
			$player->sendTip("§8> §7DROP: (§2" . $ilosc . "§7) §4Redstone");
			if($player->getInventory()->canAddItem(Item::get(331, 0, $ilosc))){
			$player->getInventory()->addItem(Item::get(331, 0, $ilosc));
			$drops = array();
			$drops[] = Item::get(0, 0, 0);
			$event->setDrops($drops);
			}
			else{
			$drops = array();
			$drops[] = Item::get(331, 0, $ilosc);
			$event->setDrops($drops);
			}
			break;
			case 7:
			$player->sendTip("§8> §7DROP: (§2" . $ilosc . "§7) Pioro");
			if($player->getInventory()->canAddItem(Item::get(288, 0, $ilosc))){
			$player->getInventory()->addItem(Item::get(288, 0, $ilosc));
			$drops = array();
			$drops[] = Item::get(0, 0, 0);
			$event->setDrops($drops);
			}
			else{
			$drops = array();
			$drops[] = Item::get(288, 0, $ilosc);
			$event->setDrops($drops);
			}
			break;
			case 8:
			$player->sendTip("§8> §7DROP: (§2" . $ilosc . "§7) Gunpowder");
			if($player->getInventory()->canAddItem(Item::get(289, 0, $ilosc))){
			$player->getInventory()->addItem(Item::get(289, 0, $ilosc));
			$drops = array();
			$drops[] = Item::get(0, 0, 0);
			$event->setDrops($drops);
			}
			else{
			$drops = array();
			$drops[] = Item::get(289, 0, $ilosc);
			$event->setDrops($drops);
			}
			break;
			case 9:
			$player->sendTip("§8> §7DROP: (§2" . $ilosc . "§7) §eDirt");
			if($player->getInventory()->canAddItem(Item::get(3, 0, $ilosc))){
			$player->getInventory()->addItem(Item::get(3, 0, $ilosc));
			$drops = array();
			$drops[] = Item::get(0, 0, 0);
			$event->setDrops($drops);
			}
			else{
			$drops = array();
			$drops[] = Item::get(3, 0, $ilosc);
			$event->setDrops($drops);
			}
			break;
			case 10:
			$player->sendTip("§8> §7DROP: §1NIC");
			break;
			}
			}
}
}