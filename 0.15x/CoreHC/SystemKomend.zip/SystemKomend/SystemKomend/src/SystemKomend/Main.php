<?php

namespace SystemKomend;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\command\{Command, CommandSender};
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use pocketmine\utils\Utils;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pockemine\inventory\Inventory;

class Main extends PluginBase implements Listener{
 	
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$server = $this->getServer();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§1E§2n§2a§4b§5l§6e§7d§2!");
		$this->saveDefaultConfig();
		}
		
		  public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
		  $cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
		  if($cmd->getName() == "vip"){
		  $sender->sendMessage($cfg->get('VipLine1'));
		  $sender->sendMessage($cfg->get('VipLine2'));
		  $sender->sendMessage($cfg->get('VipLine3'));
		  $sender->sendMessage($cfg->get('VipLine4'));
		  $sender->sendMessage($cfg->get('VipLine5'));
		  $sender->sendMessage($cfg->get('VipLine6'));
		  $sender->sendMessage($cfg->get('VipLine7'));
		  $sender->sendMessage($cfg->get('VipLine8'));
		  $sender->sendMessage($cfg->get('VipLine9'));
		  $sender->sendMessage($cfg->get('VipLine10'));
		  $sender->sendMessage($cfg->get('VipLine11'));
		  $sender->sendMessage($cfg->get('VipLine12'));
		  return true;
		  }
		  if($cmd->getName() == "svip"){
		  $sender->sendMessage($cfg->get('SVipLine1'));
		  $sender->sendMessage($cfg->get('SVipLine2'));
		  $sender->sendMessage($cfg->get('SVipLine3'));
		  $sender->sendMessage($cfg->get('SVipLine4'));
		  $sender->sendMessage($cfg->get('SVipLine5'));
		  $sender->sendMessage($cfg->get('SVipLine6'));
		  $sender->sendMessage($cfg->get('SVipLine7'));
		  $sender->sendMessage($cfg->get('SVipLine8'));
		  $sender->sendMessage($cfg->get('SVipLine9'));
		  $sender->sendMessage($cfg->get('SVipLine10'));
		  $sender->sendMessage($cfg->get('SVipLine11'));
		  $sender->sendMessage($cfg->get('SVipLine12'));
		  return true;
		  }
		  if($cmd->getName() == "stoniarka"){
		  if(count($args) == 0){
		  $sender->sendMessage($cfg->get('StoniarkaLine1'));
		  $sender->sendMessage($cfg->get('StoniarkaLine2'));
		  $sender->sendMessage($cfg->get('StoniarkaLine3'));
		  $sender->sendMessage($cfg->get('StoniarkaLine4'));
		  $sender->sendMessage($cfg->get('StoniarkaLine5'));
		  $sender->sendMessage($cfg->get('StoniarkaLine6'));
		  $sender->sendMessage($cfg->get('StoniarkaLine7'));
		  $sender->sendMessage($cfg->get('StoniarkaLine8'));
		  $sender->sendMessage($cfg->get('StoniarkaLine9'));
		  $sender->sendMessage($cfg->get('StoniarkaLine10'));
		  return true;
		  }
		  if(count($args) == 1){
		  $cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
		  if($args[0] == "kup"){
		  if($sender->getInventory()->contains(Item::get(264, 0, 1))){
		  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Zakupiles stoniarke! §f•");
		  $sender->getInventory()->addItem(Item::get(121, 0, 1));
		  $sender->getInventory()->removeItem(Item::get(264, 0, 1));
		  }
		  else{
		  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Aby zakupic stoniarke potrzebujesz 1 diament! §f•");
		  }
		  }
		  }
		  }
		  if($cmd->getName() == "boyfarmer"){
		  if(count($args) == 0){
		  $sender->sendMessage($cfg->get('BoyfarmerLine1'));
		  $sender->sendMessage($cfg->get('BoyfarmerLine2'));
		  $sender->sendMessage($cfg->get('BoyfarmerLine3'));
		  $sender->sendMessage($cfg->get('BoyfarmerLine4'));
		  $sender->sendMessage($cfg->get('BoyfarmerLine5'));
		  $sender->sendMessage($cfg->get('BoyfarmerLine6'));
		  $sender->sendMessage($cfg->get('BoyfarmerLine7'));
		  $sender->sendMessage($cfg->get('BoyfarmerLine8'));
		  $sender->sendMessage($cfg->get('BoyfarmerLine9'));
		  $sender->sendMessage($cfg->get('BoyfarmerLine10'));
		  return true;
		  }
			if(count($args) == 1){
			if($args[0] == "kup"){
			if($sender->getInventory()->contains(Item::get(264, 0, 3)) && $sender->getInventory()->contains(Item::get(49, 0, 5))){
			$sender->getInventory()->removeItem(Item::get(264, 0, 3));
			$sender->getInventory()->removeItem(Item::get(49, 0, 5));
			$item = Item::get(120, 0, 1);
			$item->setCustomName("§5§lBoyFramer");
			$sender->getInventory()->addItem($item);
			$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Zakupiles §aBoyFarmer! §f•");
			}
			else{
			$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Aby zakupic BoyFramer musisz miec 5 obsydianu oraz 3 diamenty! §f•");
			}
			}
			else{
			$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Zly argument! §f•");
		}
		}
		}
		  if($cmd->getName() == "sandfarmer"){
		  if(count($args) == 0){
		  $sender->sendMessage($cfg->get('SandfarmerLine1'));
		  $sender->sendMessage($cfg->get('SandfarmerLine2'));
		  $sender->sendMessage($cfg->get('SandfarmerLine3'));
		  $sender->sendMessage($cfg->get('SandfarmerLine4'));
		  $sender->sendMessage($cfg->get('SandfarmerLine5'));
		  $sender->sendMessage($cfg->get('SandfarmerLine6'));
		  $sender->sendMessage($cfg->get('SandfarmerLine7'));
		  $sender->sendMessage($cfg->get('SandfarmerLine8'));
		  $sender->sendMessage($cfg->get('SandfarmerLine9'));
		  $sender->sendMessage($cfg->get('SandfarmerLine10'));
		  return true;
		  }
  if(count($args) == 1){
  if($args[0] == "kup"){
  if($sender->getInventory()->contains(Item::get(264, 0, 3)) && $sender->getInventory()->contains(Item::get(12, 0, 5))){
  $sender->getInventory()->removeItem(Item::get(264, 0, 3));
  $sender->getInventory()->removeItem(Item::get(12, 0, 5));
  $item = Item::get(120, 0, 1);
  $item->setCustomName("§e§lSandFramer");
  $sender->getInventory()->addItem($item);
  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Zakupiles §aSandFarmer! §f•");
  }
    else{
	$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Aby zakupic SandFramer musisz miec 5 piasku oraz 3 diamenty! §f•");
  }
  }
  else{
  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Zly argument! §f•");
  }
  }
		  }
		  if($cmd->getName() == "fosafarmer"){
		  if(count($args) == 0){
		  $sender->sendMessage($cfg->get('FosafarmerLine1'));
		  $sender->sendMessage($cfg->get('FosafarmerLine2'));
		  $sender->sendMessage($cfg->get('FosafarmerLine3'));
		  $sender->sendMessage($cfg->get('FosafarmerLine4'));
		  $sender->sendMessage($cfg->get('FosafarmerLine5'));
		  $sender->sendMessage($cfg->get('FosafarmerLine6'));
		  $sender->sendMessage($cfg->get('FosafarmerLine7'));
		  $sender->sendMessage($cfg->get('FosafarmerLine8'));
		  $sender->sendMessage($cfg->get('FosafarmerLine9'));
		  $sender->sendMessage($cfg->get('FosafarmerLine10'));
		  return true;
		  }
  if(count($args) == 1){
  if($args[0] == "kup"){
  if($sender->getInventory()->contains(Item::get(264, 0, 5)) && $sender->getInventory()->contains(Item::get(49, 0, 5))){
  $sender->getInventory()->removeItem(Item::get(264, 0, 5));
  $sender->getInventory()->removeItem(Item::get(49, 0, 5));
  $item = Item::get(120, 0, 1);
  $item->setCustomName("§b§lFosaFramer");
  $sender->getInventory()->addItem($item);
  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Zakupiles §aFosaFarmer! §f•");
  }
    else{
	$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Aby zakupic FosaFramer musisz miec 5 obsydianu oraz 5 diamentow! §f•");
  }
  }
  else{
  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Zly argument! §f•");
  }
  }
		  }
		  if($cmd->getName() == "cobblex"){
		  if(count($args) == 0){
		  $sender->sendMessage($cfg->get('CobbleXLine1'));
		  $sender->sendMessage($cfg->get('CobbleXLine2'));
		  $sender->sendMessage($cfg->get('CobbleXLine3'));
		  $sender->sendMessage($cfg->get('CobbleXLine4'));
		  $sender->sendMessage($cfg->get('CobbleXLine5'));
		  $sender->sendMessage($cfg->get('CobbleXLine6'));
		  $sender->sendMessage($cfg->get('CobbleXLine7'));
		  $sender->sendMessage($cfg->get('CobbleXLine8'));
		  $sender->sendMessage($cfg->get('CobbleXLine9'));
		  $sender->sendMessage($cfg->get('CobbleXLine10'));
		  return true;
		  }
		  if(count($args) == 1){
		  $cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
		  if($args[0] == "kup"){
		  if($sender->getInventory()->contains(Item::get(4, 0, 576))){
		  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Zakupiles CobbleX! §f•");
		  $sender->getInventory()->addItem(Item::get(129, 0, 1));
		  $sender->getInventory()->removeItem(Item::get(4, 0, 576));
		  }
		  else{
		  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Aby zakupic CobbleX potrzebujesz 9 stackow cobbla! §f•");
		  }
		  }
		  }
		  }
		}
}