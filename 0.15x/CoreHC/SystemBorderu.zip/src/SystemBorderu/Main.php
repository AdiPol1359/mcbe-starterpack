<?php

namespace SystemBorderu;

use pocketmine\plugin\PluginBase as PluginBase;
use pocketmine\event\Listener as Listener;
use pocketmine\utils\TextFormat;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\utils\Config;
use pocketmine\block\Block;
use pocketmine\block\Air;
use pocketmine\block\Stone;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\scheduler\PluginTask;
use pocketmine\event\player\PlayerMoveEvent;

class Main extends PluginBase implements Listener{

 
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);		
		$this->getServer()->getLogger()->info(TextFormat::GREEN . "Wszelkie błędy zgłaszaj do xSmoothy'iego");
	}
	public function onMove(PlayerMoveEvent $event){
	$player = $event->getPlayer();
	$x = $player->getX();
	$y = $player->getY();
	$z = $player->getZ();
	if($player->getX() >= 5000){
    $player->knockBack($player, 0, -2, 0, 0.5);
	}
	if($player->getZ() >= 5000){
    $player->knockBack($player, 0, 0, -2, 0.5);
	}
	if($player->getZ() <= -5000){
    $player->knockBack($player, 0, 0, 2, 0.5);
	}
	if($player->getX() <= -5000){
    $player->knockBack($player, 0, 2, 0, 0.5);
	}
	}
}