<?php

namespace SystemPunktow;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\IPlayer;
use pocketmine\command\{Command, CommandSender};
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\level\particle\Particle;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use pocketmine\utils\Utils;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pockemine\inventory\Inventory;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDespawnEvent;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\entity\Snowball;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\particle\BubbleParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\BatSound;
use pocketmine\level\sound;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\block\Air;
use pocketmine\block\Obsidian;
use pocketmine\block\Sand;
use pocketmine\block\Stone;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\entity\EntityShootBowEvent;
use pocketmine\entity\Egg;
use pocketmine\event\server\DataPacketReceiveEvent;

class Main extends PluginBase implements Listener{
	
		    public function getAPI()
    {
        return Server::getInstance()->getPluginManager()->getPlugin("FactionsPro");
    }
			    public function getAPI3()
    {
        return Server::getInstance()->getPluginManager()->getPlugin("EconomyAPI");
    }
			
	
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$server = $this->getServer();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§1E§2n§2a§4b§5l§6e§7d§2!");
		}
		
  public function onDestroy(BlockBreakEvent $event){
	  if(!$event->isCancelled()){
    $breakdata = new Config($this->getDataFolder() . "/zniszczone.yml", Config::YAML);
        $name = $event->getPlayer()->getName();
        $breaks = $breakdata->get($name);
        $breakdata->set($name,$breaks+1);
        $breakdata->save();
  }
  }
  public function onPlace(BlockPlaceEvent $event){
	  if(!$event->isCancelled()){
    $placedata = new Config($this->getDataFolder() . "/postawione.yml", Config::YAML);
        $name = $event->getPlayer()->getName();
        $places = $placedata->get($name);
        $placedata->set($name,$places+1);
        $placedata->save();
	}
  }
   public function truePoints(PlayerDeathEvent $event){
    $killdata = new Config($this->getDataFolder() . "/zabicia.yml", Config::YAML);
	$pointdata = new Config($this->getDataFolder() . "/punkty.yml", Config::YAML);
	$deathdata = new Config($this->getDataFolder() . "/smierci.yml", Config::YAML);
	$streakdata = new Config($this->getDataFolder() . "/streak.yml", Config::YAML);
	$ipdata = new Config($this->getDataFolder() . "ip.yml", Config::YAML);
	
	$rand2 = rand(25,40);
	  
    $rand = rand(20,35);
	
	$deaths = $deathdata->get($event->getPlayer()->getName());
	$deathdata->set($event->getPlayer()->getName(),$deaths+1);
    $deathdata->save();
	
	$points = $pointdata->get($event->getPlayer()->getName());
	$pointdata->set($event->getPlayer()->getName(), $points-$rand2);
	$pointdata->save();
	 
	$streaks = $streakdata->get($event->getPlayer()->getName());
	$streakdata->set($event->getPlayer()->getName(), "0");
	$streakdata->save();
	 
    $entity = $event->getEntity();
    $cause = $entity->getLastDamageCause();
    $killer = $cause->getDamager();	 
	$name = $killer->getName();
	
    if($killer instanceof Player){
	$ipdata = new Config($this->getDataFolder() . "ip.yml", Config::YAML);
	$dane = $ipdata->get($killer->getName());
	$abc = explode(',', $dane);
	if(!($abc[0] == $event->getPlayer()->getAddress())){
	  //punkty dla damagera
	  $points = $pointdata->get($name);
	  $name1 = $event->getPlayer()->getName();
	  $pointdata->set($name, $points+$rand);
	  $pointdata->save();
	  // zabojstwo dla damagera
      $kills = $killdata->get($name);
      $killdata->set($name,$kills+1);
      $killdata->save();
	  // streak
	  $name = $killer->getName();
	  $streaks = $streakdata->get($name);
	  if($streaks < 4 or $streaks < 9 or $streaks < 14 or $streaks < 19 or $streaks >= 20){
	  $streakdata->set($name, $streaks+1);
	  $streakdata->save();
	}
	  if($streaks == 4){
	  $streaks = $streakdata->get($name);
	  $streakdata->set($name, "5");
	  $streakdata->save();
	  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Gracz§2 " . $name . " §7osiagnal serie zabojstw w ilosci §25§7! §f•");
	  $killer->getInventory()->addItem(Item::get(368, 0, 1));
	  $killer->addXp(500);
	  }
	  if($streaks == 9){
	  $streaks = $streakdata->get($name);
	  $streakdata->set($name, "10");
	  $streakdata->save();
	  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Gracz§2 " . $name . " §7osiagnal serie zabojstw w ilosci §210§7! §f•");
	  $killer->getInventory()->addItem(Item::get(466, 0, 1));
	  $killer->addXp(5000);
	  }
	  if($streaks == 14){
	  $streaks = $streakdata->get($name);
	  $streakdata->set($name, "15");
	  $streakdata->save();
	  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Gracz§2 " . $name . " §7osiagnal serie zabojstw w ilosci §215§7! §f•");
	  $killer->getInventory()->addItem(Item::get(466, 0, 2));
	  $killer->addXp(50000);
	  }
	  if($streaks == 19){
	  $streaks = $streakdata->get($name);
	  $streakdata->set($name, "20");
	  $streakdata->save();
	  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Gracz§2 " . $name . " §7osiagnal serie zabojstw w ilosci §220§7! §f•");
	  $killer->getInventory()->addItem(Item::get(466, 0, 3));
	  $killer->addXp(500000);
	  }
	  //formalnosci
	  $event->setDeathMessage("§f• §8> §8[§2" . $this->getAPI()->getPlayerFaction($killer->getName()) . "§8] §2" . $killer->getName() . " §8[§2+" . $rand . "§8] §8[§2" . ($killer->getHealth() / 2) . " ❤§8] §7zabil §8[§2" . $this->getAPI()->getPlayerFaction($event->getPlayer()->getName()) . "§8] §2" . $event->getPlayer()->getName() . "  §8[§2-" . $rand2 . "§8] §8[§2" . ($event->getPlayer()->getHealth() / 2) . " ❤§8] §f•");
	  $killer->sendMessage("§f• §8> §8[§2xHardCore§8] §7Otrzymujesz §2" . $rand . " §7punktow za zabicie§2 " . $event->getPlayer()->getName() . "§7! §f•");
	  $event->getPlayer()->sendMessage("§f• §8> §8[§2xHardCore§8] §7Tracisz §2" . $rand2 . " §7punktow za smierc przez§2 " . $killer->getName() . "§7! §f•");
	}
		else{
		$killer->sendMessage("§f• §8> §8[§2xHardCore§8] §7Wykryto ten sam aders ip co u poprzedniej ofiary! Punkty nie zostana dodane. §f•");
		$event->setDeathMessage("§f• §8> §8[§2" . $this->getAPI()->getPlayerFaction($killer->getName()) . "§8] §2" . $killer->getName() . " §8[§2+0§8] §8[§2" . ($killer->getHealth() / 2) . " ❤§8] §7zabil §8[§2" . $this->getAPI()->getPlayerFaction($event->getPlayer()->getName()) . "§8] §2" . $event->getPlayer()->getName() . "  §8[§2-" . $rand2 . "§8] §8[§2" . ($event->getPlayer()->getHealth() / 2) . " ❤§8] §f•");
		$event->getPlayer()->sendMessage("§f• §8> §8[§2xHardCore§8] §7Tracisz §2" . $rand2 . " §7punktow za smierc przez§2 " . $killer->getName() . "§7! §f•");
	}
	  // zapisywanie ip
	  $ip = $event->getPlayer()->getAddress();
	  $ipdata->set($name, $ip . "," . $event->getPlayer()->getName());
	  $ipdata->save();
	}
   }
	public function onQuitStreak(PlayerQuitEvent $event){
	$streakdata = new Config($this->getDataFolder() . "/streak.yml", Config::YAML);
	$name = $event->getPlayer()->getName();
	$streaks = $streakdata->get($name);
	$streakdata->set($event->getPlayer()->getName(), "0");
	$streakdata->save();
	}
	public function onEat(PlayerItemConsumeEvent $event) {
		$i = $event->getItem();
        if($i->getId() == 466) {
		if(!$event->isCancelled()){
		$koxydata = new Config($this->getDataFolder() . "/koxy.yml", Config::YAML);
        $name = $event->getPlayer()->getDisplayName();
        $koxys = $koxydata->get($name);
        $koxydata->set($name,$koxys+1);
        $koxydata->save();
		}
		}
		$i = $event->getItem();
		if($i->getId() == 322) {
	    if(!$event->isCancelled()){
		$refiledata = new Config($this->getDataFolder() . "/refile.yml", Config::YAML);
        $name = $event->getPlayer()->getDisplayName();
        $refiles = $refiledata->get($name);
        $refiledata->set($name,$refiles+1);
        $refiledata->save();
	}
	}
	}
	public function onProjectileLaunch(ProjectileLaunchEvent $event){
		$entity = $event->getEntity();
		if($entity instanceof Egg){
		if(!$event->isCancelled()){
		$perlydata = new Config($this->getDataFolder() . "/perly.yml", Config::YAML);
        $shooter = $entity->shootingEntity;
		$name = $shooter->getName();
        $pearls = $perlydata->get($name);
        $perlydata->set($name,$pearls+1);
        $perlydata->save();
		}
	}
	}
	
  public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
	  //// BEZ ARGUMENTU \\\\
        if($cmd->getName() == "gracz"){
			if($sender instanceof Player) {
				if(empty($args)){
			$gracz = $sender->getName();
            $deathdata = new Config($this->getDataFolder() . "/smierci.yml", Config::YAML);
            $deaths = $deathdata->get($sender->getName());
            $killdata = new Config($this->getDataFolder() . "/zabicia.yml", Config::YAML);
            $kills = $killdata->get($sender->getName());
            $breakdata = new Config($this->getDataFolder() . "/zniszczone.yml", Config::YAML);
            $breaks = $breakdata->get($sender->getName());
            $placedata = new Config($this->getDataFolder() . "/postawione.yml", Config::YAML);
			$places = $placedata->get($sender->getName());
			$koxydata = new Config($this->getDataFolder() . "/koxy.yml", Config::YAML);
            $koxys = $koxydata->get($sender->getName());
			$refiledata = new Config($this->getDataFolder() . "/refile.yml", Config::YAML);
            $refiles = $refiledata->get($sender->getName());
			$perlydata = new Config($this->getDataFolder() . "/perly.yml", Config::YAML);
            $pearls = $perlydata->get($sender->getName());
			$pointdata = new Config($this->getDataFolder() . "/punkty.yml", Config::YAML);
			$points = $pointdata->get($sender->getName());
			$streakdata = new Config($this->getDataFolder() . "/streak.yml", Config::YAML);
			$streaks = $streakdata->get($sender->getName());
			$ip = new Config($this->getDataFolder() . "ip.yml", Config::YAML);
			$lol = $ip->get($sender->getName());
			$ips = explode(',', $lol);
			$playername = $sender->getName();
			$gildia = $this->getAPI()->getPlayerFaction($gracz);
			$monety = $this->getAPI3()->myMoney($gracz);
			$monety2 = $this->getAPI3()->getMonetaryUnit();
			$razem = $refiles + $koxys;
			$sender->sendMessage("§8[§7 =============§8 [ §2§lGRACZ §r§8] §7============= §8]");
			$sender->sendMessage("§2* §7Gracz: §2" . $gracz . "");
			if($this->getAPI()->isInFaction($sender->getName())){
			$sender->sendMessage("§2* §7Gildia: §2" . strtoupper($gildia) . "");
			}
			else{
			$sender->sendMessage("§2* §7Gildia: §2BRAK GILDII");
			}
			$sender->sendMessage("§2* §7Punkty: §2" . $points . "");
			$sender->sendMessage("§2* §7Monety: §2" . $monety . "" . $monety2 . "");
			$sender->sendMessage("§2* §7Zabojstwa: §2" . $kills . "");
			$sender->sendMessage("§2* §7Smierci: §2" . $deaths . "");
			$sender->sendMessage(str_replace(array('NAN', 'INF'), '0.00', "§2* §7K/D: §2" . round($kills / $deaths, 2) . ""));
			$sender->sendMessage("§2* §7Wykopane Bloki: §2" . $breaks . "");
			$sender->sendMessage("§2* §7Postawione Bloki: §2" . $places . "");
			$sender->sendMessage("§2* §7Zjedzone Koxy: §2" . $koxys . "");
			$sender->sendMessage("§2* §7Zjedzone Refile: §2" . $refiles . "");
			$sender->sendMessage("§2* §7Razem zjedzonych: §2" . $razem . "");
			$sender->sendMessage("§2* §7Rzucone Perly: §2" . $pearls . "");
			$sender->sendMessage("§2* §7Seria Zabojstw: §2" . $streaks . "");
			$sender->sendMessage("§2* §7Ostatnia Ofiara: §2" . $ips[1] . "");
			$sender->sendMessage("§2* §7Zbanowany: §2NIE");
			$sender->sendMessage("§2* §7Online: §2TAK");
			$sender->sendMessage("§8[§7 =============§8 [ §2§lGRACZ §r§8] §7============= §8]");
			}
			}
			///// Z ARGUMENTEM \\\\\\
			if(count($args) == 1){
			$playername = $args[0];
            $killdata = new Config($this->getDataFolder() . "/zabicia.yml", Config::YAML);
            $kills = $killdata->get($playername);
            $deathdata = new Config($this->getDataFolder() . "/smierci.yml", Config::YAML);
            $deaths = $deathdata->get($playername);
            $breakdata = new Config($this->getDataFolder() . "/zniszczone.yml", Config::YAML);
            $breaks = $breakdata->get($playername);
            $placedata = new Config($this->getDataFolder() . "/postawione.yml", Config::YAML);
            $places = $placedata->get($playername);
			$koxydata = new Config($this->getDataFolder() . "/koxy.yml", Config::YAML);
            $koxys = $koxydata->get($playername);
			$refiledata = new Config($this->getDataFolder() . "/refile.yml", Config::YAML);
            $refiles = $refiledata->get($playername);
			$perlydata = new Config($this->getDataFolder() . "/perly.yml", Config::YAML);
            $pearls = $perlydata->get($playername);
			$pointdata = new Config($this->getDataFolder() . "/punkty.yml", Config::YAML);
			$points = $pointdata->get($playername);
			$streakdata = new Config($this->getDataFolder() . "/streak.yml", Config::YAML);
			$streaks = $streakdata->get($playername);
			$ip = new Config($this->getDataFolder() . "ip.yml", Config::YAML);
			$lol = $ip->get($playername);
			$ips = explode(',', $lol);
			$gildia = $this->getAPI()->getPlayerFaction($playername);
			$monety = $this->getAPI3()->myMoney($playername);
			$monety2 = $this->getAPI3()->getMonetaryUnit();
			$razem = $refiles + $koxys;
			if($killdata->exists($playername) &&  $deathdata->exists($playername) &&  $breakdata->exists($playername) &&  $placedata->exists($playername) &&  $koxydata->exists($playername) &&  $refiledata->exists($playername)){
			if($this->getServer()->getNameBans()->isBanned(strtolower($playername))){
			$sender->sendMessage("§8[§7 =============§8 [ §2§lGRACZ §r§8] §7============= §8]");
			$sender->sendMessage("§2* §7Gracz: §2" . $playername . "");
			if($this->getAPI()->isInFaction($args[0])){
			$sender->sendMessage("§2* §7Gildia: §2" . strtoupper($gildia) . "");
			}
			else{
			$sender->sendMessage("§2* §7Gildia: §2BRAK GILDII");
			}
			$sender->sendMessage("§2* §7Punkty: §2" . $points . "");
			$sender->sendMessage("§2* §7Monety: §2" . $monety . "" . $monety2 . "");
			$sender->sendMessage("§2* §7Zabojstwa: §2" . $kills . "");
			$sender->sendMessage("§2* §7Smierci: §2" . $deaths . "");
			$sender->sendMessage(str_replace(array('NAN', 'INF'), '0.00', "§2* §7K/D: §2" . round($kills / $deaths, 2) . ""));
			$sender->sendMessage("§2* §7Wykopane Bloki: §2" . $breaks . "");
			$sender->sendMessage("§2* §7Postawione Bloki: §2" . $places . "");
			$sender->sendMessage("§2* §7Zjedzone Koxy: §2" . $koxys . "");
			$sender->sendMessage("§2* §7Zjedzone Refile: §2" . $refiles . "");
			$sender->sendMessage("§2* §7Razem zjedzonych: §2" . $razem . "");
			$sender->sendMessage("§2* §7Rzucone Perly: §2" . $pearls . "");
			$sender->sendMessage("§2* §7Seria Zabojstw: §2" . $streaks . "");
			$sender->sendMessage("§2* §7Ostatnia Ofiara: §2" . $ips[1] . "");
			$sender->sendMessage("§2* §7Zbanowany: §2TAK");
			$sender->sendMessage("§2* §7Online: §2NIE");
			$sender->sendMessage("§8[§7 =============§8 [ §2§lGRACZ §r§8] §7============= §8]");
			}
			else{
			$sender->sendMessage("§8[§7 =============§8 [ §2§lGRACZ §r§8] §7============= §8]");
			$sender->sendMessage("§2* §7Gracz: §2" . $playername . "");
			if($this->getAPI()->isInFaction($args[0])){
			$sender->sendMessage("§2* §7Gildia: §2" . strtoupper($gildia) . "");
			}
			else{
			$sender->sendMessage("§2* §7Gildia: §2BRAK GILDII");
			}
			$sender->sendMessage("§2* §7Punkty: §2" . $points . "");
			$sender->sendMessage("§2* §7Monety: §2" . $monety . "" . $monety2 . "");
			$sender->sendMessage("§2* §7Zabojstwa: §2" . $kills . "");
			$sender->sendMessage("§2* §7Smierci: §2" . $deaths . "");
			$sender->sendMessage(str_replace(array('NAN', 'INF'), '0.00', "§2* §7K/D: §2" . round($kills / $deaths, 2) . ""));
			$sender->sendMessage("§2* §7Wykopane Bloki: §2" . $breaks . "");
			$sender->sendMessage("§2* §7Postawione Bloki: §2" . $places . "");
			$sender->sendMessage("§2* §7Zjedzone Koxy: §2" . $koxys . "");
			$sender->sendMessage("§2* §7Zjedzone Refile: §2" . $refiles . "");
			$sender->sendMessage("§2* §7Razem zjedzonych: §2" . $razem . "");
			$sender->sendMessage("§2* §7Rzucone Perly: §2" . $pearls . "");
			$sender->sendMessage("§2* §7Seria Zabojstw: §2" . $streaks . "");
			$sender->sendMessage("§2* §7Ostatnia Ofiara: §2" . $ips[1] . "");
			$sender->sendMessage("§2* §7Zbanowany: §2NIE");
			if($this->getServer()->getPlayer($args[0]) instanceof Player){
			$sender->sendMessage("§2* §7Online: §2TAK");	
			}
			else{
			$sender->sendMessage("§2* §7Online: §2NIE");		
			}
			$sender->sendMessage("§8[§7 =============§8 [ §2§lGRACZ §r§8] §7============= §8]");
			}
  }
  else{
	  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Nie odnaleziono takiej osoby w bazie danych! §f•");
  }
			}
		}
		if($cmd->getName() == "topka"){
		 if(count($args) == 0){
		 $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzycie: /topka zabojstwa/smierci/koxy/refy/gornik/punkty §f•");
		 }
		if(count($args) == 1){
	      if($args[0] == "punkty"){
		$this->sendTopPoints($sender, 10);
		$sender->sendMessage("§8[ §7----------- §8[ §2§lRANKING PUNKTOW §r§8] §7----------- §8]");
		}
		if($args[0] == "zabojstwa"){
		$this->sendTopKills($sender, 10);
		$sender->sendMessage("§8[ §7----------- §8[ §2§lRANKING ZABOJCOW §r§8] §7----------- §8]");
		}
		if($args[0] == "gornik"){
		$this->sendTopGornik($sender, 10);
		$sender->sendMessage("§8[ §7----------- §8[ §2§lRANKING GORNIKOW §r§8] §7----------- §8]");	
		}
		if($args[0] == "smierci"){
		$this->sendTopSmierci($sender, 10);
		$sender->sendMessage("§8[ §7----------- §8[ §2§lRANKING SMIERCI §r§8] §7----------- §8]");	
		}
		if($args[0] == "koxy"){
		$this->sendTopKoxy($sender, 10);
			$sender->sendMessage("§8[ §7----------- §8[ §2§lRANKING ZJEDZONYCH KOXOW §r§8] §7----------- §8]");	
		}
		if($args[0] == "refy"){
		$this->sendTopRefy($sender, 10);
		$sender->sendMessage("§8[ §7----------- §8[ §2§lRANKING ZJEDZONYCH REFOW §r§8] §7----------- §8]");	
		}
		}
		}
	 }
	   public function sendTopPoints($player, int $amount){
	  $monety = new Config($this->getDataFolder() . "/punkty.yml", Config::YAML);
	  $this->eloyaml = $monety;
   $array = $this->eloyaml->getAll();
    arsort($array);
       $arraykeys = array_keys($array);
       $arrayvalues = array_values($array);
    $player->sendMessage("§8[ §7----------- §8[ §2§lRANKING PUNKTOW §r§8] §7----------- §8]");
     for($i = 0; $i < $amount; $i++){
       $player->sendMessage("§2".($i + 1.)."§7. Gracz:§2 ".$arraykeys[$i]." §7-§2 ".$arrayvalues[$i]." §7Punktów");
   }
}
  public function sendTopKills($player, int $amount){
	  $monety = new Config($this->getDataFolder() . "/zabicia.yml", Config::YAML);
	  $this->eloyaml = $monety;
   $array = $this->eloyaml->getAll();
    arsort($array);
       $arraykeys = array_keys($array);
       $arrayvalues = array_values($array);
    $player->sendMessage("§8[ §7----------- §8[ §2§lRANKING ZABOJCOW §r§8] §7----------- §8]");
     for($i = 0; $i < $amount; $i++){
       $player->sendMessage("§2".($i + 1.)."§7. Gracz:§2 ".$arraykeys[$i]." §7-§2 ".$arrayvalues[$i]." §7Zabojstw");
   }
}
    public function sendTopGornik($player, int $amount){
	  $monety = new Config($this->getDataFolder() . "/zniszczone.yml", Config::YAML);
	  $this->eloyaml = $monety;
   $array = $this->eloyaml->getAll();
    arsort($array);
       $arraykeys = array_keys($array);
       $arrayvalues = array_values($array);
    $player->sendMessage("§8[ §7----------- §8[ §2§lRANKING GORNIKOW §r§8] §7----------- §8]");
     for($i = 0; $i < $amount; $i++){
       $player->sendMessage("§2".($i + 1.)."§7. Gracz:§2 ".$arraykeys[$i]." §7-§2 ".$arrayvalues[$i]." §7Zniszczonych Blokow");
   }
}
    public function sendTopSmierci($player, int $amount){
	  $monety = new Config($this->getDataFolder() . "/smierci.yml", Config::YAML);
	  $this->eloyaml = $monety;
   $array = $this->eloyaml->getAll();
    arsort($array);
       $arraykeys = array_keys($array);
       $arrayvalues = array_values($array);
    $player->sendMessage("§8[ §7----------- §8[ §2§lRANKING SMIERCI §r§8] §7----------- §8]");
     for($i = 0; $i < $amount; $i++){
       $player->sendMessage("§2".($i + 1.)."§7. Gracz:§2 ".$arraykeys[$i]." §7-§2 ".$arrayvalues[$i]." §7Smierci");
   }
}
    public function sendTopRefy($player, int $amount){
	  $monety = new Config($this->getDataFolder() . "refile.yml", Config::YAML);
	  $this->eloyaml = $monety;
   $array = $this->eloyaml->getAll();
    arsort($array);
       $arraykeys = array_keys($array);
       $arrayvalues = array_values($array);
    $player->sendMessage("§8[ §7----------- §8[ §2§lRANKING ZJEDZONYCH REFOW §r§8] §7----------- §8]");
     for($i = 0; $i < $amount; $i++){
       $player->sendMessage("§2".($i + 1.)."§7. Gracz:§2 ".$arraykeys[$i]." §7-§2 ".$arrayvalues[$i]." §7Zjedzonych refow");
   }
}
    public function sendTopKoxy($player, int $amount){
	  $monety = new Config($this->getDataFolder() . "/koxy.yml", Config::YAML);
	  $this->eloyaml = $monety;
   $array = $this->eloyaml->getAll();
    arsort($array);
       $arraykeys = array_keys($array);
       $arrayvalues = array_values($array);
    $player->sendMessage("§8[ §7----------- §8[ §2§lRANKING ZJEDZONYCH KOXOW §r§8] §7----------- §8]");
     for($i = 0; $i < $amount; $i++){
       $player->sendMessage("§2".($i + 1.)."§7. Gracz:§2 ".$arraykeys[$i]." §7-§2 ".$arrayvalues[$i]." §7Zjedzonych koxow");
   }
}
	 	public function trueYAMLRegisters(PlayerJoinEvent $event){
		$player = $event->getPlayer()->getName();
            $killdata = new Config($this->getDataFolder() . "/zabicia.yml", Config::YAML);
            $kills = $killdata->get($player);
            $deathdata = new Config($this->getDataFolder() . "/smierci.yml", Config::YAML);
            $deaths = $deathdata->get($player);
            $breakdata = new Config($this->getDataFolder() . "/zniszczone.yml", Config::YAML);
            $breaks = $breakdata->get($player);
            $placedata = new Config($this->getDataFolder() . "/postawione.yml", Config::YAML);
            $places = $placedata->get($player);
			$joindata = new Config($this->getDataFolder() . "/odwiedzil.yml", Config::YAML);
            $joins = $joindata->get($player);
			$koxydata = new Config($this->getDataFolder() . "/koxy.yml", Config::YAML);
            $koxys = $koxydata->get($player);
			$refiledata = new Config($this->getDataFolder() . "/refile.yml", Config::YAML);
            $refiles = $refiledata->get($player);
			$perlydata = new Config($this->getDataFolder() . "/perly.yml", Config::YAML);
            $pearls = $perlydata->get($player);
			$lvldata = new Config($this->getDataFolder() . "/lvl.yml", Config::YAML);
            $lvls = $lvldata->get($player);
			$ipdata = new Config($this->getDataFolder() . "/pickup.yml", Config::YAML);
			$acdata = new Config($this->getDataFolder() . "ac.yml", Config::YAML);
			$pointdata = new Config($this->getDataFolder() . "/punkty.yml", Config::YAML);
			$ips = $ipdata->get($player);
			$koxy1 = new Config($this->getDataFolder() . "schowekkoxy.yml", Config::YAML);
			$refy1 = new Config($this->getDataFolder() . "schowekrefy.yml", Config::YAML);
			$perly1 = new Config($this->getDataFolder() . "schowekperly.yml", Config::YAML);
			$ajpi = new Config($this->getDataFolder() . "ip.yml", Config::YAML);
			$streakdata = new Config($this->getDataFolder() . "streak.yml", Config::YAML);
			if($killdata->exists($player)){
			}
			else{
				$killdata->set($player, "0");
				$killdata->save();
			}
						if($deathdata->exists($player)){
			}
			else{
				$deathdata->set($player, "0");
				$deathdata->save();
			}
						if($placedata->exists($player)){
			}
			else{
				$placedata->set($player, "0");
				$placedata->save();
			}
						if($breakdata->exists($player)){
			}
			else{
				$breakdata->set($player, "0");
				$breakdata->save();
			}
						if($koxydata->exists($player)){
			}
			else{
				$koxydata->set($player, "0");
				$koxydata->save();
			}
						if($refiledata->exists($player)){
			}
			else{
				$refiledata->set($player, "0");
				$refiledata->save();
			}
						if($perlydata->exists($player)){
			}
			else{
				$perlydata->set($player, "0");
				$perlydata->save();
			}
			if($ipdata->exists($player)){
			}
			else{
				$ipdata->set($player, "1");
				$ipdata->save();
			}
			if($koxy1->exists($player)){
			}
			else{
				$koxy1->set($player, "0");
				$koxy1->save();
			}
			if($refy1->exists($player)){
			}
			else{
				$refy1->set($player, "0");
				$refy1->save();
			}
			if($perly1->exists($player)){
			}
			else{
				$perly1->set($player, "0");
				$perly1->save();
			}
			if($pointdata->exists($player)){
			}
			else{
				$pointdata->set($player, "500");
				$pointdata->save();
			}
			if($ajpi->exists($player)){
			}
			else{
				$def = "0.0.0.0";
				$nick = "BRAK";
				$ajpi->set($player, $def . "," . $nick);
				$ajpi->save();
			}
			if($streakdata->exists($player)){
			}
			else{
				$streakdata->set($player, "0");
				$streakdata->save();
			}
	}
	public function getElo(String $playername){
	$lvl = new Config($this->getDataFolder() . "/punkty.yml", Config::YAML);
	if($lvl->exists($playername)){
		$lvls = $lvl->get($playername);
		return $lvls;
	}
	return null;
}
}