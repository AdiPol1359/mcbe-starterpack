<?php

namespace SystemDropu;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\command\{Command, CommandSender};
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use pocketmine\utils\Utils;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pockemine\inventory\Inventory;

class Main extends PluginBase implements Listener{
 	
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$server = $this->getServer();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§1E§2n§2a§4b§5l§6e§7d§2!");
		}
		
		public function onBreak(BlockBreakEvent $event){
		$diament = new Config($this->getDataFolder() . "diament.yml", Config::YAML);
		$zloto = new Config($this->getDataFolder() . "zloto.yml", Config::YAML);
		$zelazo = new Config($this->getDataFolder() . "zelazo.yml", Config::YAML);
		$trzcina = new Config($this->getDataFolder() . "trzcina.yml", Config::YAML);
		$tnt = new Config($this->getDataFolder() . "tnt.yml", Config::YAML);
		$wegiel = new Config($this->getDataFolder() . "wegiel.yml", Config::YAML);
		$emerald = new Config($this->getDataFolder() . "emerald.yml", Config::YAML);
		$redstone = new Config($this->getDataFolder() . "redstone.yml", Config::YAML);
		$obsidian = new Config($this->getDataFolder() . "obsidian.yml", Config::YAML);
		$lapis = new Config($this->getDataFolder() . "lapis.yml", Config::YAML);
		$cfg = new Config($this->getDataFolder() . "drop.yml", Config::YAML);
		$block = $event->getBlock();
		$player = $event->getPlayer();
		$rand = rand(1,3);
		$cfg = new Config($this->getDataFolder() . "drop.yml", Config::YAML);
		$name = "drop";
		if($cfg->get($name) == 0){
		if($block->getId() == 1){
		$player->addExperience(1);
		if(!$event->isCancelled()){
        switch(mt_rand(1,500)){
			case 1:
			if($diament->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(264, 0, $rand));
			$player->sendTip("§8[§b+" . $rand . "§8] §bDiament");
			}
			break;
			case 2:
			if($tnt->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(46, 0, $rand));
			$player->sendTip("§8[§c+" . $rand . "§8] §cTNT");
			}
			break;
			case 3:
			if($trzcina->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(338, 0, $rand));
			$player->sendTip("§8[§2+" . $rand . "§8] §aTrzcina");
			}
			break;
			case 4:
			if($zloto->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(266, 0, $rand));
			$player->sendTip("§8[§6+" . $rand . "§8] §6Zloto");
			}
			break;
			case 5:
			if($zelazo->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(265, 0, $rand));
			$player->sendTip("§8[§f+" . $rand . "§8] §fZelazo");
			}
			break;
			case 6:
			if($emerald->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(388, 0, $rand));
			$player->sendTip("§8[§2+" . $rand . "§8] §2Emerald");
			}
			break;
			case 7:
			if($wegiel->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(263, 0, $rand));
			$player->sendTip("§8[§7+" . $rand . "§8] §7Wegiel");
			}
			break;
			case 8:
			if($redstone->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(331, 0, $rand));
			$player->sendTip("§8[§4+" . $rand . "§8] §4Redstone");
			}
			break;
			case 9:
			if($obsidian->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(49, 0, $rand));
			$player->sendTip("§8[§4+" . $rand . "§8] §5Obsidian");
			}
			break;
			case 10:
			if($lapis->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(351, 4, $rand));
			$player->sendTip("§8[§b+" . $rand . "§8] §bLapis");
			}
			break;
		}
		}
   }
		}
		   else{
			if($block->getId() == 1){
			$player->addExperience(2);
			if(!$event->isCancelled()){
            switch(mt_rand(1,350)){
			case 1:
			if($diament->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(264, 0, $rand));
			$player->sendTip("§8[§b+" . $rand . "§8] §bDiament");
			}
			break;
			case 2:
			if($tnt->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(46, 0, $rand));
			$player->sendTip("§8[§c+" . $rand . "§8] §cTNT");
			}
			break;
			case 3:
			if($trzcina->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(338, 0, $rand));
			$player->sendTip("§8[§a+" . $rand . "§8] §aTrzcina");
			}
			break;
			case 4:
			if($zloto->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(266, 0, $rand));
			$player->sendTip("§8[§6+" . $rand . "§8] §6Zloto");
			}
			break;
			case 5:
			if($zelazo->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(265, 0, $rand));
			$player->sendTip("§8[§f+" . $rand . "§8] §fZelazo");
			}
			break;
			case 6:
			if($emerald->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(388, 0, $rand));
			$player->sendTip("§8[§2+" . $rand . "§8] §2Emerald");
			}
			break;
			case 7:
			if($wegiel->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(263, 0, $rand));
			$player->sendTip("§8[§7+" . $rand . "§8] §7Wegiel");
			}
			break;
			case 8:
			if($redstone->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(331, 0, $rand));
			$player->sendTip("§8[§4+" . $rand . "§8] §4Redstone");
			}
			break;
			case 9:
			if($obsidian->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(49, 0, $rand));
			$player->sendTip("§8[§5+" . $rand . "§8] §5Obsidian");
			}
			break;
			case 10:
			if($lapis->get($event->getPlayer()->getName()) == 0){
			$player->getInventory()->addItem(Item::get(351, 4, $rand));
			$player->sendTip("§8[§b+" . $rand . "§8] §bLapis");
			}
			break;
}
		}
	}
		}
		}
		public function onCommand(CommandSender $sender, Command $cmd, $label, array $args) {
		$diament = new Config($this->getDataFolder() . "diament.yml", Config::YAML);
		$zloto = new Config($this->getDataFolder() . "zloto.yml", Config::YAML);
		$zelazo = new Config($this->getDataFolder() . "zelazo.yml", Config::YAML);
		$trzcina = new Config($this->getDataFolder() . "trzcina.yml", Config::YAML);
		$tnt = new Config($this->getDataFolder() . "tnt.yml", Config::YAML);
		$wegiel = new Config($this->getDataFolder() . "wegiel.yml", Config::YAML);
		$emerald = new Config($this->getDataFolder() . "emerald.yml", Config::YAML);
		$redstone = new Config($this->getDataFolder() . "redstone.yml", Config::YAML);
		$obsidian = new Config($this->getDataFolder() . "obsidian.yml", Config::YAML);
		$lapis = new Config($this->getDataFolder() . "lapis.yml", Config::YAML);
		$cfg = new Config($this->getDataFolder() . "drop.yml", Config::YAML);
		if($cmd->getName() == "drop"){
		if(count($args) == 0){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop x2/lapis/obsidian/diament/zloto/zelazo/trzcina/redstone/wegiel/tnt/emerald on/off §f•");
		}
		if(count($args) == 1){
		if($sender->hasPermission("drop.x2.admin")){
		if($args[0] == "x2"){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop §1x2§7 on/off §f•");
		}
		}
		else{
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Nie masz dostepu do tej komendy! §f•");
		}
		if($args[0] == "zloto"){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop §6zloto§7 on/off §f•");
		}
		if($args[0] == "diament"){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop §bdiament§7 on/off §f•");
		}
		if($args[0] == "zelazo"){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop §fzelazo§7 on/off §f•");
		}
		if($args[0] == "trzcina"){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop §atrzcina§7 on/off §f•");
		}
		if($args[0] == "redstone"){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop §4redstone§7 on/off §f•");
		}
		if($args[0] == "wegiel"){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop §8wegiel§7 on/off §f•");
		}
		if($args[0] == "tnt"){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop §ctnt§7 on/off §f•");
		}
		if($args[0] == "emerald"){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop §2emerald§7 on/off §f•");
		}
		if($args[0] == "obsidian"){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop §5obsidian§7 on/off §f•");
		}
		if($args[0] == "lapis"){
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyjcie: /drop §blapis§7 on/off §f•");
		}
		if($args[0] == "list"){
		$sender->sendMessage("§8[ §7==========§8 [ §2§lDROP§r§8 ] §7===========§8]");
	    if($diament->get($sender->getName()) == 0){
		$sender->sendMessage("§2* §7Diament §8[§2ON§8]");
		}
	    if($zelazo->get($sender->getName()) == 0){
		$sender->sendMessage("§2* §7Zelazo §8[§2ON§8]");
		}
		if($zloto->get($sender->getName()) == 0){
		$sender->sendMessage("§2* §7Zloto §8[§2ON§8]");
		}
		if($trzcina->get($sender->getName()) == 0){
		$sender->sendMessage("§2* §7Trzcina §8[§2ON§8]");
		}
		if($tnt->get($sender->getName()) == 0){
		$sender->sendMessage("§2* §7TNT §8[§2ON§8]");
		}
		if($wegiel->get($sender->getName()) == 0){
		$sender->sendMessage("§2* §7Wegiel §8[§2ON§8]");
		}
		if($emerald->get($sender->getName()) == 0){
		$sender->sendMessage("§2* §7Emerald §8[§2ON§8]");
		}
		if($redstone->get($sender->getName()) == 0){
		$sender->sendMessage("§2* §7Redstone §8[§2ON§8]");
		}
		if($obsidian->get($sender->getName()) == 0){
		$sender->sendMessage("§2* §7Obsidian §8[§2ON§8]");
		}
		if($lapis->get($sender->getName()) == 0){
		$sender->sendMessage("§2* §7Lapis §8[§2ON§8]");
		}
		if($cfg->get("drop") == 1){
		$sender->sendMessage("§2* §7DROP x2 §8[§2ON§8]");
		}
		
		if($diament->get($sender->getName()) == 1){
		$sender->sendMessage("§2* §7Diament §8[§cOFF§8]");
		}
	    if($zelazo->get($sender->getName()) == 1){
		$sender->sendMessage("§2* §7Zelazo §8[§cOFF§8]");
		}
		if($zloto->get($sender->getName()) == 1){
		$sender->sendMessage("§2* §7Zloto §8[§cOFF§8]");
		}
		if($trzcina->get($sender->getName()) == 1){
		$sender->sendMessage("§2* §7Trzcina §8[§cOFF§8]");
		}
		if($tnt->get($sender->getName()) == 1){
		$sender->sendMessage("§2* §7TNT §8[§cOFF§8]");
		}
		if($wegiel->get($sender->getName()) == 1){
		$sender->sendMessage("§2* §7Wegiel §8[§cOFF§8]");
		}
		if($emerald->get($sender->getName()) == 1){
		$sender->sendMessage("§2* §7Emerald §8[§cOFF§8]");
		}
		if($redstone->get($sender->getName()) == 1){
		$sender->sendMessage("§2* §7Redstone §8[§cOFF§8]");
		}
		if($obsidian->get($sender->getName()) == 1){
		$sender->sendMessage("§2* §7Obsidian §8[§cOFF§8]");
		}
		if($lapis->get($sender->getName()) == 1){
		$sender->sendMessage("§2* §7Lapis §8[§cOFF§8]");
		}
		if($cfg->get("drop") == 0){
		$sender->sendMessage("§2* §7DROP x2 §8[§cOFF§8]");
		}
		$sender->sendMessage("§8[ §7==========§8 [ §2§lDROP§r§8 ] §7===========§8]");
		}
		}
		if(count($args) == 2){
		if($args[0] == "x2" && $args[1] == "on"){
		if($sender->hasPermission("drop.x2.admin")){
		$cfg = new Config($this->getDataFolder() . "drop.yml", Config::YAML);
		$name = "drop";
		$cfg->set($name, 1);
		$cfg->save();
		$this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Drop §2x2 §7zostal włączony przez§2 " . $sender->getName() ." §f•");
		}
		else{
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Nie posiadasz wystaraczajacych pozwolen aby uzyc tej komendy §f•");
		}
		}
		if($args[0] == "x2" && $args[1] == "off"){
		if($sender->hasPermission("drop.x2.admin")){
		$cfg = new Config($this->getDataFolder() . "drop.yml", Config::YAML);
		$name = "drop";
		$cfg->set($name, 0);
		$cfg->save();
		$this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Drop §2x2 §7zostal wyłączony przez§2 " . $sender->getName() . " §f•");
		}
		else{
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Nie posiadasz wystaraczajacych pozwolen aby uzyc tej komendy §f•");
		}
		}
		if($args[0] == "all" && $args[1] == "on"){
		$diament = new Config($this->getDataFolder() . "diament.yml", Config::YAML);
		$zloto = new Config($this->getDataFolder() . "zloto.yml", Config::YAML);
		$zelazo = new Config($this->getDataFolder() . "zelazo.yml", Config::YAML);
		$trzcina = new Config($this->getDataFolder() . "trzcina.yml", Config::YAML);
		$tnt = new Config($this->getDataFolder() . "tnt.yml", Config::YAML);
		$wegiel = new Config($this->getDataFolder() . "wegiel.yml", Config::YAML);
		$emerald = new Config($this->getDataFolder() . "emerald.yml", Config::YAML);
		$redstone = new Config($this->getDataFolder() . "redstone.yml", Config::YAML);
		$obsidian = new Config($this->getDataFolder() . "obsidian.yml", Config::YAML);
		$lapis = new Config($this->getDataFolder() . "lapis.yml", Config::YAML);
		$name = $sender->getName();
		$diament->set($name, 0);
		$diament->save();
		$zloto->set($name, 0);
		$zloto->save();
		$zelazo->set($name, 0);
		$zelazo->save();
		$trzcina->set($name, 0);
		$trzcina->save();
		$tnt->set($name, 0);
		$tnt->save();
		$wegiel->set($name, 0);
		$wegiel->save();
		$emerald->set($name, 0);
		$emerald->save();
		$redstone->set($name, 0);
		$redstone->save();
		$obsidian->set($name, 0);
		$obsidian->save();
		$lapis->set($name, 0);
		$lapis->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §ewszstkich itemow§7 zostal włączony! §f•");
		}
		
		if($args[0] == "all" && $args[1] == "off"){
		$diament = new Config($this->getDataFolder() . "diament.yml", Config::YAML);
		$zloto = new Config($this->getDataFolder() . "zloto.yml", Config::YAML);
		$zelazo = new Config($this->getDataFolder() . "zelazo.yml", Config::YAML);
		$trzcina = new Config($this->getDataFolder() . "trzcina.yml", Config::YAML);
		$tnt = new Config($this->getDataFolder() . "tnt.yml", Config::YAML);
		$wegiel = new Config($this->getDataFolder() . "wegiel.yml", Config::YAML);
		$emerald = new Config($this->getDataFolder() . "emerald.yml", Config::YAML);
		$redstone = new Config($this->getDataFolder() . "redstone.yml", Config::YAML);
		$obsidian = new Config($this->getDataFolder() . "obsidian.yml", Config::YAML);
		$lapis = new Config($this->getDataFolder() . "lapis.yml", Config::YAML);
		$name = $sender->getName();
		$diament->set($name, 1);
		$diament->save();
		$zloto->set($name, 1);
		$zloto->save();
		$zelazo->set($name, 1);
		$zelazo->save();
		$trzcina->set($name, 1);
		$trzcina->save();
		$tnt->set($name, 1);
		$tnt->save();
		$wegiel->set($name, 1);
		$wegiel->save();
		$emerald->set($name, 1);
		$emerald->save();
		$redstone->set($name, 1);
		$redstone->save();
		$obsidian->set($name, 1);
		$obsidian->save();
		$lapis->set($name, 1);
		$lapis->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §ewszstkich itemow§7 zostal wyłączony! §f•");
		}
		
		if($args[0] == "diament" && $args[1] == "on"){
		$cfg = new Config($this->getDataFolder() . "diament.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 0);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §bdiamentow§7 zostal włączony! §f•");
		}
		if($args[0] == "diament" && $args[1] == "off"){
		$cfg = new Config($this->getDataFolder() . "diament.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 1);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §bdiamentow§7 zostal wyłączony! §f•");
		}
		
		if($args[0] == "zloto" && $args[1] == "on"){
		$cfg = new Config($this->getDataFolder() . "zloto.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 0);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §6zlota§7 zostal włączony! §f•");
		}
		if($args[0] == "zlota" && $args[1] == "off"){
		$cfg = new Config($this->getDataFolder() . "zloto.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 1);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §6zlota§7 zostal wyłączony! §f•");
		}
		if($args[0] == "zelazo" && $args[1] == "on"){
		$cfg = new Config($this->getDataFolder() . "zelazo.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 0);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §fzelazo§7 zostal włączony! §f•");
		}
		if($args[0] == "zelazo" && $args[1] == "off"){
		$cfg = new Config($this->getDataFolder() . "zelazo.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 1);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §fzelaza§7 zostal wyłączony! §f•");
		}
		
		if($args[0] == "trzcina" && $args[1] == "on"){
		$cfg = new Config($this->getDataFolder() . "trzcina.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 0);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §atrzcina§7 zostal włączony! §f•");
		}
		if($args[0] == "trzcina" && $args[1] == "off"){
		$cfg = new Config($this->getDataFolder() . "trzcina.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 1);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §2trzcina§7 zostal wyłączony! §f•");
		}
		
		if($args[0] == "tnt" && $args[1] == "on"){
		$cfg = new Config($this->getDataFolder() . "tnta.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 0);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §ctnt§7 zostal włączony! §f•");
		}
		if($args[0] == "tnt" && $args[1] == "off"){
		$cfg = new Config($this->getDataFolder() . "tnt.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 1);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §ctnt§7 zostal wyłączony! §f•");
		}
		
		if($args[0] == "wegiel" && $args[1] == "on"){
		$cfg = new Config($this->getDataFolder() . "wegiel.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 0);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §7wegiel§7 zostal włączony! §f•");
		}
		if($args[0] == "wegiel" && $args[1] == "off"){
		$cfg = new Config($this->getDataFolder() . "wegiel.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 1);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §7wegiel§7 zostal wyłączony! §f•");
		}
		if($args[0] == "emerald" && $args[1] == "on"){
		$cfg = new Config($this->getDataFolder() . "emerald.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 0);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §2emerald§7 zostal włączony! §f•");
		}
		if($args[0] == "emerald" && $args[1] == "off"){
		$cfg = new Config($this->getDataFolder() . "emerald.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 1);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §2emerald§7 zostal wyłączony! §f•");
		}
		if($args[0] == "redstone" && $args[1] == "on"){
		$cfg = new Config($this->getDataFolder() . "redstone.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 0);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §4redstone§7 zostal włączony! §f•");
		}
		if($args[0] == "redstone" && $args[1] == "off"){
		$cfg = new Config($this->getDataFolder() . "redstone.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 1);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §4redstone§7 zostal wyłączony! §f•");
		}
		if($args[0] == "obsidian" && $args[1] == "on"){
		$cfg = new Config($this->getDataFolder() . "obsidian.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 0);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §5obsidianu§7 zostal włączony! §f•");
		}
		if($args[0] == "obsidian" && $args[1] == "off"){
		$cfg = new Config($this->getDataFolder() . "obsidian.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 1);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §5obsidianu§7 zostal wyłączony! §f•");
		}
		if($args[0] == "lapis" && $args[1] == "on"){
		$cfg = new Config($this->getDataFolder() . "lapis.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 0);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §blapisu§7 zostal włączony! §f•");
		}
		if($args[0] == "lapis" && $args[1] == "off"){
		$cfg = new Config($this->getDataFolder() . "lapis.yml", Config::YAML);
		$name = $sender->getName();
		$cfg->set($name, 1);
		$cfg->save();
		$sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Drop §blapisu§7 zostal wyłączony! §f•");
		}
		}
		}
}
}