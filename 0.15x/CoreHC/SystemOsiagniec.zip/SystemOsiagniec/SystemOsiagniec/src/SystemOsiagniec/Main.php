<?php

namespace SystemOsiagniec;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\IPlayer;
use pocketmine\command\{Command, CommandSender};
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\level\particle\Particle;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use pocketmine\utils\Utils;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pockemine\inventory\Inventory;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDespawnEvent;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\entity\Snowball;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\particle\BubbleParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\BatSound;
use pocketmine\level\sound;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\block\Air;
use pocketmine\block\Obsidian;
use pocketmine\block\Sand;
use pocketmine\block\Stone;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\entity\EntityShootBowEvent;
use pocketmine\entity\Egg;
use pocketmine\event\server\DataPacketReceiveEvent;

class Main extends PluginBase implements Listener{
				
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$server = $this->getServer();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§1E§2n§2a§4b§5l§6e§7d§2!");
		}
	
	public function onBreak(BlockBreakEvent $event){
		$block = $event->getBlock();
		$player = $event->getPlayer();
		$name = $player->getName();
		$obsidian = new Config($this->getDataFolder() . "obsidian.yml", Config::YAML);
		$obsidians = $obsidian->get($name);
		if($block->getId() == 49){
		if($obsidians < 199){
		$obsidian->set($name, $obsidians+1);
		$obsidian->save();
		}
		if($obsidians == 199){
	    $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Gracz §2" . $name . " §7wykonal zadanie: Wykop 200 obsydianu! §f•");
		$obsidian->set($name, 200);
		$obsidian->save();
		if($player->getInventory()->canAddItem(Item::get(322, 0, 2))){
		$player->getInventory()->addItem(Item::get(322, 0, 2));
		}
		else{
		$item = Item::get(322, 0, 2);
		$player->getLevel()->dropItem(new Vector3($player->getX(), $player->getY(), $player->getZ()), $item);
		}
		}
		}
	}
	
	public function onDeath(PlayerDeathEvent $event){
	$killer = $event->getEntity()->getLastDamageCause()->getDamager()->getName();
	$killer2 = $event->getEntity()->getLastDamageCause()->getDamager();
	$kill = new Config($this->getDataFolder() . "zabojstwa.yml", Config::YAML);
	$kills = $kill->get($killer);
	if($kills < 49){
	$kill->set($killer, $kills+1);
	$kill->save();
	}
	if($kills == 49){
	$kill->set($killer, 50);
	$kill->save();
	$this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Gracz §2" . $killer . " §7wykonal zadanie: Zabij 50 graczy! §f•");
	if($killer2->getInventory()->canAddItem(Item::get(466, 0, 1))){
	$killer2->getInventory()->addItem(Item::get(466, 0, 1));
	}
	else{
	$item = Item::get(466, 0, 1);
	$killer2->getLevel()->dropItem(new Vector3($killer2->getX(), $killer2->getY(), $killer2->getZ()), $item);	
	}
	}
	}
	public function onEat(PlayerItemConsumeEvent $event){
	$name = $event->getPlayer()->getName();
	$player = $event->getPlayer();
	$refy = new Config($this->getDataFolder() . "refy.yml", Config::YAML);
	$refys = $refy->get($name);
	if($event->getItem()->getId() == 322){
	if($refys < 63){
	$refy->set($name, $refys+1);
	$refy->save();
	}
	if($refys == 63){
	$refy->set($name, 64);
	$refy->save();
	$this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Gracz §2" . $name . " §7wykonal zadanie: Zjedz 64 refy! §f•");
	if($player->getInventory()->canAddItem(Item::get(466, 0, 3))){
	$player->getInventory()->addItem(Item::get(466, 0, 3));
	}
	else{
	$item = Item::get(466, 0, 3);
	$player->getLevel()->dropItem(new Vector3($player->getX(), $player->getY(), $player->getZ()), $item);	
	}
	}	
	}
	}
	
	  public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
	  $name = $sender->getName();
	  $obsidian = new Config($this->getDataFolder() . "obsidian.yml", Config::YAML);
	  $obsidians = $obsidian->get($name);
	  $kill = new Config($this->getDataFolder() . "zabojstwa.yml", Config::YAML);
	  $kills = $kill->get($name);
	  $refy = new Config($this->getDataFolder() . "refy.yml", Config::YAML);
	  $refys = $refy->get($name);
	  $guilds = new Config($this->getDataFolder(). "guilds.yml", Config::YAML);
	  if($cmd->getName() == "zadania"){
	  $sender->sendMessage("§8[ §7=========== §8[ §2§lZADANIA§r§8 ] §7===========§8 ]");
	  $sender->sendMessage("§2* §7Wykop §2200 §7obsydianu:§2 " . $obsidians . "§7/§2200");
	  $sender->sendMessage("§2* §7Zabij §250 §7graczy:§2 " . $kills . "§7/§250");
	  $sender->sendMessage("§2* §7Zjedz §264 §7refilow:§2 " . $refys . "§7/§264");
	  if($guilds->get($name) == 1){
	  $sender->sendMessage("§2* §7Zostan czlonkiem gildii: §2TAK ");
	  }
	  else{
	  $sender->sendMessage("§2* §7Zostan czlonkiem gildii: §2NIE ");  
	  }
	  $sender->sendMessage("§8[ §7=========== §8[ §2§lZADANIA§r§8 ] §7===========§8 ]");
	  }
	  }
	  
	public function onJoin(PlayerJoinEvent $event){
	$obsidian = new Config($this->getDataFolder() . "obsidian.yml", Config::YAML);	
	$kill = new Config($this->getDataFolder() . "zabojstwa.yml", Config::YAML);
	$refy = new Config($this->getDataFolder() . "refy.yml", Config::YAML);
	if(!$obsidian->exists($event->getPlayer()->getName())){
	$obsidian->set($event->getPlayer()->getName(), 0);
	$obsidian->save();
	}
	if(!$kill->exists($event->getPlayer()->getName())){
	$kill->set($event->getPlayer()->getName(), 0);
	$kill->save();
	}
	if(!$refy->exists($event->getPlayer()->getName())){
	$refy->set($event->getPlayer()->getName(), 0);
	$refy->save();
	}
	}
	
	  public function accept(String $playername){
	  $this->eloyaml = new Config($this->getDataFolder(). "guilds.yml", Config::YAML);
	  if(!($this->eloyaml->exists($playername))){
      $this->eloyaml->set($playername, 1);
	  $this->eloyaml->save();
	  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Gracz §2" . $playername . " §7wykonal zadanie: Zostan czlonkiem gildii! §f•");
   }
  }
}