<?php

namespace SystemChatu;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\IPlayer;
use pocketmine\command\{Command, CommandSender};
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\level\particle\Particle;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use pocketmine\utils\Utils;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pockemine\inventory\Inventory;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDespawnEvent;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\entity\Snowball;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\particle\BubbleParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\BatSound;
use pocketmine\level\sound;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\block\Air;
use pocketmine\block\Obsidian;
use pocketmine\block\Sand;
use pocketmine\block\Stone;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\entity\EntityShootBowEvent;
use pocketmine\entity\Egg;
use pocketmine\event\server\DataPacketReceiveEvent;

class Main extends PluginBase implements Listener{
			
	
	public function onEnable(){
		@mkdir($this->getDataFolder());
		$server = $this->getServer();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§1E§2n§2a§4b§5l§6e§7d§2!");
		}
		
  public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
	  if($cmd->getName() == "chat"){
	  if($sender->hasPermission("chat.dostep")){
	  if(count($args) == 0){
	  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzycie: /chat on/off/vip/svip/premium/cc §f•");
	  }
	  if(count($args) == 1){
	  if($args[0] == "on"){
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Chat został włączony przez §2" . $sender->getName() . " §f•");
		  $cfg = new Config($this->getDataFolder() . "chat.yml", Config::YAML);
		  $cfg->set("chat", 0);
		  $cfg->save();
	  }
		  if($args[0] == "off"){
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Chat został wyłączony przez§2 " . $sender->getName() . " §f•");
		  $cfg = new Config($this->getDataFolder() . "chat.yml", Config::YAML);
		  $cfg->set("chat", 1);
		  $cfg->save();  
	  }
		  if($args[0] == "premium"){
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Chat został włączony tylko dla rang platnych przez§2 " . $sender->getName() . " §f•");
		  $cfg = new Config($this->getDataFolder() . "chat.yml", Config::YAML);
		  $cfg->set("chat", 2);
		  $cfg->save();  
	  }
	  	  if($args[0] == "vip"){
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Chat został włączony tylko dla rangi VIP przez§2 " . $sender->getName() . " §f•");
		  $cfg = new Config($this->getDataFolder() . "chat.yml", Config::YAML);
		  $cfg->set("chat", 3);
		  $cfg->save();  
	  }
	  	  if($args[0] == "svip"){
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Chat został włączony tylko dla rangi SVIP przez§2 " . $sender->getName() . " §f•");
		  $cfg = new Config($this->getDataFolder() . "chat.yml", Config::YAML);
		  $cfg->set("chat", 4);
		  $cfg->save();  
	  }
		  if($args[0] == "cc"){
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f");
		  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Chat został wyczyszczony przez§2 " . $sender->getName() . "§7! §f•");
		  }
	  }
	  }
	  }
	  }
		public function onChat(PlayerChatEvent $event){
	    $cfg = new Config($this->getDataFolder() . "chat.yml", Config::YAML);
		if($cfg->get("chat") == 1 && !$event->getPlayer()->hasPermission("admin.dostep.chat")){
		$event->setCancelled();
		$event->getPlayer()->sendMessage("§f• §8> §8[§2xHardCore§8] §7Chat główny jest wyłączony! §f•");
		}
		if($cfg->get("chat") == 2 && !$event->getPlayer()->hasPermission("premium.dostep.chat")){
		$event->setCancelled();
		$event->getPlayer()->sendMessage("§f• §8> §8[§2xHardCore§8] §7Chat główny jest włączony dla rang platnych! §f•");
		}
		if($cfg->get("chat") == 3 && !$event->getPlayer()->hasPermission("vip.dostep.chat")){
		$event->setCancelled();
		$event->getPlayer()->sendMessage("§f• §8> §8[§2xHardCore§8] §7Chat główny jest włączony dla VIPow! §f•");
		}
		if($cfg->get("chat") == 4 && !$event->getPlayer()->hasPermission("svip.dostep.chat")){
		$event->setCancelled();
		$event->getPlayer()->sendMessage("§f• §8> §8[§2xHardCore§8] §7Chat główny jest włączony dla SVIPow! §f•");
		}
		}
}