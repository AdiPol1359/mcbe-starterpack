<?php

namespace xSmoothy;

use pocketmine\plugin\PluginBase as PluginBase;
use pocketmine\event\Listener as Listener;
use pocketmine\utils\TextFormat;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\utils\Config;
use pocketmine\block\Block;
use pocketmine\block\Air;
use pocketmine\block\Stone;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\scheduler\PluginTask;

class Main extends PluginBase implements Listener{

 
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);		
		$this->getServer()->getLogger()->info(TextFormat::GREEN . "Wszelkie błędy zgłaszaj do xSmoothy'iego");
		$this->db = new \SQLite3($this->getDataFolder() . "Stoniarki.db");
		$this->db->exec("CREATE TABLE IF NOT EXISTS stoniarki(x INT, y INT, z INT, world VARCHAR);");
	}
	 public function onPlace(BlockPlaceEvent $event){
		 $cfg = new Config($this->getDataFolder() . "stoniarki.yml", Config::YAML);
		 $player = $event->getPlayer();
		 $block = $event->getBlock();
		 $x = $block->getX();
		 $y = $block->getY();
		 $z = $block->getZ();
		 if(!$event->isCancelled()){
		 if($block->getId() == 121){
		 $stmt = $this->db->prepare("INSERT OR REPLACE INTO stoniarki (x, y, z, world) VALUES (:x, :y, :z, :world);");
		 $stmt->bindValue(":x", $x);
		 $stmt->bindValue(":y", $y);
		 $stmt->bindValue(":z", $z);
		 $stmt->bindValue(":world", $player->getLevel()->getName());
		 $result = $stmt->execute();
		 $event->setCancelled();
		 $player->getInventory()->removeItem(Item::get(121, 0, 1));
		 $player->getLevel()->setBlock(new Vector3($x, $y, $z), Block::get(1, 0));
		 $player->sendTip("§f• §8> §8[§2xHardCore§8] §7Postawiles stoniarke! §f•");
		 $player->sendMessage("§f• §8> §8[§axHardCore§8] §7Aby zniszczyc stoniarke wykop stone'a zlotym kilofem! §f•");
		 }
	 }
	 }
	 public function onBreak(BlockBreakEvent $event){
	  $blok = $event->getBlock();
	  $gracz = $event->getPlayer();
	  $y = $blok->getFloorY();
	  $x = $blok->getFloorX();
  	  $z = $blok->getFloorZ();
	  $result = $this->db->query("SELECT * FROM stoniarki WHERE x='$x' AND y='$y' AND z='$z';");
	  $array = $result->fetchArray(SQLITE3_ASSOC);
  	  if($blok->getId() == 1){
		  if(!empty($array)){
		  $gracz->getInventory()->addItem(Item::get(4, 0, 1));
		  $task = new Task($this, $event->getBlock()->getFloorX(), $event->getBlock()->getFloorY(), $event->getBlock()->getFloorZ());
          $this->getServer()->getScheduler()->scheduleDelayedTask($task, 35);
					$drops = array();
					$drops[] = Item::get(0, 0, 0);
					$event->setDrops($drops);
		  }
}
}
	 public function onBreakGolden(BlockBreakEvent $event){
	  $blok = $event->getBlock();
	  $gracz = $event->getPlayer();
	  $y = $blok->getFloorY();
	  $x = $blok->getFloorX();
  	  $z = $blok->getFloorZ();
	  $result = $this->db->query("SELECT * FROM stoniarki WHERE x='$x' AND y='$y' AND z='$z';");
	  $array = $result->fetchArray(SQLITE3_ASSOC);
  	  if($blok->getId() == 1){
		  if(!empty($array)){
			  if($gracz->getInventory()->getItemInHand()->getId() == 285){
				  $this->db->query("DELETE FROM stoniarki WHERE x='$x' AND y='$y' AND z='$z';");
				  $task = new Task2($this, $event->getBlock()->getFloorX(), $event->getBlock()->getFloorY(), $event->getBlock()->getFloorZ());
					$this->getServer()->getScheduler()->scheduleDelayedTask($task, 36);
					$drops = array();
					$drops[] = Item::get(4, 0, 1);
					$event->setDrops($drops);
		  }
}
}
	 }
}