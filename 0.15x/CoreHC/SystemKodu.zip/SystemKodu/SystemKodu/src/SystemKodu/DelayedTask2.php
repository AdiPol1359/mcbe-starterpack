<?php

namespace SystemKodu;

use pocketmine\scheduler\PluginTask;
use pocketmine\plugin\Plugin;
use pocketmine\command\ConsoleCommandSender;

class DelayedTask2 extends PluginTask {
    
    private $plugin;
    
    public function __construct(Plugin $plugin) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
    }
    
    public function onRun($currentTick) {
        $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "kod zakoncz");
    }
}

