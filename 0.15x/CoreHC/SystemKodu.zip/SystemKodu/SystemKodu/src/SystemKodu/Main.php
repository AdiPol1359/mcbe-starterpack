<?php

namespace SystemKodu;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\IPlayer;
use pocketmine\command\{Command, CommandSender};
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\level\particle\Particle;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use pocketmine\utils\Utils;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\item\Item;
use pockemine\inventory\Inventory;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\entity\Effect;
use pocketmine\event\entity\EntityDespawnEvent;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\entity\Snowball;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\particle\BubbleParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\sound\BatSound;
use pocketmine\level\sound;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\block\Air;
use pocketmine\block\Obsidian;
use pocketmine\block\Sand;
use pocketmine\block\Stone;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\entity\EntityShootBowEvent;
use pocketmine\entity\Egg;
use pocketmine\event\server\DataPacketReceiveEvent;

class Main extends PluginBase implements Listener{
			
	public function getRandomWord($len = 10) {
    $word = array_merge(range('a', 'z'), range('A', 'Z'));
    shuffle($word);
    return substr(implode($word), 0, $len);
}

	public function onEnable(){
		@mkdir($this->getDataFolder());
		$server = $this->getServer();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§1E§2n§2a§4b§5l§6e§7d§2!");
		$task = new DelayedTask($this);
        $this->getServer()->getScheduler()->scheduleRepeatingTask($task, 24000);
		$task = new DelayedTask2($this);
        $this->getServer()->getScheduler()->scheduleRepeatingTask($task, 30000);
		}
		
  public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
  if($cmd->getName() == "kod"){
  if(count($args) == 0){
  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Uzyj: /kod <start/zakoncz> §f•");	
  }
  if(count($args) == 1){
  if($args[0] == "start"){
  if($sender->hasPermission("kod.start")){
  $cfg = new Config($this->getDataFolder() . "kod.yml", Config::YAML);
  $name = "Kod";
  if($cfg->get($name) == "0"){
  $rand = $this->getRandomWord();
  $cfg->set($name, $rand);
  $cfg->save();
  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Kto pierwszy przepisze§2 " . $rand . " §7do chatu otrzyma nagrode! §f•");
  }
  else{
  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Gra juz wystartowala! §f•");
  }
  }
  else{
  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Brak dostepu do komendy! §7(§akod.start§7) §f•");
  }
  }
  if($args[0] == "zakoncz"){
  if($sender->hasPermission("kod.zakoncz")){
  $cfg = new Config($this->getDataFolder() . "kod.yml", Config::YAML);
  $name = "Kod";
  if(!$cfg->get($name) == "0"){
  $cfg->set($name, "0");
  $cfg->save();
  $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Nikt nie wpisal kodu, koniec gry! §f•");
  }
  else{
  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Gra nie wystartowala! §f•");
  }
  }
  else{
  $sender->sendMessage("§f• §8> §8[§2xHardCore§8] §7Brak dostepu do komendy! §7(§akod.zakoncz§7) §f•");
  }
  }
  }
  }
	  }
	  public function onChat(PlayerChatEvent $event){
		 $cfg = new Config($this->getDataFolder() . "kod.yml", Config::YAML);
		 $player = $event->getPlayer();
		 $message = $event->getMessage();
		 $kod = $cfg->get("Kod");
		 if($message == $kod && !$cfg->get("Kod") == "0"){
	     $event->setCancelled();
		 $cfg->set("Kod", "0");
		 $cfg->save();
		 $player->getInventory()->addItem(Item::get(322, 0, 3));
		 $this->getServer()->broadcastMessage("§f• §8> §8[§2xHardCore§8] §7Gracz§2 " . $player->getName() . " §7wpisal kod jako pierwszy i otrzymuje §23§7 refile! §f•");
		 }
	  }
	  public function onJoin(PlayerJoinEvent $event){
		 $cfg = new Config($this->getDataFolder() . "kod.yml", Config::YAML);
		 $player = $event->getPlayer();
		 $kod = $cfg->get("Kod");
		 if(!$kod == "0"){
		 $player->sendMessage("§f• §8> §8[§2xHardCore§8] §7Kto pierwszy przepisze§2 " . $kod . " §7do chatu otrzyma nagrode! §f•");
		 }	  
	  }
}