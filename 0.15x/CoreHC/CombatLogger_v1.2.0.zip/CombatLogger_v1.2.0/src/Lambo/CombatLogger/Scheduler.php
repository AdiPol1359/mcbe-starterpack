<?php
namespace Lambo\CombatLogger;

use pocketmine\Player;
use pocketmine\scheduler\PluginTask;

class Scheduler extends PluginTask{

    public function __construct($plugin){
        $this->plugin = $plugin;
        parent::__construct($plugin);
    }

    public function onRun($currentTick){
        foreach($this->plugin->players as $player=>$time){
                $p = $this->plugin->getServer()->getPlayer($player);
                if($p instanceof Player){
				    if((time() - $time) > $this->plugin->interval){
                    $p->sendMessage("§f• §8> §8[§2xHardCore§8]§7 Jestes juz bezpieczny, zakonczyles walke! §f•§r");
					$p->sendTip("§7Zakonczyles walke!");
                    unset($this->plugin->players[$player]);
					}
					if((time() - $time) == 1){
			        $p->sendTip("§a|§c||||||||||||||");
					}
					if((time() - $time) == 2){
			        $p->sendTip("§a||§c|||||||||||||");
					}
					if((time() - $time) == 3){
			        $p->sendTip("§a|||§c||||||||||||");
					}
					if((time() - $time) == 4){
			        $p->sendTip("§a||||§c|||||||||||");
					}
					if((time() - $time) == 5){
			        $p->sendTip("§a|||||§c||||||||||");
					}
					if((time() - $time) == 6){
			        $p->sendTip("§a||||||§c|||||||||");
					}
					if((time() - $time) == 7){
			        $p->sendTip("§a|||||||§c||||||||");
					}
					if((time() - $time) == 8){
			        $p->sendTip("§a||||||||§c|||||||");
					}
					if((time() - $time) == 9){
			        $p->sendTip("§a|||||||||§c||||||");
					}
					if((time() - $time) == 10){
			        $p->sendTip("§a||||||||||§c|||||");
					}
					if((time() - $time) == 11){
			        $p->sendTip("§a|||||||||||§c||||");
					}
					if((time() - $time) == 12){
			        $p->sendTip("§a||||||||||||§c|||");
					}
					if((time() - $time) == 13){
			        $p->sendTip("§a|||||||||||||§c||");
					}
					if((time() - $time) == 14){
			        $p->sendTip("§a||||||||||||||§c|");
					}
					if((time() - $time) == 15){
			        $p->sendTip("§a|||||||||||||||");
					}
                }else unset($this->plugin->players[$player]);
            }
			}
        }