<?php

namespace Lambo\CombatLogger;

use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\PluginTask;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\entity\Entity;

use pocketmine\event\Event;
use pocketmine\event\EventPriority;
use pocketmine\event\Listener;
use pocketmine\event\TranslationContainer;
use pocketmine\math\Vector3;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerMoveEvent;

class Main extends PluginBase implements Listener{

    public $players = array();
    public $interval = 15;
    public $blockedcommands = array();
		
    public function onEnable(){
        $this->saveDefaultConfig();
        $this->interval = $this->getConfig()->get("interval");
        $cmds = $this->getConfig()->get("blocked-commands");
        foreach($cmds as $cmd){
            $this->blockedcommands[$cmd]=1;
        }
        $this->getServer()->getLogger()->info("CombatLogger enabled");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new Scheduler($this, $this->interval), 20);
    }

    public function onDisable(){
        $this->getServer()->getLogger()->info("CombatLogger disabled");
    }

    /**
     * @param EnityDamageEvent $event
     *
     * @priority MONITOR
     * @ignoreCancelled true
     */
    public function EntityDamageEvent(EntityDamageEvent $event){
        if($event instanceof EntityDamageByEntityEvent){
            if($event->getDamager() instanceof Player and $event->getEntity() instanceof Player){
                foreach(array($event->getDamager(),$event->getEntity()) as $players){
                    $this->setTime($players);
                }
            }
        }
    }

    private function setTime(Player $player){
        $msg = "§f• §8> §8[§2xHardCore§8]§7 Jesteś podczas walki! §7Poczekaj§2 ".$this->interval." §7sekund. §f•§r";
        if(isset($this->players[$player->getName()])){
            if((time() - $this->players[$player->getName()]) > $this->interval){
                $player->sendMessage($msg);
            }
        }else{
            $player->sendMessage($msg);
        }
        $this->players[$player->getName()] = time();
    }

    /**
     * @param PlayerDeathEvent $event
     *
     * @priority MONITOR
     * @ignoreCancelled true
     */
    public function PlayerDeathEvent(PlayerDeathEvent $event){
        if(isset($this->players[$event->getEntity()->getName()])){
            unset($this->players[$event->getEntity()->getName()]);
            /*$cause = $event->getEntity()->getLastDamageCause();
            if($cause instanceof EntityDamageByEntityEvent){
                $e = $cause->getDamager();
                if($e instanceof Player){
                    $message = "death.attack.player";
                    $params[] = $e->getName();
                    $event->setDeathMessage(new TranslationContainer($message, $params));
                }
            }*/
        }
    }

    /**
     * @param PlayerQuitEvent $event
     *
     * @priority HIGH
     * @ignoreCancelled true
     */
    public function PlayerQuitEvent(PlayerQuitEvent $event){
        if(isset($this->players[$event->getPlayer()->getName()])){
            $player = $event->getPlayer();
            if((time() - $this->players[$player->getName()]) < $this->interval){
                $player->kill();
            }
        }
    }

    /**
     * @param PlayerCommandPreprocessEvent $event
     *
     * @priority HIGH
     * @ignoreCancelled true
     */
    public function PlayerCommandPreprocessEvent(PlayerCommandPreprocessEvent $event){
        if(isset($this->players[$event->getPlayer()->getName()])){
            $cmd = strtolower(explode(' ', $event->getMessage())[0]);
            if(isset($this->blockedcommands[$cmd])){
                $event->getPlayer()->sendMessage("§f• §8> §8[§2xHardCore§8]§7 Nie możesz użyć tej komendy podczas walki! §f•§r");
                $event->setCancelled();
            }
        }
    }
	public function onPlace(BlockPlaceEvent $event){
		if(isset($this->players[$event->getPlayer()->getName()])){
			if($event->getPlayer()->getFloorY() <= 40){
				$event->setCancelled();
				$event->getPlayer()->sendMessage("§f• §8> §8[§2xHardCore§8]§7 Nie możesz stawiac blokow ponizej Y: §240 §7podczas walki! §f•§r");
			}
		}
	}
	public function onMove(PlayerMoveEvent $event){
		if(isset($this->players[$event->getPlayer()->getName()])){
			#if($event->getPlayer()->getLevel()->getBlock(new Vector3($event->getPlayer()->getX(), $event->getPlayer()->getY(), $event->getPlayer()->getZ()))->getId() == 171 && $event->getPlayer()->getLevel()->getBlock(new Vector3($event->getPlayer()->getX(), $event->getPlayer()->getY(), $event->getPlayer()->getZ()))->getDamage() == 14 or $event->getPlayer()->getLevel()->getBlock(new Vector3($event->getPlayer()->getX(), $event->getPlayer()->getY()-1, $event->getPlayer()->getZ()))->getId() == 171 && $event->getPlayer()->getLevel()->getBlock(new Vector3($event->getPlayer()->getX(), $event->getPlayer()->getY()-1, $event->getPlayer()->getZ()))->getDamage() == 14 or $event->getPlayer()->getLevel()->getBlock(new Vector3($event->getPlayer()->getX(), $event->getPlayer()->getY()-2, $event->getPlayer()->getZ()))->getId() == 171 && $event->getPlayer()->getLevel()->getBlock(new Vector3($event->getPlayer()->getX(), $event->getPlayer()->getY()-2, $event->getPlayer()->getZ()))->getDamage() == 14 or $event->getPlayer()->getLevel()->getBlock(new Vector3($event->getPlayer()->getX(), $event->getPlayer()->getY()-3, $event->getPlayer()->getZ()))->getId() == 171 && $event->getPlayer()->getLevel()->getBlock(new Vector3($event->getPlayer()->getX(), $event->getPlayer()->getY()-3, $event->getPlayer()->getZ()))->getDamage() == 14){
			    $player = $event->getPlayer();
     		/*if($player->getDirection() == 1){
                 $player->knockBack($player, 0, 0, -1, 0.3);
			}
			if($player->getDirection() == 2){
				$player->knockBack($player, 0, 1, 0, 0.3);
			}
			if($player->getDirection() == 3){
				$player->knockBack($player, 0, 0, 1, 0.3);
			}
			if($player->getDirection() == 0){
				$player->knockBack($player, 0, -1, 0, 0.3);
			}*/
			if($player->getX() <= 154 && $player->getX() >= 94){
			if($event->getPlayer()->getZ() >= 178 && $event->getPlayer()->getZ() < 179){
			$player->knockBack($player, 100, 0, 2, 0.5);
			}
			}
			if($player->getX() >= 154 && $player->getX() < 155){
			if($event->getPlayer()->getZ() < 179 && $event->getPlayer()->getZ() > 120){
			$player->knockBack($player, 100, 2, 0, 0.5);
			}
			}
			if($player->getX() <= 154 && $player->getX() >= 94){
			if($event->getPlayer()->getZ() >= 119 && $event->getPlayer()->getZ() < 120){
			$player->knockBack($player, 100, 0, -2, 0.5);
			}
			}
			if($player->getX() >= 94 && $player->getX() < 95){
			if($event->getPlayer()->getZ() < 179 && $event->getPlayer()->getZ() > 120){
			$player->knockBack($player, 100, -2, 0, 0.5);
			}
			}
		}
	}
	}