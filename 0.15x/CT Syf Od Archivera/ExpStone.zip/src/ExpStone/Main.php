<?php

namespace ExpStone;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;

use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;

use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use pocketmine\event\block\BlockBreakEvent;
use pockemine\inventory\Inventory;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("ExpStone Loaded zaladowane");
		}
	
  public function onBreak(BlockBreakEvent $ev){

  $player = $ev->getPlayer();

  if($ev->getBlock()->getId() == 1){

  $player->addExperience(1);

  }

}
		}
