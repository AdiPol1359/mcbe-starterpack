<?php

namespace swag;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info("Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('swag'))) {
				if(empty($args)) {
					$sender->sendMessage("§8[§7========== §8[§cSWAG§8]§7 ==========§8]");
					$sender->sendMessage("§7Ranga §cSWAG §7posiada:"); 
					$sender->sendMessage("§7§cDarmowa §7teleportacje na spawn,");
					$sender->sendMessage("§7oraz wszystkie przywileje rangi§c VIP");
					$sender->sendMessage("§7Aby wylosowac wpisz:§c /swag losuj");
					$sender->sendMessage("§8[§7========== §8[§cSWAG§8]§7 ==========§8]");
					return true;
				}
				if($args[0] == "losuj") {
				if($sender instanceof Player) {
					  if($sender->getInventory()->contains(Item::get(264, 0, 48))) {
						  $name = $sender->getName();
			 switch(mt_rand(1,45)){
					 case 1:
					 $this->getServer()->broadcastMessage("§f• §7Gracz §c " . $name . " §7wylosował range §1S§2W§3A§4G§7, gratulacje! §f•");
					 $cmd = "setgroup $name swag";
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 $this->getServer()->dispatchCommand(new ConsoleCommandSender,$cmd);
					 $cmd2 = "sudo $name c:Łatwo! <3";
					 $this->getServer()->dispatchCommand(new ConsoleCommandSender,$cmd2);
					 break;
					 case 2:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 3:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 4:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 5:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 6:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 7:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 8:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 9:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 10:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 11:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 12:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 13:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 14:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 15:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					$sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 16:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 17:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 18:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 19:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 20:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 21:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 22:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 23:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 24:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 25:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 26:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 27:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 28:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 29:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 30:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 31:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 32:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 33:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 34:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 35:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 36:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 37:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 38:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 39:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 40:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));

					 break;
					 					 case 41:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 42:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 43:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 44:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
				 	 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
					 					 case 45:
					 $sender->sendMessage("§f• §8[§cSWAG§8] §7Spróbuj ponownie później! §f•");
					 $sender->getInventory()->removeItem(Item::get(264, 0, 48));
					 break;
			 }
		} 
		else {
			$sender->sendMessage("§f• §8[§cSWAG§8] §7Potrzebujesz 48 diamentów aby zalosować! §f•");
	}
			} 
			else {
						$this->getServer()->getLogger()->info("Uzyj tego w grze zjebie...");
 		  }
}
	
	}
						}
					}
