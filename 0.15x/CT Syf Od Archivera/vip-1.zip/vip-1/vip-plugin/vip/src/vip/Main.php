<?php

namespace vip;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("vip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "vip"){
      $sender->sendMessage("§l§8 [§7-----------§a[VIP]§7-----------§8]");
      $sender->sendMessage(" §a* §7Jak kupic range §aVIP? ");
      $sender->sendMessage(" §a* §7Wpisz komende /is tam masz link do sklepu");
      $sender->sendMessage(" §a* §7Co posiada ranga §aVIP§7?");
	  $sender->sendMessage(" §a* §7- §a/Kit vip §7- §7Itemy startowe vipa. ");
	  $sender->sendMessage(" §a* §7- §a/Back §7- Teleportacja w ostatnie miejsce");
      $sender->sendMessage(" §a* §7Kit §avip §7zawiera: ");
	  $sender->sendMessage(" §a* §7- §aZelazna Zbroje oraz narzedzia");
	  $sender->sendMessage(" §a* §7- §aLuk oraz 16 strzal");
	  $sender->sendMessage(" §a* §7- §a3 Zlote Jablka oraz 10 Chleba");
	  $sender->sendMessage(" §a* §7- §aZelazny Miecz Ostrosc 2");
      $sender->sendMessage("§l§8[§7-----------§a[VIP]§7-----------§8]");
       return true;
   }

}
}
