<?php

namespace main_folder;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;
use pocketmine\utils\MainLogger;
use pocketmine\block\Air;
use pocketmine\entity\Effect;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\level\sound\PopSound;
use pocketmine\level\particle\LavaParticle;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;

class OreInstantDrop extends PluginBase implements Listener {

  public function onEnable() {
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
  }
  
  public function onBreak(BlockBreakEvent $event) {
    if($event->getBlock()->getId() == 14) {
      $drops = array(Item::get(4, 0, 1));
      $event->setDrops($drops);
    }
    if($event->getBlock()->getId() == 15) {
      $drops = array(Item::get(4, 0, 1));
      $event->setDrops($drops);
	      }
    if($event->getBlock()->getId() == 56) {
      $drops = array(Item::get(4, 0, 1));
      $event->setDrops($drops);
	      }
    if($event->getBlock()->getId() == 129) {
      $drops = array(Item::get(4, 0, 1));
      $event->setDrops($drops);
	      }
    if($event->getBlock()->getId() == 21) {
      $drops = array(Item::get(4, 0, 1));
      $event->setDrops($drops);
	      }
    if($event->getBlock()->getId() == 73) {
      $drops = array(Item::get(4, 0, 1));
      $event->setDrops($drops);
	}
	if($event->getBlock()->getId() == 78) {
      $drops = array(Item::get(0, 0, 1));
      $event->setDrops($drops);
    }
	if($event->getBlock()->getId() == 19) {
      $drops = array(Item::get(49, 0, 1));
      $event->setDrops($drops);
    }
  }
}