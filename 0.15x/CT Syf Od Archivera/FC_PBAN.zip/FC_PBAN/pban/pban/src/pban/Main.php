<?php

namespace pban;

use pocketmine\event\Listener;

use pocketmine\Server;

use pocketmine\Player;

use pocketmine\utils\TextFormat as color;

use pocketmine\command\Command;

use pocketmine\command\CommandSender;

use pocketmine\plugin\PluginBase;

class Main extends PluginBase implements Listener{

    public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		
		$this->getLogger()->info("§cPBAN v1.0 §aDZIALA!");
	}
    
    public function onDisable(){
		$this->getLogger()->info("§cPBAN 1.0 §cNIE DZIALA!");
    }

public function onCommand(CommandSender $sender, Command $command, $label, array $args){
        switch($command->getName()){
            case "pban":
                if(isset($args[0])){
                        $player = $this->getServer()->getPlayer($args[0]);
                        if($this->getServer()->getPlayer($args[0])){
            $reason = implode(" ", $args);
            $worte = explode(" ", $reason);
			 unset($worte[0]);
			  $reason = implode(" ", $worte);
 $sender->getServer()->getCIDBans()->addBan($player->getClientId(), $reason, null, $sender->getName());                     
                            $player->kick("\n§8======\n§4 Zostales zbanowany na serwerze, §4\nPowod:[" .$reason ."]\n§4FASTCORE.PL « Wejdz jezeli chcesz\nsie odwolac od bana.\n§8======");
          $this->getServer()->broadcastMessage("§c» §8[§cBAN§8] §c" .$args[0] ." §8Zostal zbanowany na zawsze przez:§c " . $sender->getName() . "§8! §8Powod: §c[§c" .$reason ."§c] §c«");
             } else {
      if(!$player instanceof Player){
           $sender->sendMessage("§cGracz jest offline!");
                     return true;
                         }
      if($sender instanceof Player) {
               if($sender->hasPermission("pban.command")) {
                   } else {
           $sender->sendMessage("§cNie masz permisji!");
           return true;
                 }
              }
          }
       }
     }
  }
  }
 
     
   
