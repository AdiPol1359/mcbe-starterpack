Source Code For Guilds Plugin.
