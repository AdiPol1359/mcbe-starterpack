<?php

namespace uvipe;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("svip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "rangi"){
      $sender->sendMessage("§l§8[§7-----------§8[§6RANGI§8]§7-----------§8]");
      $sender->sendMessage("§6*§7 - Komendy na zakup rang (sms)");
      $sender->sendMessage("§6*§7 - Zakup rangi vip: §b/vip");
      $sender->sendMessage("§6*§7 - Zakup rangi mvip: §b/mvip");
	  $sender->sendMessage("§6*§7 - Zakup rangi gvip: §b/gvip");
	  $sender->sendMessage("§6*§7 - Chcesz YouTubera wpisz: §b/yt");
      $sender->sendMessage("§8§l[§7-----------§8[§6RANGI§8]§7-----------§8]");
       return true;
   }

}
}
