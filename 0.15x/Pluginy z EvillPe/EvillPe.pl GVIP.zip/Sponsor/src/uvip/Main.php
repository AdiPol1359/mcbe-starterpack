<?php

namespace uvip;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("vip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "gvip"){
      $sender->sendMessage("§l§8[§7-----------§a[GVIP]§7-----------§8]");
      $sender->sendMessage("§a* §7- Co posiada ranga §aGVIP§7?");
      $sender->sendMessage("§a* §7 - Kit gvip, a w nim:");
      $sender->sendMessage("§a* §7- §aDiamentowy helm oraz napiersnik");
      $sender->sendMessage("§a* §7- §aDiementowe spodnie oraz helm ");
      $sender->sendMessage("§a* §7- §aDiamentowe Narzedzia (Miecz, kilof)");
      $sender->sendMessage("§a* §7- §a3 Stoniarki oraz 64 Diamenty");
      $sender->sendMessage("§a* §7- Dodatkowe permisje takie jak:");
      $sender->sendMessage("§a* §7- §aTeleportacja w ostatnie miejsce lub miejsce smierci: /back");
      $sender->sendMessage("§a* §7- §aPisanie bez ograniczenia czasowego na chacie");
      $sender->sendMessage("§a* §7- §aNaprawa konkretnego lub wszystkich przedmiotow: /repair");
	  $sender->sendMessage("§a* §7- Jak kupic range §aGVIP§7?");
	  $sender->sendMessage("§a* §7- §aWyslij sms'a o tresci §cAP.HOSTMC");
	  $sender->sendMessage("§a* §7- §aPod numer §c91058§a koszt to §c12.30§a + §cVAT!");
	  $sender->sendMessage("§a* §7- §aMozna takze kupic doladowanie do §cOrange §aza §c10zl");
	  $sender->sendMessage("§a* §7- §aKod zwrotny podaj tylko do §cvApple69");             
      $sender->sendMessage("§l§8[§7----------§a[GVIP]§7-----------§8]");
       return true;
   }

}
}
