<?php

namespace regulamin;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("RegulaminElitePE loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "regulamin"){
      $sender->sendMessage("§l§8[§7-----------§a[Regulamin]§7-----------§8]");
      $sender->sendMessage("§a* §7- §cAdmin ma zawsze racje!");
      $sender->sendMessage("§a* §7- §cCheaty - Ban-CID");
      $sender->sendMessage("§a* §7- §cReklamowanie - Ban-IP");
      $sender->sendMessage("§a* §7- §cWyzwiska/Przeklenstwa - 3x = Ban");
      $sender->sendMessage("§a* §7- §cProba/ Oszustwo na administratorze - Ban-IP");
      $sender->sendMessage("§a* §7- §cWykorzystywanie bledow serwera - Ban-IP");
      $sender->sendMessage("§a* §7- §cMasz problem? Zglos sie do Administratora!");
      $sender->sendMessage("§l§8[§7-----------§a[Regulamin]§7-----------§8]");
       return true;
   }

}
}
