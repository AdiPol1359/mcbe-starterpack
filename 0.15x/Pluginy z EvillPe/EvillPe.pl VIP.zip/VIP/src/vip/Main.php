<?php

namespace vip;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("vip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "vip"){
      $sender->sendMessage("§l§8[§7----------§a[VIP]§7-----------§8]");
      $sender->sendMessage("§a* §7- Co posiada ranga §aVIP§7?");
      $sender->sendMessage("§a* §7- kit vip, a w nim:");
      $sender->sendMessage("§a* §7- §aZelazne spodnie oraz buty");
      $sender->sendMessage("§a* §7- §aZelazna klate oraz helm");
      $sender->sendMessage("§a* §7- §aZelazne narzedzia (Miecz, kilof)");
      $sender->sendMessage("§a* §7- §a3 Stoniarki i 16 Diamentow");
      $sender->sendMessage("§a* §7- Dodatkowe permisje takie jak:");
      $sender->sendMessage("§a* §7- §aTeleportacja w ostatnie lub miejsce smierci: /back");
      $sender->sendMessage("§a* §7- §aNaprawa konkretnego lub wszystkich przedmiotow: /repair");
	  $sender->sendMessage("§a* §7- Jak kupic range §aVIP§7?a");
	  $sender->sendMessage("§a* §7- §aWyslij sms'a o tresci §cAP.HOSTMC");
	  $sender->sendMessage("§a* §7- §aNa numer §c72068 §akoszt to §c2.46zl §a+ §cVAT!");
	  $sender->sendMessage("§a* §7- §aMozna takze kupic doladowanie do §cOrange §aza §c5zl");
	  $sender->sendMessage("§a* §7- §aKod zwrotny podaj tylko do §cvApple69!");
      $sender->sendMessage("§l§8[§7-----------§a[VIP]§7-----------§8]");
       return true;
   }

}
}
