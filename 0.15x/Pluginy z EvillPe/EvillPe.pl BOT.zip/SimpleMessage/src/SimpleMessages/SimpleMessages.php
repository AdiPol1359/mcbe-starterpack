<?php
/**
 * User: Michael Leahy
 * Date: 6/24/14
 * Time: 11:02 AM
 */

namespace SimpleMessages;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;

class SimpleMessages extends PluginBase{

    public $configFile;

    public function onEnable(){
        @mkdir($this->getDataFolder());
        $this->configFile = (new Config($this->getDataFolder()."config.yml", Config::YAML, array(
            "messages" => array(
                "Zakup rangi §8[§aVIP§8] §7pod komenda: §a/vip §8•",
                "Zakup rangi §8[§aMVIP§8] §7pod komenda: §a/mvip §8•",
                "Zakup rangi §8[§aGVIP§8] §7pod komenda: §a/gvip §8•",
            ),
            "time" => "60",
            "prefix" => "§4EvillPe.pl§7",
            "color" => "§7"
        )))->getAll();

        $time = intval($this->configFile["time"]) * 20;
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new SimpleMessagesTask($this), $time);

        $this->getLogger()->info("I've been enabled!");
    }

    public function onDisable(){
        $this->getLogger()->info("I've been disabled!");
    }

}
