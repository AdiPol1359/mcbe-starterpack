<?php

namespace uvip;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("vip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "pomoc"){
      $sender->sendMessage("§l§8[§7-----------§a[§7POMOC§a]§7-----------§8]");
	  $sender->sendMessage("§a> §7Pomocne komendy Gildi: §b/g pomoc 1,2,3 §a<");
      $sender->sendMessage("§a> §7Komenda na zakup BoyFarmer'a: §b/boyfarmer §a<");
	  $sender->sendMessage("§a> §7Komenda na zakup CobbleX'a: §b/cobblex §a<");
	  $sender->sendMessage("§a> §7Komenda na zakup Stoniarki: §b/stoniarka §a<");
	  $sender->sendMessage("§a> §7Komenda na zakup Obsydianiarki: §b/obsydianiarka §a<");
      $sender->sendMessage("§a> §7Komenda na zakup Efektow: §b/efekt §a<");
	  $sender->sendMessage("§a> §7Komenda na zakup Enchantu: §b/ench §a<");
      $sender->sendMessage("§a> §7Startowe itemki i nie tylko znajdziesz pod: §b/kit §a<");
      $sender->sendMessage("§a> §cWiecej komend juz wkrotce!§a <");
      $sender->sendMessage("§l§8[§7-----------§a[§7POMOC§a]§7----------§8]");
       return true;
   }

}
}
