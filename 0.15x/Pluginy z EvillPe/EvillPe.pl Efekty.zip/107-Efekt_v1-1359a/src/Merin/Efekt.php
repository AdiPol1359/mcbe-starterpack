<?php

namespace Merin;

use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;

class Efekt extends PluginBase
{
	public function onCommand(CommandSender $sender, Command $cmd, $label, array $args)
	{
		switch($cmd->getName())
		{
			case "efekt":
			if ($args[0] == "skok")
			{
				if ($sender->getInventory()->contains(Item::get(266, 0, 10)))
				{
					$sender->getInventory()->removeItem(Item::get(266, 0, 10));
					$nick = $sender->getName();
					$cmd = "effect $nick 8 180 1";
					$sender->sendMessage("• [§eEfekt] Zakupiłeś efekt skoku na 3 minuty!");
					$this->getServer()->dispatchCommand(new ConsoleCommandSender, $cmd);
				}
				else
				{
					$sender->sendMessage("• [§eEfekt] Nie masz w ekwipunku 10 złota!");
				}
			}
			elseif ($args[0] == "silka")
			{
				if ($sender->getInventory()->contains(Item::get(266, 0, 15)))
				{
					$sender->getInventory()->removeItem(Item::get(266, 0, 15));
					$nick = $sender->getName();
					$cmd = "effect $nick 5 120 0";
					$sender->sendMessage("• [§eEfekt§8] Zakupiłeś efekt siły na 2 minuty!");
					$this->getServer()->dispatchCommand(new ConsoleCommandSender, $cmd);
				}
				else
				{
					$sender->sendMessage("• [Efekt] Nie masz w ekwipunku 15 złota!");
				}
			}
			elseif ($args[0] == "szybkosc")
			{
				if ($sender->getInventory()->contains(Item::get(266, 0, 10)))
				{
					$sender->getInventory()->removeItem(Item::get(266, 0, 10));
					$nick = $sender->getName();
					$cmd = "effect $nick 1 240 0";
					$sender->sendMessage("• [§eEfekt] Zakupiłeś efekt szybkości na 4 minuty!");
					$this->getServer()->dispatchCommand(new ConsoleCommandSender, $cmd);
				}
				else
				{
					$sender->sendMessage("• [§eEfekt] Nie masz w ekwipunku 10 złota!");
				}
			}
			elseif ($args[0] == "regeneracja")
			{
				if ($sender->getInventory()->contains(Item::get(266, 0, 15)))
				{
					$sender->getInventory()->removeItem(Item::get(266, 0, 15));
					$nick = $sender->getName();
					$cmd = "effect $nick 10 120 0";
					$sender->sendMessage("• [§eEfekt] Zakupiłeś efekt regeneracjii na 2 minuty!");
					$this->getServer()->dispatchCommand(new ConsoleCommandSender, $cmd);
				}
				else
				{
					$sender->sendMessage("• [§eEfekt] Nie masz w ekwipunku 15 złota!");
				}
			}
			else
			{
				$sender->sendMessage("§8[§7---------------§e[Efekt]§7---------------§8]");
				$sender->sendMessage("§7Aby zakupic efekt wpisz:");
				$sender->sendMessage("§7/efekt skok - Skok §c2 §7na §c3 §7minuty");
				$sender->sendMessage("§7Koszt: §c10 §7zlota");
				$sender->sendMessage("§7/efekt sila - Sila §c1 §7na §c2 §7minuty");
				$sender->sendMessage("§7Koszt: §c15 §7zlota");
				$sender->sendMessage("§7/efekt szybkosc - Szybkosc §c1 §7na §c4 §7minuty");
				$sender->sendMessage("§7Koszt: §c10 §7zlota");
				$sender->sendMessage("§7/efekt regeneracja - Regeneracja §c1 §7na §c2 §7minuty");
				$sender->sendMessage("§7Koszt: §c15 §7zlota");
				$sender->sendMessage("§8[§7---------------§e[Efekt]§7---------------§8]");
			}
		}
	}
}
?>