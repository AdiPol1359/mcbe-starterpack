<?php

namespace drop;

use pocketmine\plugin\PluginBase as P;
use pocketmine\event\Listener as L;
use pocketmine\utils\TextFormat;
use pocketmine\utils\MainLogger;
use pocketmine\block\Air;
use pocketmine\entity\Effect;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\level\sound\PopSound as Pop;
use pocketmine\level\particle\LavaParticle as Lava;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\item\Item;

class Main extends P implements L{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
		$this->saveDefaultConfig();
		$this->getServer()->getLogger()->info(TextFormat::GREEN."[DropStone] Włączony!");
	}

	
	public function onBreak(BlockBreakEvent $e){
		$player = $e->getPlayer();
		$block = $e->getBlock();
		$gracz = $e->getPlayer()->getName();
		if($e->getBlock()->getId() == 1){
			 switch(mt_rand(1,200)){
		    case 1:
		    $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(3) §7Diamenty!");
		    $player->getInventory()->addItem(Item::get(264, 0, 3));
		    break;
         case 2:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(1) §7Diament!");
         $player->getInventory()->addItem(Item::get(264, 0, 1));
         break;
         case 3:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(1) §7Sztabke Zelaza!");
         $player->getInventory()->addItem(Item::get(265, 0, 1));
         break;
         case 4:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(1) §7Sztabke Zlota!");
         $player->getInventory()->addItem(Item::get(266, 0, 1));
         break;
         case 8:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(4) §7Obsydian!");
         $player->getInventory()->addItem(Item::get(49, 0, 4));
         break;
         case 5:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(1) §7Butelke exp'a");
         $player->getInventory()->addItem(Item::get(384, 0, 1));
         break;
         case 7:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(1) §7Emerald
		 ");
         $player->getInventory()->addItem(Item::get(388, 0, 1));
         break;
         case 8:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(5) §7Redstone");
         $player->getInventory()->addItem(Item::get(331, 0, 5));
         break;
         case 9:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §aEffekt Na Szybsze Kopanie!");
         $effect = Effect::getEffect(3);
         $effect->setDuration(600);
         $player->addEffect($effect);
         $player->addExperience(1);
         break;
         case 10:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(6) §7Jablek!");
         $player->getInventory()->addItem(Item::get(260, 0, 6));
         break;
		 case 11:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(5) §7Wegla");
         $player->getInventory()->addItem(Item::get(263, 0, 5));
         break;
		 case 12:
	    $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(2) §7Wegla!");
         $player->getInventory()->addItem(Item::get(263, 0, 2));
         break;
		 case 13:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(6) §7Sztabek Zelaza!");
         $player->getInventory()->addItem(Item::get(265, 0, 6));
         break;
		 case 14:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(4) §7Sztabek Zlota!");
         $player->getInventory()->addItem(Item::get(266, 0, 4));
         break;
		 case 15:
         $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(9) §7Lazurytu!");
         $player->getInventory()->addItem(Item::get(351, 4, 9));
         break;
		 case 16:
		 $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §a(2) §7Diamenty");
		 $player->getInventory()->addItem(Item::get(264, 0, 2));
		 break;
		 case 17:
		 $player->sendMessage("§7• §8[§aDrop§8] §7Brawo! Wykopales: §aEffekt Na Widzenie W Ciemnosci!");
		 $effect = Effect::getEffect(16);
		 $effect = setDuration(600);
		 $player->addEffect($effect);
		 $player->addExperience(1);
		 break;
			 }
		}
	}
}
