<?php

namespace myt;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("myt loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "mvip"){
      $sender->sendMessage("§8[§7-----------§8[§aMVIP]§7-----------§8]");
      $sender->sendMessage("§a* §7- Co posiada ranga §aMVIP§7?");
      $sender->sendMessage("§a* §7- kit mvip, a w nim:");
      $sender->sendMessage("§a* §7- §aDiamentowe spodnie, buty");
      $sender->sendMessage("§a* §7- §aDiamentowy helm, klate");
	  $sender->sendMessage("§a* §7- §aDiamentowe narzedzia (Miecz,kilof)");
	  $sender->sendMessage("§a* §7- §a3 Stoniarki oraz 32 Diamenty");
	  $sender->sendMessage("§a* §7- Dodatkowe permisje takie jak:");
	  $sender->sendMessage("§a* §7- §aTeleportacja w ostatnie miejsce lub miejsce smierci: /back");
	  $sender->sendMessage("§a* §7- §aNaprawa konktretnego lub wszystkich przedmiotow: /repair");
	  $sender->sendMessage("§a* §7- Jak kupic range §aMVIP§7?");
	  $sender->sendMessage("§a* §7- §aWyslij sms'a o tresci §cAP.HOSTMC");
	  $sender->sendMessage("§a* §7- §aPod numer §c76068 §akoszt to §c7.38zl §a+ §cVAT!");
	  $sender->sendMessage("§a* §7- §aMozna takze kupic doladowanie do §cOrange §aza §c5zl");
	  $sender->sendMessage("§a* §7- §aKod zwrotny podaj tylko do §cvApple69");
      $sender->sendMessage("§8[§7-----------§8[§aMVIP]§7-----------§8]");
       return true;
   }

}
}
