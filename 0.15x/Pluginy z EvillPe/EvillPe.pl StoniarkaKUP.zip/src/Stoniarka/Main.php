<?php

namespace Stoniarka;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info(" Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('stoniarka'))) {
				if(empty($args)) {
					$sender->sendMessage("§l§8[§7-----------§c[Stoniarka]§7-----------§8]");
					$sender->sendMessage("§c*§7 - Co to §cStoniarka§7?");
					$sender->sendMessage("§c*§7 - Jest to §cEnd_Stone §7ktory genruje §cstone");
                         $sender->sendMessage("§c*§7 - Aby kupic, wpisz §c/stoniarka kup");
					$sender->sendMessage("§c*§7 - Koszt: §c15 diamentow");
					$sender->sendMessage("§l§8[§7-----------§c[Stoniarka]§7-----------§8]");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 15))){
                               $sender->getInventory()->addItem(Item::get(121, 0, 1));
                               $sender->getInventory()->removeItem(Item::get(264, 0, 15));
						$sender->sendMessage("§c• [EvillPe.pl] Zakupiles §6Stoniarke�� ");
            }
						else{
							$sender->sendMessage("§c• [EvillPe.pl] Nie posiadasz 15 diamentow! •");
							}
						return true;
                          }
	
	}
						}
					}
