<?php

namespace Merin;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info(" Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('ench'))) {
				if(empty($args)) {
					$sender->sendMessage("§8§l[§7-----------§c[Enchant]§7------------§8]");
                    $sender->sendMessage("§c* §7- Co to jest §cEnchant§7?");
                    $sender->sendMessage("§c* §7- Jest to komenda dzieki ktorej mozesz kupic §cStol do Enchantu");
					$sender->sendMessage("§c* §7- Aby kupic wpisz §c/ench kup §7koszt to §c32 Diamenty!");
                    $sender->sendMessage("§8§l[§7-----------§c[Enchant]§7------------§8]");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 32))){
                        $sender->getInventory()->addItem(Item::get(116, 0, 1));
                        $sender->getInventory()->removeItem(Item::get(264, 0, 32));
						$sender->sendMessage("§8[§cEvillPe.pl§8] §aZakupiłeś Stól do enchantu! ");
            }
						else{
							$sender->sendMessage("§8[§cEvillPe.pl§8] §cNie posiadasz 32 diamentów!");
							}
						return true;
                          }
	
	}
						}
					}
