<?php

namespace perly;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info("Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('perly'))) {
				if(empty($args)) {
					$sender->sendMessage("§l§8[§7-----------§c[EnderPerly]§7-----------§8]");
					$sender->sendMessage("§c* §7- Co to jest §cEnderPerla§7?"); 
					$sender->sendMessage("§c* §7- Jes to to dodatek ktory umozliwia telportacje:");
					$sender->sendMessage("§c* §7- W miejsce po zucie §cKulka Sniezki§7!");
					$sender->sendMessage("§c* §7- §cPerly §7kupisz komenda:");
					$sender->sendMessage("§c* §7- §c/perly kup §7Koszt: §c10 §7emeraldow");
					$sender->sendMessage("§l§8[§7-----------§c[EnderPerly]§7-----------§8]");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(388, 0, 10))){
						$sender->getInventory()->addItem(Item::get(332, 0, 5));
						 $sender->getInventory()->removeItem(Item::get(388, 0, 10));
						$sender->sendMessage("§a• [EvillPe.pl] Zakupiłeś 5 EnderPerel •");
            }
						else{
							$sender->sendMessage("§c• [EvillPe.pl] potrzebujesz 10 emeraldow •");
							}
						return true;
                          }
	
	}
						}
					}
