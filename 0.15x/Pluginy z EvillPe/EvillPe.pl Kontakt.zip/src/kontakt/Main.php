<?php

namespace kontakt;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("kontakt loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "kontakt"){
      $sender->sendMessage("§l§8[§7-----------§c[Kontakt]§7-----------§8]");
      $sender->sendMessage("§c* §7- Kontakt z Administracja (Facebook):");
      $sender->sendMessage("§c* §7- §cRaDeK12102003 §7- Radek Jendrych");
      $sender->sendMessage("§c* §7- §cvApple69 §7- Krystian Kaminski");
      $sender->sendMessage("§c* §7- §cFireWolfBR §7- Damian Muniak");
	  $sender->sendMessage("§c* §7- §cNAMEtenFEJM §7- Kornel Wielgus");
	  $sender->sendMessage("§c* §7- §cGejben §7- Camil Zietalek");
      $sender->sendMessage("§l§8[§7-----------§c[Kontakt]§7-----------§8]");
       return true;
   }

}
}
