<?php

namespace Obsydianiarka;

use pocketmine\plugin\PluginBase as PluginBase;
use pocketmine\event\Listener as Listener;
use pocketmine\utils\TextFormat;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\utils\Config;
use pocketmine\block\Block;
use pocketmine\block\Air;
use pocketmine\block\Obsidian;
use pocketmine\math\Vector3;
use pocketmine\item\Item;


class Main extends PluginBase implements Listener{

 
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);	
		$this->saveDefaultConfig();
		$this->getServer()->getLogger()->info(TextFormat::GREEN . "Obsydianiarki zaladowano!");
	}
	
	public function onPlace(BlockPlaceEvent $event){
	 $blok = $event->getBlock();
	 $gracz = $event->getPlayer();
	 $y = $blok->getFloorY();
	 $x = $blok->getFloorX();
	 $z = $blok->getFloorZ();
	 
  	 if($blok->getId() == 165){
  	  if(!($event->isCancelled())){
	   $gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()+1, $blok->getFloorZ()), new Obsidian());
     $gracz->sendMessage("§8• (§cNicePE§8) §7Postawiles Obsydianiarkę! §8•");
	  }else{
	   $gracz->sendMessage("§8• (§cNicePE§8) §7Ten teren jest zajęty! §8•");
	  }	 
	 }
 }
	 
	 public function onBreak(BlockBreakEvent $event){
	  $blok = $event->getBlock();
	  $gracz = $event->getPlayer();
	  $y = $blok->getFloorY();
	  $x = $blok->getFloorX();
  	 $z = $blok->getFloorZ();
  	  if($blok->getId() == 49){
  	   if($gracz->getLevel()->getBlock(new Vector3($x, $y-1, $z))->getId() == 165) {
  	    $event->setCancelled();
  	     if($this->getConfig()->get("rzeczy-do-eq") == "tak"){
  	       $gracz->getInventory()->addItem(Item::get($this->getConfig()->get("item"), 0, $this->getConfig()->get("ilosc")));
  	      }elseif($this->getConfig()->get("rzeczy-do-eq") == "nie"){
  	       $gracz->getLevel()->dropItem(new Vector3($x, $y, $z), Item::get($this->getConfig()->get("item"), 0, $this->getConfig()->get("ilosc")));
  	      }
  	   }
			 }elseif($blok->getId() == 165){
		   	$gracz->getLevel()->setBlock(new Vector3($blok->getFloorX(), $blok->getFloorY()+1, $blok->getFloorZ()), new Obsidian());
     $gracz->sendMessage("§8• (§cNicePE§8) §7Usunąłeś Obsydianiarkę! §8•");
	  }
		}
	}