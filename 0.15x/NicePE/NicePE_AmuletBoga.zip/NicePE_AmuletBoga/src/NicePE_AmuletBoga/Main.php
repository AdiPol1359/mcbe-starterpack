<?php

namespace NicePE_AmuletBoga;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;

use pocketmine\Server;
use pocketmine\Player;

use pocketmine\command\{Command, CommandSender};
use pocketmine\item\Item;
use pockemine\inventory\Inventory;
use pocketmine\entity\Effect;
use pocketmine\event\player\PlayerInteractEvent;

class Main extends PluginBase implements Listener {

    public function onEnable() {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
	public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
		if($cmd->getName() == "amuletboga"){
			$sender->sendMessage("ustaw co tu ma pisac");
			
		}
		if($cmd->getName() == "ab"){
			if(!$sender->hasPermission("nicepe.ab")){
				$sender->sendMessage("§8• [§cNicePE§8] §7Nie posiadasz permisji (nicepe.ab)");
				}
				if($sender->hasPermission("nicepe.ab")){
					if(!isset($args[0])){
					$s = $sender->getPlayer();
					$amuletboga = Item::get(369, 0, 1);
				    $amuletboga->setCustomName("§r§l§2Amulet Boga");
			        $s->getInventory()->addItem($amuletboga);
	                $sender->sendMessage("§8• [§cNicePE§8]§7 Otrzymałeś Amulet Boga! §8•");
              }
              if(isset($args[0])){
$gracz = $this->getServer()->getPlayer($args[0]);
$nick = $args[0];
              	$amuletboga = Item::get(369, 0, 1);
				    $amuletboga->setCustomName("§r§l§2Amulet Boga");
				    if($gracz){
				    $gracz->getInventory()->addItem($amuletboga);
	                $sender->sendMessage("§8• [§cNicePE§8]§7 Gracz §c$nick §7otrzymal Amulet Boga! §8•");
              	$gracz->sendMessage("§8• [§cNicePE§8]§7 Otrzymales Amulet Boga! §8•");
              }
              if(!$gracz){
              	 $sender->sendMessage("§8• [§cNicePE§8]§7 Nie znaleziono gracza §c" . $nick . "§7!§8•");
              	
              }
              }
              }
              }
              }
        public function amulet(PlayerInteractEvent $event){
		$gracz = $event->getPlayer();
		$nick = $gracz->getName();
		$item = $gracz->getInventory()->getItemInHand();
		if($item->getId() == 369){
			if($item->getName() == "§r§l§2Amulet Boga"){
				$event->getPlayer()->sendMessage("§8• [§cNicePE§8]§7 Użyłeś Amuletu Boga! §8•");
				$event->getPlayer()->addEffect(Effect::getEffect(1)->setAmplifier(2)->setDuration(20*120));
				$event->getPlayer()->addEffect(Effect::getEffect(5)->setAmplifier(1)->setDuration(20*120));
				$event->getPlayer()->addEffect(Effect::getEffect(10)->setAmplifier(3)->setDuration(20*120));
				$event->getPlayer()->addEffect(Effect::getEffect(12)->setAmplifier(2)->setDuration(20*120));
				}
				}
				}
				}