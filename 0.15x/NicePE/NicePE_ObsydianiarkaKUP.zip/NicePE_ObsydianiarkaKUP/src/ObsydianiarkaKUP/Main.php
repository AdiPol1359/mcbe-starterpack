<?php

namespace ObsydianiarkaKUP;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info(" Zaladowane OBS");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('obsydianiarka'))) {
				if(empty($args)) {
					$sender->sendMessage("§l§8)§7===========§8( (§cObsydianiarka§8) )§7===========§8(");
					$sender->sendMessage("§c* §7- Co to §cObsydianiarka§7?");
					$sender->sendMessage("§c* §7- Jest to §cSlime_Block §7ktory generuje §cObsydian");
                    $sender->sendMessage("§c §7- Aby kupic, wpisz §c/obsydianiarka kup");
					$sender->sendMessage("§c* §7- Koszt: §c15 diamentow");
					$sender->sendMessage("§l§8)§7===========§8( (§cObsydianiarka§8) )§7===========§8(");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 15))){
                               $sender->getInventory()->addItem(Item::get(165, 0, 1));
                               $sender->getInventory()->removeItem(Item::get(264, 0, 15));
						$sender->sendMessage("§8• (§cNicePE§8) §7Zakupiłeś Obsydianiarkę! §8•");
            }
						else{
							$sender->sendMessage("§8• (§cNicePE§8) §7Nie Posiadasz 15 Diamentów! §8•");
							}
						return true;
                          }
	
	}
						}
					}