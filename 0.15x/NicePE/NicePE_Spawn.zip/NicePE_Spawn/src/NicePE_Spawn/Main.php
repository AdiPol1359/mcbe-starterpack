<?php

namespace NicePE_Spawn;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\entity\Effect;
use pocketmine\command\CommandSender;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener{
    public $task;
    public function onEnable(){
    					@mkdir($this->getDataFolder());
 $this->spawn = new Config($this->getDataFolder() . "spawn.yml", Config::YAML);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->task = [];
        $this->getLogger()->info("Plugin wlaczony!");
    }
    
	public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
       	if($cmd->getName() == "spawn"){
				if(empty($args)){
					if($sender->hasPermission("nicepe.spawnadmin") or $sender->isOp()){
			$sender->teleport($sender->getLevel()->getSafeSpawn());
	$sender->sendMessage("§8• (§cSpawn§8) §7Zostales przeteleportowany na spawn! §8•");
						}else{
					if($sender->hasPermission("nicepe.spawn10")){
            $t = new Teleportacja($this);
            $t->createTeleportacja($sender);
            $h = ($this->getServer()->getScheduler()->scheduleDelayedTask($t, 20*10));
            $this->task[$sender->getName()] = array($t,$h);
      $x = $sender->getFloorX();
      $y = $sender->getFloorY();
      $z = $sender->getFloorZ();
      $nick = $sender->getName();
      $this->spawn->set("" . $nick . "_X", $x);
      $this->spawn->set("" . $nick . "_Y", $y);
      $this->spawn->set("" . $nick . "_Z", $z);
      $this->spawn->save();
							$sender->sendMessage("§8• (§cSpawn§8) §7Teleportacja nastąpi za §c10 §7sekund! Nie ruszaj sie §8•");
        }
					if($sender->hasPermission("nicepe.spawn7")){
            $t = new Teleportacja($this);
            $t->createTeleportacja($sender);
            $h = ($this->getServer()->getScheduler()->scheduleDelayedTask($t, 20*7));
            $this->task[$sender->getName()] = array($t,$h);
      $x = $sender->getFloorX();
      $y = $sender->getFloorY();
      $z = $sender->getFloorZ();
      $nick = $sender->getName();
      $this->spawn->set("" . $nick . "_X", $x);
      $this->spawn->set("" . $nick . "_Y", $y);
      $this->spawn->set("" . $nick . "_Z", $z);
      $this->spawn->save();
							$sender->sendMessage("§8• (§cSpawn§8) §7Teleportacja nastąpi za §c7 §7sekund! Nie ruszaj sie §8•");
        }
					if($sender->hasPermission("nicepe.spawn5")){
            $t = new Teleportacja($this);
            $t->createTeleportacja($sender);
            $h = ($this->getServer()->getScheduler()->scheduleDelayedTask($t, 20*5));
            $this->task[$sender->getName()] = array($t,$h);
      $x = $sender->getFloorX();
      $y = $sender->getFloorY();
      $z = $sender->getFloorZ();
      $nick = $sender->getName();
      $this->spawn->set("" . $nick . "_X", $x);
      $this->spawn->set("" . $nick . "_Y", $y);
      $this->spawn->set("" . $nick . "_Z", $z);
      $this->spawn->save();
							$sender->sendMessage("§8• (§cSpawn§8) §7Teleportacja nastąpi za §c5 §7sekund! Nie ruszaj sie §8•");
        }
        }
      }
}
}


	public function onMove(PlayerMoveEvent $event){
		$player = $event->getPlayer();
		$nick = $player->getName();
		$x = $this->spawn->get("" . $nick . "_X");
		$y = $this->spawn->get("" . $nick . "_Y");
		$z = $this->spawn->get("" . $nick . "_Z");
		if($x){
						if(!($x == $player->getFloorX())){
					if($player->getName() !== null and isset($this->task[$player->getName()])){
                $this->task[$player->getName()][1]->cancel();
                unset($this->task[$player->getName()]);
							$player->sendMessage("§8• (§cSpawn§8) §7Poruszyłeś się! Teleportacja anulowana §8•");
							$this->spawn->remove("" . $nick . "_X");
     		$this->spawn->remove("" . $nick . "_Y");
		     $this->spawn->remove("" . $nick . "_Z");
		     $this->spawn->save();
							$player->removeEffect(9);
	}
    }
    						if(!($y == $player->getFloorY())){
					if($player->getName() !== null and isset($this->task[$player->getName()])){
                $this->task[$player->getName()][1]->cancel();
                unset($this->task[$player->getName()]);
							$player->sendMessage("§8• (§cSpawn§8) §7Poruszyłeś się! Teleportacja anulowana §8•");
						 $this->spawn->remove("" . $nick . "_X");
     		$this->spawn->remove("" . $nick . "_Y");
		     $this->spawn->remove("" . $nick . "_Z");
		     $this->spawn->save();
							$player->removeEffect(9);
	}
    }
    						if(!($z == $player->getFloorZ())){
					if($player->getName() !== null and isset($this->task[$player->getName()])){
                $this->task[$player->getName()][1]->cancel();
                unset($this->task[$player->getName()]);
							$player->sendMessage("§8• (§cSpawn§8) §7Poruszyłeś się! Teleportacja anulowana §8•");
							$this->spawn->remove("" . $nick . "_X");
     		$this->spawn->remove("" . $nick . "_Y");
		     $this->spawn->remove("" . $nick . "_Z");
		     $this->spawn->save();
							$player->removeEffect(9);
	}
    }
}
}
    public function onDisable(){
        foreach($this->getServer()->getOnlinePlayers() as $p){
            $t = new Teleportacja($this);
            $t->onRun(-1);
        }
        $this->getLogger()->info("Plugin wylaczony!");
    }
    public function onQuit(PlayerQuitEvent $e){
    	$nick = $e->getPlayer()->getName();
    	if($this->spawn->get("" . $nick . "_X")){
    		$this->spawn->remove("" . $nick . "_X");
     	$this->spawn->remove("" . $nick . "_Y");
		    $this->spawn->remove("" . $nick . "_Z");
    		$this->spawn->save();
    	}
    }
}