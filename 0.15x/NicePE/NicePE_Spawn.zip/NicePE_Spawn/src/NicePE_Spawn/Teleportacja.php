<?php

namespace NicePE_Spawn;

use pocketmine\scheduler\PluginTask;
use pocketmine\Player;
use pocketmine\entity\Effect;

class Teleportacja extends PluginTask{
    protected $plugin;
    private $p;
    public function __construct(Main $plugin){
    	parent::__construct($plugin);
        $this->plugin = $plugin;
    }
	
    public function onRun($tick){
        $this->revert();
    }
    
    public function revert(){
	      $this->p->teleport($this->p->getLevel()->getSafeSpawn());
	$this->p->sendMessage("§8• (§cSpawn§8) §7Zostales przeteleportowany na spawn! §8•");
		$nick = $this->p->getName();
   $this->plugin->spawn->remove("" . $nick . "_X");
   $this->plugin->spawn->remove("" . $nick . "_Y");
   $this->plugin->spawn->remove("" . $nick . "_Z");
   $this->plugin->spawn->save();
    }
    
    public function createTeleportacja($player){
        $this->p = $player;
        if($this->p->hasPermission("nicepe.spawn10")){
     			$player->addEffect(Effect::getEffect(9)->setAmplifier(1)->setDuration(20*10));
    }
        if($this->p->hasPermission("nicepe.spawn7")){
     			$player->addEffect(Effect::getEffect(9)->setAmplifier(1)->setDuration(20*7));
    }
        if($this->p->hasPermission("nicepe.spawn5")){
     			$player->addEffect(Effect::getEffect(9)->setAmplifier(1)->setDuration(20*5));
    }
    }
}