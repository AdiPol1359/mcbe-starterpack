<?php

namespace NicePE_SystemBanowania;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
		$this->getLogger()->info("Plugin włączono");
				@mkdir($this->getDataFolder());
				$this->ban = new Config($this->getDataFolder() . "ban.yml", Config::YAML);
				$this->banip = new Config($this->getDataFolder() . "ban-ip.yml", Config::YAML);
		$this->bancid = new Config($this->getDataFolder() . "ban-cid.yml", Config::YAML);
	}
	public function onDisable(){
		$this->getLogger()->info("Plugin wyłączono");
	}
	  public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
	  	$admin = $sender->getName();
	 if($cmd->getName() == "zbanuj"){
	 	if(!isset($args[0])){
	 	$sender->sendMessage("§7Uzyj:");
	 	$sender->sendMessage("§7/zbanuj (nick) - brak powodu");
	 	$sender->sendMessage("§7/zbanuj (nick) (powod) - z powodem");
	 }
	 //ban bez powodu
	 if(isset($args[0]) && !isset($args[1])){
	 $ban_gracz = $this->getServer()->getPlayer($args[0]);
	 $ban_nick = $args[0];
	 if(!$ban_gracz){
	 	$this->ban->set("".strtolower($ban_nick)."_admin", $admin);
	 	$this->ban->save();
	 	$this->ban->save();
	Server::getInstance()->broadcastMessage("§8• (§cBan§8) §7Gracz §c$ban_nick §7zostal zbanowany z powodu: §4brak §8•");
	 }
	 if($ban_gracz){
	 	$this->ban->set("".strtolower($ban_nick)."_admin", $admin);
	 	$this->ban->save();
	 	$this->ban->save();
	 	$powod = "§cZostales zbanowany!
§7Przez: §c$admin
§7Powod: §cbrak
§7Typ: §cBan na nick";
	Server::getInstance()->broadcastMessage("§8• (§cBan§8) §7Gracz §c$ban_nick §7zostal zbanowany z powodu: §4brak §8•");
	$ban_gracz->close("", $powod);
	 }
	 }
	 //ban z powodem
if(isset($args[1])){
 $ban_powod = "";
 for ($i = 1; $i < count($args); $i++) {
 $ban_powod .= $args[$i];
 $ban_powod .= " ";
}
 $ban_powod = substr($ban_powod, 0, strlen($ban_powod) - 1);
	 $ban_gracz = $this->getServer()->getPlayer($args[0]);
	 $ban_nick = $args[0];
	 if(!$ban_gracz){
	 	$this->ban->set("".strtolower($ban_nick)."_admin", $admin);
	 	$this->ban->set("".strtolower($ban_nick)."_powod", $ban_powod);
	 	$this->ban->save();
	Server::getInstance()->broadcastMessage("§8• (§cBan§8) §7Gracz §c$ban_nick §7zostal zbanowany z powodu: §4$ban_powod §8•");
	 }
	 if($ban_gracz){
	 	$this->ban->set("".strtolower($ban_nick)."_admin", $admin);
	 	$this->ban->set("".strtolower($ban_nick)."_powod", $ban_powod);
	 	$this->ban->save();
	 	$powod = "§cZostales zbanowany!
§7Przez: §c$admin
§7Powod: §c$ban_powod
§7Typ: §cBan na nick";
	Server::getInstance()->broadcastMessage("§8• (§cBan§8) §7Gracz §c$ban_nick §7zostal zbanowany z powodu: §4brak §8•");
	$ban_gracz->close("", $powod);
	 }
	 }
	 }
	 	 if($cmd->getName() == "zbanuj-ip"){
	 	if(!isset($args[0])){
	 	$sender->sendMessage("§7Uzyj:");
	 	$sender->sendMessage("§7/zbanuj-ip (nick) - brak powodu");
	 	$sender->sendMessage("§7/zbanuj-ip (nick) (powod) - z powodem");
	 }
	 //ban-ip bez powodu
	 if(isset($args[0]) && !isset($args[1])){
	 	$banip_nick = $args[0];
	 $banip_gracz = $this->getServer()->getPlayer($args[0]);
	 $ip = $banip_gracz->getAddress();
	 if(!$banip_gracz){
	 	$this->banip->set(strtolower($banip_nick), $ip);
	 	$this->banip->set($ip, "brak");
	 	$this->banip->set("".$ip."_admin", $admin);
	 	$this->banip->save();
	 	$this->banip->save();
	Server::getInstance()->broadcastMessage("§8• (§cBan§8) §7Gracz §c$ban_nick §7zostal zbanowany z powodu: §4brak §8•");
	 }
	 if($banip_gracz){
	 		 $ip = $banip_gracz->getAddress();
	 	$this->banip->set(strtolower($banip_nick), $ip);
	 	$this->banip->set($ip, "brak");
	 	$this->banip->set("".$ip."_admin", $admin);
	 	$this->banip->save();
	 	$powod = "§cZostales zbanowany!
§7Przez: §c$admin
§7Powod: §cbrak
§7Typ: §cBan IP";
	Server::getInstance()->broadcastMessage("§8• (§cBan§8) §7Gracz §c$banip_nick §7zostal zbanowany na ip z powodu: §4brak §8•");
	$banip_gracz->close("", $powod);
	 }
	 }
	 //ban-ip z powodem
if(isset($args[1])){
 $banip_powod = "";
 for ($i = 1; $i < count($args); $i++) {
 $banip_powod .= $args[$i];
 $banip_powod .= " ";
}
 $banip_powod = substr($banip_powod, 0, strlen($banip_powod) - 1);
	 $banip_gracz = $this->getServer()->getPlayer($args[0]);
	 $banip_nick = $args[0];
	 	 $ip = $banip_gracz->getAddress();
	 if(!$banip_gracz){
	 	$this->banip->set(strtolower($banip_nick, $ip));
	 	$this->banip->set($ip, $banip_powod);
	 	$this->banip->set("".$ip."_admin", $admin);
	 	$this->banip->save();
	Server::getInstance()->broadcastMessage("§8• (§cBan§8) §7Gracz §c$banip_nick §7zostal zbanowany z powodu: §4$banip_powod §8•");
	 }
	 if($banip_gracz){
	 	$this->banip->set(strtolower($banip_nick, $ip));
	 	$this->banip->set($ip, $banip_powod);
	 	$this->banip->set("".$ip."_admin", $admin);
	 	$this->banip->save();
	 	$powod = "§cZostales zbanowany!
§7Przez: §c$admin
§7Powod: §c$banip_powod
§7Typ: §cBan IP";
	Server::getInstance()->broadcastMessage("§8• (§cBan§8) §7Gracz §c$ban_nick §7zostal zbanowany z powodu: §4$ban_powod §8•");
	$banip_gracz->close("", $powod);
	 }
	 }
	 }
	 if($cmd->getName()=="odbanuj"){
	 	if(empty($args)){
	 		$sender->sendMessage("§7Uzyj /odbanuj (nick)");
	 	}
	 	if(isset($args[0])){
	 		$unban_nick = $args[0];
if(!$this->ban->get(strtolower("".strtolower($unban_nick)."_admin"))){
	$sender->sendMessage("§8• (§cBan§8) §7Gracz §c$unban_nick §7nie jest zbanowany! §8•");
	}	
if($this->ban->get(strtolower("".strtolower($unban_nick)."_admin"))){
if($this->ban->get(strtolower("".strtolower($unban_nick)."_powod"))){
	$this->ban->remove(strtolower("".strtolower($unban_nick)."_admin"));
		$this->ban->remove(strtolower("".strtolower($unban_nick)."_powod"));
		$this->ban->save();
			Server::getInstance()->broadcastMessage("§7Gracz §c$unban_nick §7zostal odbanowany");
			return false;
	 		}
	 		if(!$this->ban->get(strtolower("".strtolower($unban_nick)."_powod"))){
	 				$this->ban->remove(strtolower("".strtolower($unban_nick)."_admin"));
	 				$this->ban->save();
			Server::getInstance()->broadcastMessage("§8• (§cBan§8) §7Gracz §c$unban_nick §7zostal odbanowany §8•");
			return false;
	 			}
	 	}
	 }
	 }
	 if($cmd->getName()=="odbanuj-ip"){
	 	 	if(empty($args)){
	 		$sender->sendMessage("§7Uzyj /odbanuj (nick)");
	 	}
	 	if(isset($args[0])){
	 		$unban_nick = strtolower($args[0]);
	 		$unban_ip = $this->banip->get(strtolower($unban_nick));
	 		if(!$unban_ip){
	 			$sender->sendMessage("§8• (§cBan§8) §7Gracz §c$unban_nick §7 nie jest zbanowany na ip! §8•");
	 		}
	 		if($unban_ip){
	 			$this->banip->remove($unban_nick);
	 			$this->banip->remove("".$unban_ip."_admin");
	 			$this->banip->remove($unban_ip);
	 			$this->banip->save();
	 		}
	 	}
	 }
	 }
	         public function onPreLogin(PlayerPreLoginEvent $e){
        $gracz = $e->getPlayer();
        $ip = $gracz->getAddress();
        $nick = strtolower($gracz->getName());
        $admin_ban = $this->ban->get("".strtolower($nick)."_admin");
        $powod_ban = $this->ban->get("".strtolower($nick)."_powod");
        
       	 $powod_banip =	$this->banip->get($ip);
      	 	$admin_banip = $this->banip->get("".$ip."_admin");
        //ban
   if($this->ban->get(strtolower("".strtolower($nick)."_admin"))){
if($this->ban->get("".strtolower($nick)."_powod")){
            $e->setCancelled();
            $e->setKickMessage("§cZostales zbanowany!
§7Przez: §c$admin_ban
§7Powod: §c$powod_ban
§7Typ: §cBan na nick");
        }
if(!$this->ban->get(strtolower("".strtolower($nick)."_powod"))){
            $e->setCancelled();
            $e->setKickMessage("§cZostales zbanowany!
§7Przez: §c$admin_ban
§7Powod: §cbrak
§7Typ: §cBan na nick");
        }
    }
    if($this->banip->get("".$ip."_admin")){
    $e->setCancelled();
    $e->setKickMessage("§cZostales zbanowany!
§7Przez: §c$admin_banip
§7Powod: §c$powod_banip
§7Typ: §cBan na IP");
    }
	 }
	 }