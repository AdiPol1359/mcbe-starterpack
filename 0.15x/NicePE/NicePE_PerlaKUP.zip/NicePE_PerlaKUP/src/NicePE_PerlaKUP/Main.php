<?php

namespace NicePE_PerlaKUP;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info(" Zaladowane perły!");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('perla'))) {
				if(empty($args)) {
					$sender->sendMessage("§l§8)§7============§8( (§cPerla§8) )§7============§8(");
					$sender->sendMessage("§c* §7- Perla kresu jest dodatkiem, ktory \n     §7teleportuje we wskazane miejsce");
					$sender->sendMessage("§c* §7- Jak dziala ten dodatek?");
                    $sender->sendMessage("§c* §7- Wystarczy rzucic snieszka a zostaniesz \n     §7przeteleportowany w to miejsce, w ktore \n     §7ona spadnie!");
					$sender->sendMessage("§c* §7- Koszt: §c10 diamentow");
					$sender->sendMessage("§c* §7- Mozesz kupic pod komenda: §c/perla kup");
					$sender->sendMessage("§l§8)§7===========§8( (§cPerla§8) )§7===========§8(");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(264, 0, 10))){
                               $sender->getInventory()->addItem(Item::get(332, 0, 1));
                               $sender->getInventory()->removeItem(Item::get(264, 0, 10));
						$sender->sendMessage("§8• (§cNicePE§8) §7Zakupiłeś Perłę! §8•");
            }
						else{
							$sender->sendMessage("§8• (§cNicePE§8) §7Nie Posiadasz 10 Diamentów! §8•");
							}
						return true;
                          }
	
	}
						}
					}