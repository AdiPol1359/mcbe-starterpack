<?php

namespace NicePE_TPA;

use pocketmine\scheduler\PluginTask;
use pocketmine\Player;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\entity\Effect;

class Teleportacja extends PluginTask{
    protected $plugin;
    private $p;
    public function __construct(Main $plugin){
    	parent::__construct($plugin);
        $this->plugin = $plugin;
    }
	
    public function onRun($tick){
        $this->revert();
    }
    
    public function revert(){
    	$nick = $this->p->getName();
    	$x = $this->plugin->tp->get("" . $nick . "_X");
     $y = $this->plugin->tp->get("" . $nick . "_Y");
     $z = $this->plugin->tp->get("" . $nick . "_Z");
       $this->p->teleport(new Position($x, $y, $z));
	   $this->plugin->spawn->remove("" . $nick . "_X");
   $this->plugin->spawn->remove("" . $nick . "_Y");
   $this->plugin->spawn->remove("" . $nick . "_Z");
   $this->plugin->tp->remove("" . $nick . "_X");
   $this->plugin->tp->remove("" . $nick . "_Y");
   $this->plugin->tp->remove("" . $nick . "_Z");
   $this->plugin->spawn->save();
   $this->plugin->tp->save();
    }
    
    public function createTeleportacja($player){
        $this->p = $player;
     			$player->addEffect(Effect::getEffect(9)->setAmplifier(1)->setDuration(20*5));
    }
}