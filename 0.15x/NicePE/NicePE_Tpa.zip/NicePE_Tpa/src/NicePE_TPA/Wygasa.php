<?php

namespace NicePE_TPA;

use pocketmine\scheduler\PluginTask;
use pocketmine\Player;
use pocketmine\entity\Effect;

class Wygasa extends PluginTask{
    protected $plugin;
    private $p;
    public function __construct(Main $plugin){
    	parent::__construct($plugin);
        $this->plugin = $plugin;
    }
	
    public function onRun($tick){
        $this->revert();
    }
    
    public function revert(){
   $gracz = $this->p;
   $gracz2 = $this->plugin->gracz2;
   $nick = strtolower($gracz->getName());
if($this->plugin->tpa[$nick] != null){
	$this->p->sendMessage("§8• [§cNicePE§8] §7Prosba o teleportacje wygasla! §8•");
		$gracz2->sendMessage("§8• [§cNicePE§8] §7Prosba o teleportacje wygasla! §8•");
					$this->plugin->tpa[$nick] = null;
    }
    }
    public function createWygasa($player){
        $this->p = $player;
    }
}