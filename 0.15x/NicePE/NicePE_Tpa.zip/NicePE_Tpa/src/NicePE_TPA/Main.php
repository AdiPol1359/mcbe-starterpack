<?php

namespace NicePE_TPA;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\level\Level;
use pocketmine\math\Vector3;

use pocketmine\command\CommandSender;
use pocketmine\command\Command;

use pocketmine\IPlayer;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\Timings;
use pocketmine\level\format\FullChunk;
use pocketmine\level\format\LevelProvider;
use pocketmine\level\Position;
use pocketmine\math\Vector2;
use pocketmine\math\AxisAlignedBB;
use pocketmine\plugin\Plugin;
use pocketmine\utils\ReversePriorityQueue;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener{
  public function  onEnable(){
  	
$this->getServer()->getPluginManager()->registerEvents($this, $this);
    					@mkdir($this->getDataFolder());
 $this->spawn = new Config($this->getDataFolder() . "spawn.yml", Config::YAML);
 $this->tp = new Config($this->getDataFolder() . "tpa.yml", Config::YAML);

$this->getServer()->getLogger()->info("§a[EverPEssentialCore] Wlaczone!");
}

  public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
  	if($cmd->getName()=="tpa"){
  		if(empty($args)){
  			$sender->sendMessage("§8• [§cNicePE§8] §7Uzyj /tpa (nick) §8•");
  		}
	if(isset($args[0])){
		$this->nick = strtolower($sender->getName());
	$akceptujacy = $this->getServer()->getPlayer($args[0]);
	$this->gracz2 = $this->getServer()->getPlayer($args[0]);
	$tepajacy_nick = $sender->getName();
	$akceptujacy_nick = strtolower($akceptujacy->getName());
	$e = $akceptujacy->getName();
	 if($akceptujacy){
	$akceptujacy->sendMessage("§8• [§cNicePE§8] §7Gracz §c$tepajacy_nick §7wyslal prosbe o teleportacje do ciebie! §8•");
	
	$akceptujacy->sendMessage("§8• [§cNicePE§8] §7Uzyj §c/tpaccept §7aby zaakceptowac prosbe o teleportacje §8•");
	
	$akceptujacy->sendMessage("§8• [§cNicePE§8] §7albo §c/tpdeny §7aby odrzucic prosbe o teleportacje §8•");
	 
	$sender->sendMessage("§8• [§cNicePE§8] §7Wyslano prosbe o teleportacje do gracza §c$e §8•");
	
		$sender->sendMessage("§8• [§cNicePE§8] §7Ten gracz ma §c15 §7sekund aby ja zaakceptowac §8•");
		
            $tw = new Wygasa($this);
            $tw->createWygasa($sender);
            $hw = ($this->getServer()->getScheduler()->scheduleDelayedTask($tw, 20*5));
            $this->task[$sender->getName()] = array($tw,$hw);
$this->tpa[$akceptujacy_nick] = $tepajacy_nick;
	}
	if(!$akceptujacy){
	$sender->sendMessage("§8• [§cNicePE§8] §7Gracz §c$akceptujacy_nick §7nie jest online! §8•");
	}
  }
  }
  
if($cmd->getName()=="tpaccept"){	
		$nick = strtolower($sender->getName());
		$this->nick = strtolower($sender->getName());
		$akceptujacy_nick = $sender->getName();
		if($this->tpa[$nick] == null){
	$sender->sendMessage("§8• [§cNicePE§8] §7Nie posiadasz zadnych prosb o teleportacje! §8•");
		}
	if($this->tpa[$nick] != null){
		$tepajacy = $this->getServer()->getPlayer($this->tpa[$nick]);
		$tepajacy_nick = $tepajacy->getName();
      $x = $tepajacy->getFloorX();
      $y = $tepajacy->getFloorY();
      $z = $tepajacy->getFloorZ();
      $x2 = $sender->getFloorX();
      $y2 = $sender->getFloorY();
      $z2 = $sender->getFloorZ();
      $nickz = $tepajacy->getName();
      $this->spawn->set("" . $nickz . "_X", $x);
      $this->spawn->set("" . $nickz . "_Y", $y);
      $this->spawn->set("" . $nickz . "_Z", $z);
      $this->tp->set("" . $nickz . "_X", $x2);
      $this->tp->set("" . $nickz . "_Y", $y2);
      $this->tp->set("" . $nickz . "_Z", $z2);
      $this->spawn->save();
      $this->tp->save();
	    //task
	  $t = new Teleportacja($this);
   $t->createTeleportacja($tepajacy);
   $h = ($this->getServer()->getScheduler()->scheduleDelayedTask($t, 20*10));
            $this->task[$tepajacy_nick] = array($t,$h);
                    
				$tepajacy->sendMessage("§8• [§cNicePE§8] §7Gracz §c$akceptujacy_nick §7zaakceptowal twoja prosbe o teleportacje! §8•");
				$sender->sendMessage("§8• [§cNicePE§8] §7Zaakceptowano prosbe o teleportacje gracza §c$tepajacy_nick §8•");
					$this->tpa[$nick] = null;
			}
			}
	if($cmd->getName()=="tpdeny"){
   $nick = strtolower($sender->getName());
   $tepajacy = $this->getServer()->getPlayer($this->tpa[$nick]);
   $tepajacy_nick = $tepajacy->getName();
   $akceptujacy_nick = $sender->getName();
 if($this->tpa[$nick] == null){
	$sender->sendMessage("§8• [§cNicePE§8] §7Nie posiadasz zadnych prosb o teleportacje! §8•");
		}
	if($this->tpa[$nick] != null){
				$tepajacy->sendMessage("§8• [§cNicePE§8] §7Gracz §c$akceptujacy_nick §7odrzucil twoja prosbe o teleportacje §8•");
			$sender->sendMessage("§8• [§cNicePE§8] §7Odrzucono prosbe o teleportacje gracza §c$tepajacy_nick §8•");
				  $this->tpa[$nick] = null;
				}
}
}
	public function onMove(PlayerMoveEvent $event){
		$player = $event->getPlayer();
		$nick = $player->getName();
		$x = $this->spawn->get("" . $nick . "_X");
		$y = $this->spawn->get("" . $nick . "_Y");
		$z = $this->spawn->get("" . $nick . "_Z");
		if($x){
						if(!($x == $player->getFloorX())){
					if($player->getName() !== null and isset($this->task[$player->getName()])){
                $this->task[$player->getName()][1]->cancel();
                unset($this->task[$player->getName()]);
							$player->sendMessage("§8• [§cNicePE§8] §7Poruszyłeś się! Teleportacja anulowana §8•");
							$this->spawn->remove("" . $nick . "_X");
     		$this->spawn->remove("" . $nick . "_Y");
		     $this->spawn->remove("" . $nick . "_Z");
		     $this->spawn->save();
							$player->removeEffect(9);
	}
    }
    						if(!($y == $player->getFloorY())){
					if($player->getName() !== null and isset($this->task[$player->getName()])){
                $this->task[$player->getName()][1]->cancel();
                unset($this->task[$player->getName()]);
							$player->sendMessage("§8• [§cNicePE§8] §7Poruszyłeś się! Teleportacja anulowana §8•");
						 $this->spawn->remove("" . $nick . "_X");
     		$this->spawn->remove("" . $nick . "_Y");
		     $this->spawn->remove("" . $nick . "_Z");
		     $this->spawn->save();
							$player->removeEffect(9);
	}
    }
    						if(!($z == $player->getFloorZ())){
					if($player->getName() !== null and isset($this->task[$player->getName()])){
                $this->task[$player->getName()][1]->cancel();
                unset($this->task[$player->getName()]);
							$player->sendMessage("§8• [§cNicePE§8] §7Poruszyłeś się! Teleportacja anulowana §8•");
							$this->spawn->remove("" . $nick . "_X");
     		$this->spawn->remove("" . $nick . "_Y");
		     $this->spawn->remove("" . $nick . "_Z");
		     $this->spawn->save();
							$player->removeEffect(9);
	}
    }
}
}
}