<?php

namespace NicePE_ChatPisanie;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
		$this->getLogger()->info("Plugin włączono");
				@mkdir($this->getDataFolder());
		$this->chat = new Config($this->getDataFolder() . "chat.yml", Config::YAML);
	}
	public function onDisable(){
		$this->getLogger()->info("Plugin wyłączono");
	}
	public function onJoin(PlayerJoinEvent $event){
				    $nick = $event->getPlayer()->getDisplayName();
		           $chat = new Config($this->getDataFolder() . "chat.yml", Config::YAML);
		if(!$chat->exists($nick)){
				$chat->set($nick, "0");
				$chat->save();
			}
	}
	public function zniszczone(BlockBreakEvent $e){
		$blok = $e->getBlock()->getId();
		$gracz = $e->getPlayer();
		$nick = $gracz->getDisplayName();
		$zniszczone = $this->chat->get($nick);
	if($zniszczone <= 499){
		if($blok == 1){
		$this->chat->set($nick,$zniszczone+1);
		$this->chat->save();
		$this->chat->reload();
				}
				if($zniszczone === 499){
					$gracz->sendMessage("§8• (§cNicePE§8) §7Odblokowano pisanie na chacie! §8•");
				}
	}
	}
  public function onChat(PlayerChatEvent $event){
	  $gracz = $event->getPlayer();
	  $nick = $gracz->getDisplayName();
   $zniszczone = $this->chat->get($nick);
   $zostalo = 500 - $zniszczone;
        if($zniszczone >= 500 || $gracz->hasPermission("nicepe.chatpisanie")){
		} 
		else{
			$event->setCancelled(true);
			$gracz->sendMessage("§8• (§cNicePE§8) §7Aby pisac na chacie musisz wykopac jeszcze §c$zostalo §7stone! §8•");
			}
  }
}