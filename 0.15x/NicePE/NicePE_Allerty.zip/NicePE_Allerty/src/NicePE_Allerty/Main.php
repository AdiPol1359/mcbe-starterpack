<?php

namespace NicePE_Allerty;

use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;

class Main extends PluginBase{
	
	       public function onEnable(){
		$this->getLogger()->info("Allert Włączono");
     }
     public function onDisable(){
     $this->getLogger()->info("Allert wyłączono");
 }
   public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
      if($cmd->getName() == "allert"){
 if(!$sender->hasPermission("allert.command")){
 $sender->sendMessage("§cNie posiadasz permisji (allert.command)");                                             }
  if((count($args) === 0)){
  $sender->sendMessage("§cUzyj: /allert (wiadomosc)");
                 return false;
               }else if ($sender->hasPermission("allert.command")){
         $message = trim(implode(" ", $args));

    if($sender instanceof Player){
 $sender->getServer()->broadcastTip("§8[§cALLERT§8]\n§c$message\n\n\n\n\n\n");
}
    if($sender instanceof ConsoleCommandSender){
 $sender->getServer()->broadcastTip("§8[§cALLERT§8]\n§c$message\n\n\n\n\n\n");
}
     }
          }
               }
               }