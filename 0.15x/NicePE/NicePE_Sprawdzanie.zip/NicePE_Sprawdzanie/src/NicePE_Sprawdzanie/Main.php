<?php

namespace NicePE_Sprawdzanie;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\TranslationContainer;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
				@mkdir($this->getDataFolder());
		$this->spr = new Config($this->getDataFolder() . "sprawdzani.yml", Config::YAML);
				if(!is_file($this->getDataFolder() . "kordy.yml")){
				$this->kordy = new Config($this->getDataFolder() . "kordy.yml", Config::YAML);
						$this->kordy->setAll([
				"x" => 0,
				"y" => 0,
				"z" => 0
			]);
			$this->kordy->save();
			}
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
		$this->getLogger()->info("Plugin włączono");
	}
	public function onDisable(){
		$this->getLogger()->info("Plugin wyłączono");
	}
	  public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
	 if($cmd->getName()=="s"){
	 	if(empty($args[0])){
	 		 					$sender->sendMessage("§8######################### §cNicePE §8#########################");
					$sender->sendMessage("§c* §7/s sprawdz (nick) §8- §7Uzyj aby wezwac gracza do sprawdzania");
					$sender->sendMessage("§c* §7/s czysty (nick) §8- §7Uzyj aby wypuscic gracza ze sprawdzania");
					$sender->sendMessage("§c* §7/s ban §8- §7Uzyj aby zbanowac gracza za cheaty");
					$sender->sendMessage("§c* §7/s ustaw §8- §7Uzyj aby ustawic kordy sprawdzania");
					$sender->sendMessage("§8######################### §cNicePE §8#########################");
	 	}
	 	if($args[0] == "ustaw"){
	 		$x = $sender->getFloorX();
	 		$y = $sender->getFloorY();
	 		$z = $sender->getFloorZ();
	 						$kordy = new Config($this->getDataFolder() . "kordy.yml", Config::YAML);
	 		$kordy->set("x", $x);
	 		$kordy->set("y", $y);
	 		$kordy->set("z", $z);
	 		$kordy->save();
	 		$sender->sendMessage("§7Pomyslnie zmieniono kordy na §c" . $x . "§7x §c" . $y . "§7y §c" . $z . "§7z");
	 }
	 if($args[0] == "sprawdz" && !$args[1]){
	 	$sender->sendMessage("§c* §7Uzyj /s sprawdz (nick)");
	 }
	 if($args[0] == "sprawdz" && isset($args[1])){
	 	$sprawdzany = $this->getServer()->getPlayer($args[1]);
	 	$nick = $args[1];
	 	$anick = $sender->getName();
	 	if(!$sprawdzany){
	 		$sender->sendMessage("§c* §7Nie odnaleziono gracza §c$nick");
	 	}
	 	if($sprawdzany){
	 		  		 	$this->spr->set($nick, "*");
	 		  		 	$this->spr->save();
	 		  	$k = new Config($this->getDataFolder() . "kordy.yml", Config::YAML);
	 		  	$x1 = $k->get("x");
	 		  	$y1 = $k->get("y");
	 		  	$z1 = $k->get("z");
	 		  	       $sprawdzany->teleport(new Position($x1, $y1, $z1));
	 			Server::getInstance()->broadcastMessage("§7Administrator §c$anick §7wezwal do sprawdzania gracza §c$nick");
	 			$sprawdzany->sendMessage("§c* §7Jestes sprawdzany! Mozesz uzywac tylko komend §c/msg §7i §c/r");
	 	}
	 }
	 if($args[0] == "czysty" && !$args[1]){
	 		 	$sender->sendMessage("§c* §7Uzyj /s czysty (nick)");	
	 }
	 if($args[0] == "czysty" && isset($args[1])){
	 		 	$czysty = $this->getServer()->getPlayer($args[1]);
	 	$nick = $args[1];
	 	if(!$czysty){
	 		$sender->sendMessage("§c* §7Nie odnaleziono gracza §c$nick");
	 	}
	 	if($czysty){
	 	 	  			if(!$this->spr->get("$nick")){
  			$sender->sendMessage("§c* §7Ten gracz nie jest sprawdzany!");
  			return false;
  		}
  		if($this->spr->get("$nick")){
  $czysty->teleport($czysty->getLevel()->getSafeSpawn());
    		 	$this->spr->remove($nick, "*");
  		 	$this->spr->save();
	 			Server::getInstance()->broadcastMessage("§7Gracz §c$nick §7jest czysty!");
  			}
	 }
	 }
	 if($args[0] == "ban" && !isset($args[1])){
	 		 		 	$sender->sendMessage("§c* §7Uzyj /s ban (nick)");
	 }
	 if($args[0] == "ban" && isset($args[1])){
	 	$bnick = $this->getServer()->getPlayer($args[1]);
	 	$nick = $args[1];
	 	if(!$bnick){
	 			 		$sender->sendMessage("§c* §7Nie odnaleziono gracza §c$nick");
	 	}
	 	if($bnick){
	 	if(!$this->spr->get("$nick")){
  			$sender->sendMessage("§c* §7Ten gracz nie jest sprawdzany!");
  			return false;
  		}
	 		if($this->spr->get("$nick")){
	 				 			Server::getInstance()->broadcastMessage("§7Gracz §c$nick §7zostal zbanowany na chity!");
	 				$this->spr->remove($nick, "*");
  		 	$this->spr->save();
  						Server::getInstance()->dispatchCommand(new ConsoleCommandSender(), 'kick ' . $nick . ' chity');
	 			}
	 	}
	 }
	 }
	 if($cmd->getName() == "przyznajesie"){
	 	$nick = $sender->getName();
	 	 	  			if(!$this->spr->get("$nick")){
  			$sender->sendMessage("§c* §7Nie jestes sprawdzany!");
  			return false;
  		}
   if($this->spr->get("$nick")){
  		 	$this->spr->remove($nick, "*");
  		 	$this->spr->save();
  	Server::getInstance()->broadcastMessage("§7Gracz §c$nick §7przyznal sie do chitow!");
  						Server::getInstance()->dispatchCommand(new ConsoleCommandSender(), 'kick ' . $nick . ' chity');
  		}
	 }
	}
	    public function PlayerQuitEvent(PlayerQuitEvent $e){
	    	$nick = $e->getPlayer()->getName();
	    	$test = $e->getPlayer();
	    	$l = new Config($this->getDataFolder() . "sprawdzani.yml", Config::YAML);
	    	if($l->get($nick)){
	    $ban = "ban $nick";
		$this->getServer()->dispatchCommand(new ConsoleCommandSender, $ban);
	    	$this->spr->remove($nick, "*");
  		 	$this->spr->save();
	    	}
	    	}
	}