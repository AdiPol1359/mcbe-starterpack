<?php

namespace NicePE_ParticleInfo;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info(" Zaladowane OBS");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('particleinfo'))) {
				if(empty($args)) {
					$sender->sendMessage("§l§8)§7===========§8( (§cParticlesy§8) )§7===========§8(");
					$sender->sendMessage("§c* §7Chcesz kupic §cParticlesy§r§7?");
					$sender->sendMessage("§c* §7Wyslij SMS'a o tresci §cAP.HOSTMC §r§7pod numer §c91058");
					$sender->sendMessage("§c* §7Koszt to §c12§7,§c30§7zl");
					$sender->sendMessage("§l§8)§7===========§8( (§cParticlesy§8) )§7===========§8(");
                          }
	
	}
						}
					}
