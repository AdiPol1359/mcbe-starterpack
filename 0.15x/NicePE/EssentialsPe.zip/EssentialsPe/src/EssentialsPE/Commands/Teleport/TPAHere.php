<?php
namespace EssentialsPE\Commands\Teleport;

use EssentialsPE\BaseFiles\BaseCommand;
use EssentialsPE\Loader;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class TPAHere extends BaseCommand{
    /**
     * @param Loader $plugin
     */
    public function __construct(Loader $plugin){
        parent::__construct($plugin, "tpahere", "Request a player to teleport to your position", "/tpahere <player>", false);
        $this->setPermission("essentials.tpahere");
    }

    /**
     * @param CommandSender $sender
     * @param string $alias
     * @param array $args
     * @return bool
     */
    public function execute(CommandSender $sender, $alias, array $args){
        if(!$this->testPermission($sender)){
            return false;
        }
        if(!$sender instanceof Player){
            $sender->sendMessage($this->getConsoleUsage());
            return false;
        }
        if(count($args) !== 1){
            $sender->sendMessage(TextFormat::RED . $this->getUsage());
            return false;
        }
        $player = $this->getPlugin()->getPlayer($args[0]);
        if(!$player){
            $sender->sendMessage(TextFormat::RED . "• Gracza nie ma na serwerze •");
            return false;
        }
        if($player->getName() === $sender->getName()){
            $sender->sendMessage(TextFormat::RED . "[Error] Please provide another player name");
            return false;
        }
        $this->getPlugin()->requestTPHere($sender, $player);
        $player->sendMessage(TextFormat::RED . $sender->getName() . TextFormat::GREEN . " §7Chce, abyś się teleportował §cdo niego, §7użyj:\n§c/tpaccept §7żeby zaakceptować\n§c/tpdeny §7żeby odrzucić");
        $sender->sendMessage(TextFormat::GREEN . "§8• §7Wysłano prośbę o Teleportowanie do > §c" . $player->getDisplayName(). "§7! §8•");
        return true;
    }
} 
