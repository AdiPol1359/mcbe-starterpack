<?php

namespace NicePE_WyczyscChat;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info(" Zaladowane OBS");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('chatwyczysc'))) {
				if(empty($args)) {
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage(" ");
					$sender->sendMessage("§8• (§cChat§8) §7Twój chat został §cwyczyszony§7! §8•");
					return true;
				}
	
	}
						}
					}