<?php

namespace wymiana;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info(" Wymiany Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('coins'))) {
				if(empty($args)) {
					$sender->sendMessage("§7[ ========== §a[ Wymiana Coins ] §7 ========== ]");
					$sender->sendMessage("§7> Aby wymienic Coins wpisz §c/coins (nr)");
					$sender->sendMessage("§7> §b[§c1§b] §732x Coins >> 1 Klucz");
                 $sender->sendMessage("§7> §b[§c2§b] §748x Coins>> 1 TOP BOX ");
					$sender->sendMessage("§7> §b[§c3§b] §764x Coins >> 1 Magiczny Case ");
					$sender->sendMessage("§7[ ========== §a[ Wymiana Coins ] §7 ========== ]");
					return true;
				}   
					 if($args[0] == "1") {
					 if($sender->getInventory()->contains(Item::get(341, 0, 32))){
                               $sender->getInventory()->addItem(Item::get(421, 0, 1));
                               $sender->getInventory()->removeItem(Item::get(341, 0, 32));
						$sender->sendMessage("§e• §b[§cSV4U§b] §7Wymieniles (x32) Coins na  §c1 Klucz ");
            }
						else{
							$sender->sendMessage("§c• §b[§cSV4U§b] §7Nie posiadasz §cx32 Coins! •");
							}
						return true;
                }    
                     if($args[0] == "2") {
					    if($sender->getInventory()->contains(Item::get(341, 0, 48))){
                               $sender->getInventory()->addItem(Item::get(146, 0, 1));
                               $sender->getInventory()->removeItem(Item::get(341, 0, 48));
						$sender->sendMessage("§e• §b[§cSV4U§b] §7Wymieniles (48) Coins na §c1 TopBox ");
            }
						else{
							$sender->sendMessage("§c• §b[§cSV4U§b] §7Nie posiadasz §cx48 §7Coins! •");
							}
						return true;
                }  
                     if($args[0] == "3") {
					    if($sender->getInventory()->contains(Item::get(341, 0, 64))){
                               $sender->getInventory()->addItem(Item::get(247, 0, 1));
                               $sender->getInventory()->removeItem(Item::get(341, 0, 64));
						$sender->sendMessage("§e• §b[§cSV4U§b] §7Wymieniles (x64) Coins na §c 1 MC ");
            }
						else{
							$sender->sendMessage("§c• §b[§cSV4U§b] §7Nie posiadasz §cx64 §7Coins! •");
							}
						return true;
                          }
	
	}
						}
					}
