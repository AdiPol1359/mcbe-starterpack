<?php

namespace ctAutoClearItems;

use pocketmine\plugin\PluginBase;

class Main extends PluginBase {
    
    public function onEnable() {        
        $this->getLogger()->info("Plugin wlaczony!");
        $this->getLogger()->info("Plugin napisany dla CraftTure.pl!");
        $task = new RepetaingTask($this);
        $this->getServer()->getScheduler()->scheduleRepeatingTask($task, (20*60)*10);
    }
    
    public function onDisable() {
        $this->getLogger()->info("Plugin wylaczony!");
        $this->getLogger()->info("Plugin napisany dla CraftTure.pl!");
    }
}

