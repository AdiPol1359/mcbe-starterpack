<?php

namespace ctAutoClearItems;

use pocketmine\scheduler\PluginTask;
use pocketmine\plugin\Plugin;

class RepetaingTask extends PluginTask {
    
    private $plugin;
    
    public function __construct(Plugin $plugin) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
    }
        
    public function onRun($currentTick) {
        $this->plugin->getServer()->broadcastMessage(str_replace('&', '§', "&8• &a> (&aSmetnik&8) &7Czyszczenie przedmiotow za &a60 &7sekund! &f•"));   
        $task = new DelayedTask($this->plugin);
        $this->plugin->getServer()->getScheduler()->scheduleDelayedTask($task, 20*60);
    }
}

