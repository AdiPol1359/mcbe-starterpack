<?php

namespace ctAutoClearItems;

use pocketmine\scheduler\PluginTask;
use pocketmine\plugin\Plugin;
use pocketmine\command\ConsoleCommandSender;

class DelayedTask extends PluginTask {
    
    private $plugin;
    
    public function __construct(Plugin $plugin) {
        parent::__construct($plugin);
        $this->plugin = $plugin;
    }
    
    public function onRun($currentTick) {
        $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "lagg clear");
        $this->plugin->getServer()->broadcastMessage(str_replace('&', '§', "&8• &a> &8(&aŚmietnik&8) &7Przedmioty zostaly wyczyszczone! &f•"));   
    }
}

