<?php

namespace perly;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{
	public function onEnable(){
		$this->getLogger()->info("Zaladowane");
		}

  public function onCommand(CommandSender $sender, Command $command, $label, array $args){	
			if(strtolower($command->getName('enderperly'))) {
				if(empty($args)) {
					$sender->sendMessage("§7[ ========== §aEnderPerly§7 ==========]");
					$sender->sendMessage("§7> Aby kupic §c2 perel§7 wpisz:"); 
					$sender->sendMessage("§7> /perly kup §7Koszt: 15 emeraldow");
					$sender->sendMessage("§7[ ========== §aEnderPerly§7 ========== ]");
					return true;
				}
					 if($args[0] == "kup") {
					 if($sender->getInventory()->contains(Item::get(388, 0, 15))){
						$sender->getInventory()->addItem(Item::get(344, 0, 2));
						 $sender->getInventory()->removeItem(Item::get(388, 0, 15));
						$sender->sendMessage("§a• [MC.4FOURHC.PL] Zakupiłeś 2 enderperel •");
            }
						else{
							$sender->sendMessage("§c• [MC.4FOURHC.PL] potrzebujesz 15 emeraldow •");
							}
						return true;
                          }
	
	}
						}
					}
