<?php
namespace luigigar\luigigar;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;

use pocketmine\Server;
use pocketmine\Player;

use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;

use pocketmine\utils\Config;

use pocketmine\item\Item;
use pocketmine\item\Emerald;

use pocketmine\block\Block;
use pocketmine\level\sound\TNTPrimeSound;
use pocketmine\level\sound\PopSound;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\utils\TextFormat as C;

use pocketmine\math\Vector3;
use pocketmine\level\Level;
use pocketmine\level\particle\LavaParticle;


class Main extends PluginBase implements Listener{

  public function onEnable(){
    @mkdir($this->getDataFolder());
    $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
    $config->save();
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
  }

  public function onDeath(PlayerDeathEvent $event){
    $entity = $event->getEntity();
    $cause = $entity->getLastDamageCause();
    if($entity instanceof Player){
       if($cause instanceof Player){
        $killer->getInventory()->addItem(Item::get(421,0,1));
    }
  }
}
  public function onInteract(PlayerInteractEvent $event){
    $block = $event->getBlock();
    $player = $event->getPlayer();
    $inventory = $player->getInventory();       
      if($block->getId() === Block::END_PORTAL_FRAME){     
        if($event->getPlayer()->getInventory()->contains(Item::get(421, 0, 1))) {
												$level=$player->getLevel();
										$level->addSound(new EndermanTeleportSound($player));
										$level=$player->getLevel();
        $player->sendMessage(C::RED . C::BOLD . "- ". C::GRAY . "Otwieram...!");
        $prize = rand(1,16);
        switch($prize){
        case 1:
          $inventory->addItem(Item::get(466,0,3));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;
		        case 2:
          $inventory->addItem(Item::get(466,0,2));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;
		        case 3:
          $inventory->addItem(Item::get(466,0,1));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;
        case 4:
          $inventory->addItem(Item::get(322,0,3));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;
        case 5:
          $inventory->addItem(Item::get(421,0,1));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;  
        case 6:
          $inventory->addItem(Item::get(146,0,2));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;  		
        case 7:
          $inventory->addItem(Item::get(264,0,32));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;
        case 8:
          $inventory->addItem(Item::get(247,0,1));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break; 
        case 9:
          $inventory->addItem(Item::get(332,0,1));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break; 		
        case 10:
          $inventory->addItem(Item::get(3,0,64));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;      
        case 11:
          $inventory->addItem(Item::get(180,0,32));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;
        case 12:
          $inventory->addItem(Item::get(388,0,20));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;
        case 13:
          $inventory->addItem(Item::get(388,0,16));
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;		
        case 14:
          $inventory->addItem(Item::get(146,0,1));  
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;
		        case 15:
          $inventory->addItem(Item::get(466,0,2));  
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;
		        case 16:
          $inventory->addItem(Item::get(57,0,10));  
		  $player->getInventory()->removeItem(Item::get(421, 0, 1));
        break;
    }
		}
  }
}
}
