€￠onom￥$ v5.7 for PocketMine-MP 1.6

Translation of EconomyAPI is welcomed.

Please send the language config file or json resource file if you completed translation. It is okay to commit on GitHub, or commenting on forums.

If the error occurs, please send me the "entire" error log in any method.


- Contribute to my project!
https://github.com/onebone/EconomyS
Feel free to make "Pull Request" or "Issues".


Official Websites:
http://forums.pocketmine.net/ (PocketMine Forums)
http://www.mcpekorea.com/ (MCPE KOREA)
http://onebone.me/

Official Download Link:
http://forums.pocketmine.net/plugins/onom.30/
http://cafe.naver.com/minecraftpe/1297447
http://onebone.me/plugins/#economys



License

EconomyS, the massive economy plugin with many features for PocketMine-MP
Copyright (C) 2013-2015  onebone <jyc00410@gmail.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
